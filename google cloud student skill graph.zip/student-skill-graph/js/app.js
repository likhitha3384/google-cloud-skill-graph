const state = {
  user: JSON.parse(localStorage.getItem("sg_user") || "null"),
  skills: JSON.parse(localStorage.getItem("sg_skills") || "null") || {
    Python:62, Java:48, "Data Structures":55, "Cloud Computing":38, "Communication":44, "English":58, "AI/ML":31, "Problem Solving":52
  },
  assessments: JSON.parse(localStorage.getItem("sg_assessments") || "[]"),
  projects: JSON.parse(localStorage.getItem("sg_projects") || "[]"),
  completedLessons: Number(localStorage.getItem("sg_lessons") || 3),
  certificates: JSON.parse(localStorage.getItem("sg_certs") || "[]"),
  quizScore: Number(localStorage.getItem("sg_quiz") || 0),
  activePage: "dashboard"
};
const $ = id => document.getElementById(id);
const save = () => {
  localStorage.setItem("sg_user", JSON.stringify(state.user));
  localStorage.setItem("sg_skills", JSON.stringify(state.skills));
  localStorage.setItem("sg_assessments", JSON.stringify(state.assessments));
  localStorage.setItem("sg_projects", JSON.stringify(state.projects));
  localStorage.setItem("sg_lessons", state.completedLessons);
  localStorage.setItem("sg_certs", JSON.stringify(state.certificates));
  localStorage.setItem("sg_quiz", state.quizScore);
};
function initials(name){return (name||"Student").split(" ").map(x=>x[0]).join("").slice(0,2).toUpperCase()}
function showToast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2500)}
function togglePassword(id,btn){const input=$(id);if(!input)return;const show=input.type==='password';input.type=show?'text':'password';btn.textContent=show?'🙈':'👁';btn.setAttribute('aria-label',show?'Hide password':'Show password');}
function setupUser(){
  const u=state.user||{name:"Likhitha Reddy",email:"student@example.com",branch:"Computer Science Engineering",year:"3rd Year",goal:"Software Developer"};
  state.user=u;
  ["sideName","topName"].forEach(id=>$(id).textContent=u.name);
  ["sideAvatar","topAvatar"].forEach(id=>$(id).textContent=initials(u.name));
  if($("topCoins")) $("topCoins").textContent=getRewardPoints();
  save();
}
function showApp(){
  if(!state.user){ $('app').classList.add('hidden'); $('authPage').classList.remove('hidden'); return; }
  $("authPage").classList.add("hidden"); $("app").classList.remove("hidden"); setupUser(); render("dashboard");
}
const DEFAULT_ACCOUNTS={
  "student@example.com":{password:"Student@123",name:"Demo Student",branch:"Computer Science Engineering",year:"3rd Year",goal:"Software Developer"},
  "likhitha@student.com":{password:"Likhitha@123",name:"Likhitha Reddy",branch:"Computer Science Engineering",year:"3rd Year",goal:"Software Developer"}
};
function getAccounts(){return JSON.parse(localStorage.getItem("sg_accounts")||"null")||DEFAULT_ACCOUNTS}
function saveAccounts(v){localStorage.setItem("sg_accounts",JSON.stringify(v))}
function loginWithCredentials(email,password){
  const key=email.trim().toLowerCase();
  const accounts=getAccounts(), a=accounts[key];
  if(!a || a.password!==password){showToast("❌ Incorrect email or password. Login denied.");return false}
  state.user={name:a.name,email:key,branch:a.branch||"Not specified",year:a.year||"Student",goal:a.goal||"Explore careers"};
  localStorage.setItem("sg_active_email",key);
  accounts[key]={...a,name:state.user.name,branch:state.user.branch,year:state.user.year,goal:state.user.goal,lastLogin:new Date().toISOString()};
  saveAccounts(accounts);
  save();
  showApp();showToast("Welcome back, "+a.name+"!");return true;
}
$("loginForm").addEventListener("submit",e=>{e.preventDefault();loginWithCredentials($("loginEmail").value,$("loginPassword").value)});
$("demoLogin").onclick=()=>{$("loginEmail").value="student@example.com";$("loginPassword").value="Student@123";showToast("Demo credentials filled. Click Sign in.")};
function logoutUser(){state.user=null;localStorage.removeItem("sg_user");localStorage.removeItem("sg_active_email");$("app").classList.add("hidden");$("authPage").classList.remove("hidden");showToast("Logged out successfully")};
$("logoutBtn").onclick=logoutUser;
$("mobileMenu").onclick=()=>document.querySelector(".sidebar").classList.toggle("open");
document.querySelectorAll(".nav-item").forEach(b=>b.onclick=()=>{render(b.dataset.page);document.querySelector(".sidebar").classList.remove("open")});

function head(title,desc,action=""){return `<div class="page-head"><div><div class="eyebrow">STUDENT SKILL GRAPH</div><h1>${title}</h1><p>${desc}</p></div>${action}</div>`}
function progressBar(name,val){return `<div class="skill-row"><div class="skill-top"><span>${name}</span><strong>${val}%</strong></div><div class="bar"><div class="fill" style="width:${val}%"></div></div></div>`}
function dashboard(){
 const avg=Math.round(Object.values(state.skills).reduce((a,b)=>a+b,0)/Object.keys(state.skills).length);
 const weak=Object.entries(state.skills).sort((a,b)=>a[1]-b[1]).slice(0,3);
 return head(`Good evening, ${state.user.name.split(" ")[0]} 👋`,"Your personalized learning workspace. Continue where you left off and close your next skill gap.",
 `<button class="btn gold-btn" onclick="render('recommendations')">View recommendations →</button>`) + `
 <div class="cards">
  <div class="card stat"><div><div class="stat-label">Overall Skill Level</div><div class="stat-num">${avg}%</div><div class="delta">↑ 8% this month</div></div><div class="stat-icon">◈</div></div>
  <div class="card stat"><div><div class="stat-label">Lessons Completed</div><div class="stat-num">${state.completedLessons}</div><div class="delta">Keep learning</div></div><div class="stat-icon">▶</div></div>
  <div class="card stat"><div><div class="stat-label">Assessments</div><div class="stat-num">${state.assessments.length}</div><div class="delta">Stored history</div></div><div class="stat-icon">✓</div></div>
  <div class="card stat"><div><div class="stat-label">Certificates</div><div class="stat-num">${state.certificates.length}</div><div class="delta">Share your achievements</div></div><div class="stat-icon">◇</div></div>
 </div>
 <div class="grid2">
  <div class="card"><h3 class="section-title">Skill Performance</h3><div class="chart-box"><canvas id="dashBar"></canvas></div></div>
  <div class="card"><h3 class="section-title">Skill Distribution</h3><div class="chart-box"><canvas id="dashPie"></canvas></div></div>
 </div>
 <div class="grid2">
  <div class="card"><h3 class="section-title">Recommended next steps</h3><div class="list">${weak.map(([s,v])=>`<div class="list-item"><h4>${s} <span class="pill red">${v}% • Skill gap</span></h4><p>Start a beginner lesson, complete the quiz, then attempt the practical assessment.</p></div>`).join("")}</div></div>
  <div class="card"><h3 class="section-title">Continue learning</h3><div class="list">
  <div class="list-item"><h4>Python Fundamentals <span class="pill blue">62%</span></h4><p>Variables → conditions → loops → functions → OOP</p><button class="btn light" onclick="completeLesson('Python')">Complete next lesson</button></div>
  <div class="list-item"><h4>Cloud Computing Basics</h4><p>Cloud concepts and Google Cloud foundations.</p><button class="btn light" onclick="render('resources')">Open resources</button></div>
  </div></div>
 </div>`;
}
function profile(){
 return head("Student Profile","Tell the platform about your academic background and career goal.")+`
 <div class="card profile-card">
  <div class="profile-photo"><div class="big-avatar">${initials(state.user.name)}</div></div>
  <div>
   <h3 class="section-title">Profile information</h3>
   <div class="form-grid">
    <div class="form-group"><label>FULL NAME</label><input id="pName" class="field" value="${state.user.name}"></div>
    <div class="form-group"><label>EMAIL</label><input id="pEmail" class="field" value="${state.user.email}"></div>
    <div class="form-group"><label>BRANCH / DEPARTMENT</label><input id="pBranch" class="field" value="${state.user.branch}"></div>
    <div class="form-group"><label>YEAR</label><select id="pYear" class="field"><option>${state.user.year}</option><option>1st Year</option><option>2nd Year</option><option>3rd Year</option><option>4th Year</option></select></div>
    <div class="form-group full"><label>CAREER GOAL</label><input id="pGoal" class="field" value="${state.user.goal}" placeholder="Example: Software Developer"></div>
   </div>
   <button class="btn gold-btn" style="margin-top:18px" onclick="saveProfile()">Save profile</button>
  </div>
 </div>`;
}
function skillgraph(){
 return head("Skill Graph","A visual profile of your current capabilities across technical and professional areas.")+
 `<div class="grid2"><div class="card"><div class="chart-box" style="height:400px"><canvas id="radar"></canvas></div></div><div class="card"><h3 class="section-title">Skill levels</h3>${Object.entries(state.skills).map(([s,v])=>progressBar(s,v)).join("")}</div></div>`;
}
function analysis(){
 const sorted=Object.entries(state.skills).sort((a,b)=>a[1]-b[1]);
 return head("Skill Gap Analysis","Assessment scores, quizzes and completed lessons are combined to identify areas that need attention.")+
 `<div class="grid2"><div class="card"><h3 class="section-title">Current gaps</h3>${sorted.slice(0,5).map(([s,v],i)=>`<div class="list-item" style="margin-bottom:9px"><h4>${s} <span class="pill ${v<40?"red":"blue"}">${v}%</span></h4><p>${v<40?"High-priority gap: start from fundamentals and use guided practice.":"Developing: continue lessons and practical assessments."}</p></div>`).join("")}</div>
 <div class="card"><h3 class="section-title">How the analysis works</h3><div class="timeline"><div class="step done"><h4>1. Profile & goal</h4><p>Career goal and academic background define the target skill set.</p></div><div class="step done"><h4>2. Assessments</h4><p>Scores are stored and used as evidence of current proficiency.</p></div><div class="step"><h4>3. Learning activity</h4><p>Lessons and quizzes update the skill graph.</p></div><div class="step"><h4>4. Recommendation engine</h4><p>Weak areas become priority items in the roadmap.</p></div></div></div></div>`;
}
function recommendations(){
 const weak=Object.entries(state.skills).sort((a,b)=>a[1]-b[1]);
 const goal=state.user.goal||"Software Developer";
 return head("Recommendations",`Suggested learning path for your goal: ${goal}. Recommendations adapt as your scores change.`)+
 `<div class="grid3">${weak.slice(0,6).map(([s,v],i)=>`<div class="card"><span class="pill ${v<40?"red":"blue"}">${v}% current</span><h3>${s}</h3><p class="muted">Recommended because this area is below your current overall profile. Follow the sequence from fundamentals to practical work.</p><div style="margin-top:14px"><button class="btn" onclick="render('resources')">Start learning</button></div></div>`).join("")}</div>`;
}
function roadmap(){
 const stages=[["Foundation","Programming basics, computer fundamentals, English grammar",true],["Core Skills","Data structures, SQL, Git, OOP",false],["Cloud & Tools","Google Cloud, APIs, deployment, DevOps basics",false],["Projects","Build 2–3 portfolio projects using learned skills",false],["Career Ready","Assessments, presentation practice, interview preparation",false]];
 return head("Learning Roadmap","A step-by-step route from beginner fundamentals to practical, career-ready skills.")+
 `<div class="card"><div class="timeline">${stages.map((x,i)=>`<div class="step ${x[2]?"done":""}"><h4>${i+1}. ${x[0]} ${x[2]?'<span class="pill green">In progress</span>':""}</h4><p>${x[1]}</p><button class="btn light" onclick="render('resources')">View learning resources</button></div>`).join("")}</div></div>`;
}
const resources=[
 ["Python from Scratch to Pro","Programming","python","12 lessons","Beginner → Advanced","Python"],
 ["Java Complete Learning Path","Programming","cloud","14 lessons","Beginner → Advanced","Java"],
 ["C / C++ Fundamentals","Programming","python","16 lessons","Beginner → Advanced","C++"],
 ["Data Structures & Algorithms","Programming","cloud","18 lessons","Beginner → Job Ready","Data Structures"],
 ["Data Analyst Path","Data","cloud","18 lessons","Beginner → Job Ready","Data Analytics"],
 ["AI & Machine Learning","AI/ML","ai","20 lessons","Foundation → Advanced","AI/ML"],
 ["Google Cloud Computing","Cloud","cloud","10 lessons","Foundation → Professional","Cloud Computing"],
 ["English Communication","Communication","python","20 lessons","Beginner → Fluent","Communication"]
];
const lessonVideos={
 Python:{title:"Python Full Course for Beginners",url:"https://www.youtube.com/embed/rfscVS0vtbw",notes:"Learn Python syntax, variables, conditions, loops, functions and core programming concepts."},
 Java:{title:"Java Programming for Beginners",url:"https://www.youtube.com/embed/eIrMbAQSU34",notes:"Learn Java syntax, classes, objects, methods, conditions, loops and basic OOP."},
 "C++":{title:"C++ Full Course",url:"https://www.youtube.com/embed/vLnPwxZdW4Y",notes:"Learn C++ fundamentals, variables, control flow, functions, arrays and object-oriented programming."},
 "Data Structures":{title:"Data Structures Full Course",url:"https://www.youtube.com/embed/RBSGKlAvoiM",notes:"Understand arrays, linked lists, stacks, queues, trees, graphs and algorithmic thinking."},
 "Data Analytics":{title:"Data Analytics for Beginners",url:"https://www.youtube.com/embed/8DvywoWv6fI",notes:"Learn the foundations of data analysis, spreadsheets, SQL, visualization and analytical thinking."},
 "AI/ML":{title:"Machine Learning for Beginners",url:"https://www.youtube.com/embed/i_LwzRVP7bg",notes:"Learn machine-learning fundamentals, datasets, training, evaluation and common algorithms."},
 "Cloud Computing":{title:"Google Cloud Digital Leader / Cloud Basics",url:"https://www.youtube.com/embed/4D3X6Xl5c_Y",notes:"Learn cloud concepts, compute, storage, networking and the role of Google Cloud services."},
 Communication:{title:"English Communication Skills",url:"https://www.youtube.com/embed/2QbD6LhQ7vI",notes:"Practice clear speaking, vocabulary, sentence formation and professional communication."}
};
function resourcesPage(){
 return head("Resources","Choose a skill to open its real teaching video, lesson notes and the matching skill quiz.",
 `<input id="resourceSearch" class="search" placeholder="Search Python, Java, Cloud..." oninput="filterResources()">`)+
 `<div id="resourceGrid" class="resource-grid">${resources.map((r,i)=>`<div class="card resource" data-text="${r.join(" ").toLowerCase()}"><div class="resource-cover ${r[2]}"><span class="pill">${r[3]}</span></div><div class="resource-body"><h3>${r[0]}</h3><p>${r[1]} • ${r[4]}<br>Real video + notes + ${r[5]} quiz</p><div class="resource-meta"><span>▶ Teaching video</span><button class="btn" onclick="startResource('${r[5]}')">Start</button></div></div></div>`).join("")}</div>`;
}
function startResource(skill){
 const v=lessonVideos[skill]||lessonVideos.Python;
 return renderLesson(skill,v);
}
function renderLesson(skill,v){
 state.currentSkill=skill;
 const q=quizBanks[skill]||quizBanks.Python;
 $("content").innerHTML=head(`${skill} Learning Lesson`,`Watch the lesson, review the notes, then take the ${skill} quiz.`)+
 `<div class="grid2"><div class="card"><div style="position:relative;padding-top:56.25%;overflow:hidden;border-radius:12px;background:#111"><iframe src="${v.url}" title="${v.title}" style="position:absolute;inset:0;width:100%;height:100%;border:0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div><h3 style="margin-top:18px">${v.title}</h3><p class="muted">${v.notes}</p><button class="btn gold-btn" onclick="completeVideoLesson('${skill}')">✓ Mark Lesson Complete</button></div><div class="card"><h3 class="section-title">Lesson checklist</h3><div class="timeline"><div class="step done"><h4>1. Watch the teaching video</h4><p>Understand the main concepts before attempting questions.</p></div><div class="step"><h4>2. Review lesson notes</h4><p>${v.notes}</p></div><div class="step"><h4>3. Take ${skill} quiz</h4><p>${q.length} questions with previous, next, submit and result review.</p><button class="btn" onclick="startQuiz('${skill}')">Open ${skill} Quiz</button></div><div class="step"><h4>4. Take ${skill} assessment</h4><p>Complete the assessment to update this skill in your graph.</p><button class="btn light" onclick="startAssessment('${skill}')">Open Assessment</button></div></div></div></div>`;
}
function completeVideoLesson(skill){
 state.completedLessons++;state.skills[skill]=Math.min(100,(state.skills[skill]||0)+3);save();showToast(`${skill} lesson completed. Quiz unlocked.`);startQuiz(skill);
}

const quizBanks={
 Python:[
  {q:"Which keyword defines a function in Python?",o:["func","def","function","method"],a:1},
  {q:"Which data type stores whole numbers in Python?",o:["float","int","str","bool"],a:1},
  {q:"Which symbol is used for exponentiation in Python?",o:["^","**","//","%%"],a:1},
  {q:"What does len([10,20,30]) return?",o:["2","3","4","30"],a:1},
  {q:"Which collection stores key-value pairs?",o:["list","tuple","dictionary","set"],a:2},
  {q:"Which keyword exits a loop immediately?",o:["skip","stop","break","exitloop"],a:2}
 ],
 Java:[
  {q:"Which keyword is used to define a class in Java?",o:["class","struct","define","type"],a:0},
  {q:"Which method is the entry point of a Java application?",o:["start()","run()","main()","init()"],a:2},
  {q:"Which type stores true or false?",o:["boolean","bool","bit","logical"],a:0},
  {q:"Which keyword creates an object?",o:["make","new","create","object"],a:1},
  {q:"Which concept allows a class to acquire properties from another class?",o:["Encapsulation","Inheritance","Compilation","Casting"],a:1},
  {q:"Which collection does not allow duplicate elements?",o:["List","Set","ArrayList","Vector"],a:1}
 ],
 "C++":[
  {q:"Which function is the usual entry point of a C++ program?",o:["start()","main()","run()","begin()"],a:1},
  {q:"Which operator is used for stream insertion with cout?",o:["<<",">>","::","&&"],a:0},
  {q:"Which header provides std::cout?",o:["<stdio.h>","<iostream>","<string.h>","<math.h>"],a:1},
  {q:"Which feature lets a class have multiple constructors with different parameters?",o:["Overloading","Overriding","Inheritance","Templating"],a:0},
  {q:"Which keyword creates dynamic memory in C++?",o:["alloc","malloc","new","dynamic"],a:2},
  {q:"Which container stores elements in a resizable sequence?",o:["vector","pair","stackframe","iterator"],a:0}
 ],
 "Data Structures":[
  {q:"Which data structure follows LIFO?",o:["Queue","Stack","Tree","Graph"],a:1},
  {q:"Which data structure follows FIFO?",o:["Stack","Queue","Heap","Tree"],a:1},
  {q:"Binary search requires what ordering in the searchable array?",o:["Random order","Sorted order","Reverse only","Duplicate-free only"],a:1},
  {q:"What is the typical time complexity of binary search?",o:["O(n)","O(log n)","O(n²)","O(1) always"],a:1},
  {q:"Which traversal visits root, left subtree, then right subtree?",o:["Inorder","Preorder","Postorder","Level order"],a:1},
  {q:"Which structure is commonly used for BFS?",o:["Stack","Queue","Heap","Set"],a:1}
 ],
 "Data Analytics":[
  {q:"Which language is widely used for data analysis?",o:["Python","HTML","CSS","XML"],a:0},
  {q:"What does SQL primarily query?",o:["Images","Relational data","Audio","CPU registers"],a:1},
  {q:"Which measure represents the middle value of ordered data?",o:["Mean","Median","Mode","Range"],a:1},
  {q:"Which chart is commonly used to show trends over time?",o:["Line chart","Pie chart only","Scatterless chart","Tree chart"],a:0},
  {q:"What is data cleaning?",o:["Deleting all data","Correcting or handling inaccurate/incomplete data","Encrypting a database","Creating a chart"],a:1},
  {q:"Which pandas object is two-dimensional?",o:["Series","DataFrame","Index","Scalar"],a:1}
 ],
 "AI/ML":[
  {q:"What is supervised learning trained with?",o:["Labeled data","Only images","No data","Random passwords"],a:0},
  {q:"Which is a classification example?",o:["Predicting spam/not spam","Predicting house price","Grouping customers without labels","Sorting numbers"],a:0},
  {q:"What is overfitting?",o:["Model learns training data too closely and generalizes poorly","Model never trains","Data has no labels","Model has zero parameters"],a:0},
  {q:"Which metric is common for classification?",o:["Accuracy","Pixel size","File extension","Clock speed"],a:0},
  {q:"What is a feature?",o:["An input variable used by a model","Only the final prediction","A compiler error","A database password"],a:0},
  {q:"Which algorithm is commonly used for clustering?",o:["K-means","Linear regression","Naive Bayes only","Binary search"],a:0}
 ],
 "Cloud Computing":[
  {q:"Which cloud model provides virtual machines and networks?",o:["IaaS","SaaS","DaaS only","HTML"],a:0},
  {q:"What does scalability mean?",o:["Ability to adjust resources to demand","Deleting resources","Changing a password","Printing logs"],a:0},
  {q:"Which service is object storage?",o:["Cloud Storage","Cloud SQL","Compute Engine","Cloud DNS"],a:0},
  {q:"Which Google Cloud service runs containers without managing servers?",o:["Cloud Run","Cloud Storage","BigQuery","Cloud DNS"],a:0},
  {q:"What is IAM used for?",o:["Identity and access control","Image editing","Database indexing","Video streaming"],a:0},
  {q:"What does a VPC provide?",o:["A logically isolated network","A word processor","A compiler","A certificate"],a:0}
 ],
 Communication:[
  {q:"Which sentence is grammatically correct?",o:["She go to college.","She goes to college.","She going college.","She gone college."],a:1},
  {q:"Which is a professional email opening?",o:["Hey dude","Dear Professor,","Yo!","What's up bro?"],a:1},
  {q:"Which skill involves understanding spoken language?",o:["Listening","Typing","Drawing","Coding"],a:0},
  {q:"Which is a filler word?",o:["Therefore","Um","However","Because"],a:1},
  {q:"Which improves presentation clarity?",o:["Clear structure and pauses","Speaking as fast as possible","Avoiding examples","Using no headings"],a:0},
  {q:"Which is suitable interview behavior?",o:["Give concise, relevant answers","Interrupt constantly","Avoid eye contact always","Ignore the question"],a:0}
 ]
};
let quizSession={skill:"Python",index:0,answers:[],score:0,rewarded:false};
function quizzes(){return `<div class="card"><h3>Select a skill quiz</h3><p class="muted">Each skill has its own question bank. Java never uses Python questions.</p><div class="grid3">${Object.keys(quizBanks).map(s=>`<button class="btn" onclick="startQuiz('${s}')">${s} Quiz</button>`).join("")}</div></div>`}
function startQuiz(skill){quizSession={skill,index:0,answers:[],score:0,rewarded:false};renderQuizQuestion();}
function renderQuizQuestion(){
 const qs=quizBanks[quizSession.skill]||quizBanks.Python;const item=qs[quizSession.index];const selected=quizSession.answers[quizSession.index];
 $("content").innerHTML=head(`${quizSession.skill} Quiz`,`Question ${quizSession.index+1} of ${qs.length}. Select an answer, then use Previous/Next. Submit when you finish.`)+
 `<div class="card" id="quizBox"><span class="pill blue">${quizSession.skill} • Skill Quiz</span><h2 style="margin-top:18px">${item.q}</h2><div>${item.o.map((o,i)=>`<button class="quiz-option ${selected===i?"selected":""}" onclick="selectQuizAnswer(${i})">${String.fromCharCode(65+i)}. ${o}</button>`).join("")}</div><div style="display:flex;gap:10px;justify-content:space-between;margin-top:20px"><button class="btn light" onclick="quizPrev()" ${quizSession.index===0?"disabled":""}>← Previous</button><div><button class="btn light" onclick="quizNext()">Next →</button><button class="btn gold-btn" onclick="submitQuiz()">Submit Quiz</button></div></div></div>`;
}
function selectQuizAnswer(i){quizSession.answers[quizSession.index]=i;renderQuizQuestion();}
function quizPrev(){if(quizSession.index>0){quizSession.index--;renderQuizQuestion();}}
function quizNext(){const qs=quizBanks[quizSession.skill];if(quizSession.index<qs.length-1){quizSession.index++;renderQuizQuestion();}else showToast("You are on the last question. Click Submit Quiz.");}
function submitQuiz(){
 const qs=quizBanks[quizSession.skill];quizSession.score=qs.reduce((n,q,i)=>n+(quizSession.answers[i]===q.a?1:0),0);const percent=Math.round(quizSession.score/qs.length*100);state.quizHistory=JSON.parse(localStorage.getItem("sg_quiz_history")||"[]");state.quizHistory.push({skill:quizSession.skill,score:percent,date:new Date().toLocaleString()});state.quizScore=percent;state.skills[quizSession.skill]=Math.min(100,Math.round(((state.skills[quizSession.skill]||0)+percent)/2));localStorage.setItem("sg_quiz_history",JSON.stringify(state.quizHistory));save();renderQuizResult(percent);
}
function renderQuizResult(percent){
 const qs=quizBanks[quizSession.skill];
 $("content").innerHTML=head(`${quizSession.skill} Quiz Result`,`You scored ${quizSession.score}/${qs.length} (${percent}%). Review every answer below.`)+`<div class="card"><div class="score-circle">${percent}%</div><div class="list">${qs.map((q,i)=>{const chosen=quizSession.answers[i];return `<div class="list-item"><h4>Q${i+1}. ${q.q}</h4><p>Your answer: <strong>${chosen==null?"Not answered":q.o[chosen]}</strong></p><p>Correct answer: <strong>${q.o[q.a]}</strong></p><span class="pill ${chosen===q.a?"green":"red"}">${chosen===q.a?"Correct":"Wrong"}</span></div>`}).join("")}</div><div style="margin-top:18px"><button class="btn" onclick="startQuiz('${quizSession.skill}')">Retake ${quizSession.skill} Quiz</button> <button class="btn light" onclick="render('quizzes')">Choose another quiz</button></div></div>`;
}

const assessmentBanks={
 Python:quizBanks.Python,
 Java:quizBanks.Java,
 "C++":quizBanks["C++"],
 "Data Structures":quizBanks["Data Structures"],
 "Data Analytics":quizBanks["Data Analytics"],
 "AI/ML":quizBanks["AI/ML"],
 "Cloud Computing":quizBanks["Cloud Computing"],
 Communication:quizBanks.Communication
};
let assessmentSession={skill:"Python",index:0,answers:[],rewarded:false};
function assessments(){
 const history=JSON.parse(localStorage.getItem("sg_assessment_history")||"[]");
 return head("Assessments","Choose a skill assessment. A percentage is calculated only after you answer and submit the questions.")+`<div class="grid2"><div class="card"><h3 class="section-title">Choose assessment</h3><div class="list">${Object.keys(assessmentBanks).map(s=>`<div class="list-item"><h4>${s} Assessment</h4><p>${assessmentBanks[s].length} questions • automatic scoring • skill update</p><button class="btn" onclick="startAssessment('${s}')">Take ${s} Assessment</button></div>`).join("")}</div></div><div class="card"><h3 class="section-title">Assessment history</h3>${history.length?`<div class="list">${history.slice().reverse().map(a=>`<div class="list-item"><h4>${a.skill} <span class="pill ${a.score>=70?"green":"red"}">${a.score}%</span></h4><p>${a.date}</p></div>`).join("")}</div>`:`<div class="empty">No assessments completed yet.</div>`}</div></div>`;
}
function startAssessment(skill){assessmentSession={skill,index:0,answers:[],rewarded:false};renderAssessmentQuestion();}
function renderAssessmentQuestion(){
 const qs=assessmentBanks[assessmentSession.skill];const q=qs[assessmentSession.index];const selected=assessmentSession.answers[assessmentSession.index];
 $("content").innerHTML=head(`${assessmentSession.skill} Assessment`,`Question ${assessmentSession.index+1} of ${qs.length}. Answer all questions and submit for a real score.`)+`<div class="card"><span class="pill blue">${assessmentSession.skill} • Assessment</span><h2 style="margin-top:18px">${q.q}</h2><div>${q.o.map((o,i)=>`<button class="quiz-option ${selected===i?"selected":""}" onclick="selectAssessmentAnswer(${i})">${String.fromCharCode(65+i)}. ${o}</button>`).join("")}</div><div style="display:flex;gap:10px;justify-content:space-between;margin-top:20px"><button class="btn light" onclick="assessmentPrev()" ${assessmentSession.index===0?"disabled":""}>← Previous</button><div><button class="btn light" onclick="assessmentNext()">Next →</button><button class="btn gold-btn" onclick="submitAssessment()">Submit Assessment</button></div></div></div>`;
}
function selectAssessmentAnswer(i){assessmentSession.answers[assessmentSession.index]=i;renderAssessmentQuestion();}
function assessmentPrev(){if(assessmentSession.index>0){assessmentSession.index--;renderAssessmentQuestion();}}
function assessmentNext(){const qs=assessmentBanks[assessmentSession.skill];if(assessmentSession.index<qs.length-1){assessmentSession.index++;renderAssessmentQuestion();}else showToast("You are on the last question. Click Submit Assessment.");}
function submitAssessment(){
 const qs=assessmentBanks[assessmentSession.skill];const score=qs.reduce((n,q,i)=>n+(assessmentSession.answers[i]===q.a?1:0),0);const percent=Math.round(score/qs.length*100);const history=JSON.parse(localStorage.getItem("sg_assessment_history")||"[]");history.push({skill:assessmentSession.skill,score:percent,date:new Date().toLocaleString()});localStorage.setItem("sg_assessment_history",JSON.stringify(history));state.assessments=history;state.skills[assessmentSession.skill]=Math.min(100,Math.round(((state.skills[assessmentSession.skill]||0)+percent)/2));save();renderAssessmentResult(percent,score);
}
function renderAssessmentResult(percent,score){
 const qs=assessmentBanks[assessmentSession.skill];$("content").innerHTML=head(`${assessmentSession.skill} Assessment Result`,`You scored ${score}/${qs.length} (${percent}%). The result has been added to your skill graph.`)+`<div class="card"><div class="score-circle">${percent}%</div><div class="list">${qs.map((q,i)=>{const chosen=assessmentSession.answers[i];return `<div class="list-item"><h4>Q${i+1}. ${q.q}</h4><p>Your answer: <strong>${chosen==null?"Not answered":q.o[chosen]}</strong></p><p>Correct answer: <strong>${q.o[q.a]}</strong></p><span class="pill ${chosen===q.a?"green":"red"}">${chosen===q.a?"Correct":"Wrong"}</span></div>`}).join("")}</div><div style="margin-top:18px"><button class="btn" onclick="startAssessment('${assessmentSession.skill}')">Retake Assessment</button> <button class="btn light" onclick="render('assessments')">Back to Assessments</button></div></div>`;
}

const codingProblems=[
 {id:1,title:"Two Sum",difficulty:"Easy",tags:"Array • Hash Map",statement:"Given an integer array nums and a target, return indices of the two numbers whose sum equals target.",example:"Input: nums = [2,7,11,15], target = 9\nOutput: [0,1]",hint:"Store each number and its index in a hash map while scanning the array."},
 {id:2,title:"Valid Parentheses",difficulty:"Easy",tags:"Stack • String",statement:"Given a string containing (), {}, and [], determine whether the brackets are valid and correctly nested.",example:"Input: s = \"{[]}\"\nOutput: true",hint:"Push opening brackets onto a stack and match every closing bracket with the top."},
 {id:3,title:"Best Time to Buy and Sell Stock",difficulty:"Easy",tags:"Array • Greedy",statement:"Given daily stock prices, choose one day to buy and a later day to sell to maximize profit.",example:"Input: [7,1,5,3,6,4]\nOutput: 5",hint:"Track the minimum price seen so far and the best profit."},
 {id:4,title:"Reverse Linked List",difficulty:"Easy",tags:"Linked List",statement:"Reverse a singly linked list and return the new head.",example:"Input: 1 → 2 → 3 → 4 → 5\nOutput: 5 → 4 → 3 → 2 → 1",hint:"Use prev and current pointers; reverse current.next one node at a time."},
 {id:5,title:"Binary Search",difficulty:"Easy",tags:"Array • Binary Search",statement:"Given a sorted array and a target value, return its index, or -1 if it is absent.",example:"Input: nums = [-1,0,3,5,9,12], target = 9\nOutput: 4",hint:"Compare the target with the middle element and discard half the search space."},
 {id:6,title:"Maximum Subarray",difficulty:"Medium",tags:"Array • Dynamic Programming",statement:"Find the contiguous subarray with the largest sum and return that sum.",example:"Input: [-2,1,-3,4,-1,2,1,-5,4]\nOutput: 6",hint:"Kadane's algorithm keeps the best sum ending at the current position."},
 {id:7,title:"Longest Substring Without Repeating Characters",difficulty:"Medium",tags:"String • Sliding Window",statement:"Find the length of the longest substring containing no repeated characters.",example:"Input: s = \"abcabcbb\"\nOutput: 3",hint:"Use a sliding window and remember the most recent index of each character."},
 {id:8,title:"Merge Two Sorted Lists",difficulty:"Easy",tags:"Linked List • Two Pointers",statement:"Merge two sorted linked lists into one sorted linked list.",example:"Input: 1→2→4 and 1→3→4\nOutput: 1→1→2→3→4→4",hint:"Use a dummy node and repeatedly attach the smaller current node."},
 {id:9,title:"Palindrome Number",difficulty:"Easy",tags:"Math",statement:"Determine whether a non-negative integer reads the same from left to right and right to left.",example:"Input: 121\nOutput: true",hint:"Reverse half of the digits and compare it with the other half."},
 {id:10,title:"Contains Duplicate",difficulty:"Easy",tags:"Array • Hash Set",statement:"Return true when an integer array contains the same value more than once.",example:"Input: [1,2,3,1]\nOutput: true",hint:"A set can tell you whether a value has already appeared."},
 {id:11,title:"Valid Anagram",difficulty:"Easy",tags:"String • Hash Map",statement:"Check whether two lowercase strings contain exactly the same letters with the same frequencies.",example:'Input: s="anagram", t="nagaram"\nOutput: true',hint:"Count character frequencies in both strings."},
 {id:12,title:"Climbing Stairs",difficulty:"Easy",tags:"Dynamic Programming",statement:"Count how many distinct ways there are to reach step n when each move is one or two steps.",example:"Input: n=5\nOutput: 8",hint:"The number of ways follows the Fibonacci-style recurrence dp[i]=dp[i-1]+dp[i-2]."},
 {id:13,title:"Majority Element",difficulty:"Easy",tags:"Array • Boyer-Moore",statement:"Find the value that occurs more than half the time in an array, assuming such a value exists.",example:"Input: [2,2,1,1,1,2,2]\nOutput: 2",hint:"Try the Boyer-Moore voting algorithm."},
 {id:14,title:"Move Zeroes",difficulty:"Easy",tags:"Array • Two Pointers",statement:"Move every zero to the end while keeping the relative order of non-zero elements.",example:"Input: [0,1,0,3,12]\nOutput: [1,3,12,0,0]",hint:"Write non-zero values forward, then fill the remaining positions with zeroes."},
 {id:15,title:"Intersection of Two Arrays",difficulty:"Easy",tags:"Array • Hash Set",statement:"Return the unique values that appear in both integer arrays.",example:"Input: [1,2,2,1], [2,2]\nOutput: [2]",hint:"Put one array in a set and scan the other."},
 {id:16,title:"Reverse String",difficulty:"Easy",tags:"String • Two Pointers",statement:"Reverse a character array in place without creating another character array.",example:"Input: [h,e,l,l,o]\nOutput: [o,l,l,e,h]",hint:"Swap characters from the two ends toward the center."},
 {id:17,title:"First Unique Character",difficulty:"Easy",tags:"String • Counting",statement:"Return the index of the first character that appears exactly once, or -1 if none exists.",example:'Input: "leetcode"\nOutput: 0',hint:"Count first, then scan the string again."},
 {id:18,title:"Flood Fill",difficulty:"Easy",tags:"Matrix • DFS/BFS",statement:"Starting from a cell, recolor every connected cell with the same original color.",example:"Input: image=[[1,1,1],[1,1,0]], start=(0,0), color=2\nOutput: all connected 1s become 2",hint:"Use DFS or BFS in four directions."},
 {id:19,title:"Binary Tree Level Order Traversal",difficulty:"Medium",tags:"Tree • BFS",statement:"Return the values of a binary tree grouped by depth from the root downward.",example:"Input: [3,9,20,null,null,15,7]\nOutput: [[3],[9,20],[15,7]]",hint:"Use a queue and process one level at a time."},
 {id:20,title:"Number of Islands",difficulty:"Medium",tags:"Graph • DFS/BFS",statement:"Count groups of horizontally or vertically connected land cells in a grid of 1s and 0s.",example:"Input: 1 1 0 / 0 1 0 / 1 0 1\nOutput: 3",hint:"When you find land, run DFS/BFS and mark the whole island visited."},
 {id:21,title:"Product of Array Except Self",difficulty:"Medium",tags:"Array • Prefix/Suffix",statement:"For each position, return the product of every array value except the value at that position, without division.",example:"Input: [1,2,3,4]\nOutput: [24,12,8,6]",hint:"Multiply a prefix product with a suffix product."},
 {id:22,title:"Top K Frequent Elements",difficulty:"Medium",tags:"Hash Map • Heap",statement:"Return the k values with the highest frequencies in an integer array.",example:"Input: [1,1,1,2,2,3], k=2\nOutput: [1,2]",hint:"Count frequencies, then use buckets or a heap to keep the largest k."},
 {id:23,title:"Group Anagrams",difficulty:"Medium",tags:"String • Hash Map",statement:"Group words that are anagrams of one another into separate lists.",example:"Input: [eat,tea,tan,ate,nat,bat]\nOutput: [[eat,tea,ate],[tan,nat],[bat]]",hint:"Use the sorted letters or a frequency signature as the map key."},
 {id:24,title:"Longest Palindromic Substring",difficulty:"Medium",tags:"String • Two Pointers",statement:"Find the longest contiguous substring that is a palindrome.",example:'Input: "babad"\nOutput: "bab" or "aba"',hint:"Expand around every possible center."},
 {id:25,title:"3Sum",difficulty:"Medium",tags:"Array • Two Pointers",statement:"Find all unique triples whose values add up to zero.",example:"Input: [-1,0,1,2,-1,-4]\nOutput: [[-1,-1,2],[-1,0,1]]",hint:"Sort the array, fix one value, and solve the remaining two-sum with two pointers."},
 {id:26,title:"Container With Most Water",difficulty:"Medium",tags:"Array • Two Pointers",statement:"Choose two vertical lines that hold the maximum amount of water.",example:"Input: [1,8,6,2,5,4,8,3,7]\nOutput: 49",hint:"Start at both ends and move the pointer at the shorter line."},
 {id:27,title:"Search in Rotated Sorted Array",difficulty:"Medium",tags:"Array • Binary Search",statement:"Search for a target in a sorted array that has been rotated at an unknown pivot.",example:"Input: [4,5,6,7,0,1,2], target=0\nOutput: 4",hint:"At each step, one half is guaranteed to remain sorted."},
 {id:28,title:"Min Stack",difficulty:"Medium",tags:"Stack • Design",statement:"Design a stack that supports push, pop, top and retrieving the minimum value in constant time.",example:"Operations: push(-2), push(0), push(-3), getMin()\nOutput: -3",hint:"Store the current minimum alongside stack values or use a second stack."},
 {id:29,title:"Coin Change",difficulty:"Medium",tags:"Dynamic Programming",statement:"Given coin denominations and a target amount, return the minimum number of coins needed, or -1 if impossible.",example:"Input: coins=[1,2,5], amount=11\nOutput: 3",hint:"Build dp[amount] using the best answer for smaller amounts."},
 {id:30,title:"LRU Cache",difficulty:"Medium",tags:"Hash Map • Linked List",statement:"Design a cache with get and put operations where the least recently used item is removed first when capacity is reached.",example:"Capacity=2; put(1), put(2), get(1), put(3)\nResult: key 2 is evicted",hint:"Combine a hash map with a doubly linked list for O(1) updates."}
];
let selectedCodingProblem=1;
function codingProblemsPage(){
 const p=codingProblems.find(x=>x.id===selectedCodingProblem)||codingProblems[0];
 return head("Coding Problems","Practice interview-style problems similar to LeetCode. Read the problem, example and hint, then solve it in the Online Compiler.",`<button class="btn gold-btn" onclick="render('compiler')">Open Compiler →</button>`)+
 `<div class="grid2"><div class="card"><h3 class="section-title">Problem Set</h3><div class="list">${codingProblems.map(x=>`<button class="list-item" style="width:100%;text-align:left;cursor:pointer;border:0;background:${x.id===p.id?'var(--surface-2)':'transparent'}" onclick="selectCodingProblem(${x.id})"><h4>${x.id}. ${x.title} <span class="pill ${x.difficulty==='Medium'?'gold':'green'}">${x.difficulty}</span></h4><p>${x.tags}</p></button>`).join('')}</div></div><div class="card"><span class="pill blue">${p.difficulty}</span><h2 style="margin:14px 0 8px">${p.title}</h2><p>${p.statement}</p><h3>Example</h3><pre class="output" style="margin-top:8px">${p.example}</pre><h3 style="margin-top:18px">Hint</h3><p class="muted">${p.hint}</p><button class="btn gold-btn" onclick="render('compiler')">Solve in Compiler</button></div></div>`;
}
function selectCodingProblem(id){selectedCodingProblem=id;render('coding');}

const compilerLanguages={Python:{id:71,version:"3.8.1",name:"Python"},Java:{id:62,version:"13.0.1",name:"Java"},C:{id:50,version:"9.2.0",name:"C"},"C++":{id:54,version:"9.2.0",name:"C++"},JavaScript:{id:63,version:"12.14.0",name:"JavaScript"}};
let selectedCompilerLanguage="Python";
function compiler(){
 return head("Online Compiler","Run your own code and see real output, compilation errors and runtime errors. The execution service is sandboxed.",`<button class="btn gold-btn" onclick="runCode()">Run ▶</button>`)+`<div class="card compiler"><div class="lang-list">${Object.keys(compilerLanguages).map((l,i)=>`<button class="${i===0?"active":""}" onclick="selectLang(this,'${l}')">${l}</button>`).join("")}<button onclick="selectLang(this,'HTML/CSS')">HTML/CSS</button></div><textarea id="code" class="code-area">print("Hello, Student Skill Graph!")</textarea><div class="compiler-output-head"><strong>Output / Errors</strong><span id="runStatus" class="pill blue">Ready</span></div><pre id="output" class="output">Run your code to see the actual output or error message.</pre></div>`;
}
function selectLang(btn,lang){document.querySelectorAll(".lang-list button").forEach(x=>x.classList.remove("active"));btn.classList.add("active");selectedCompilerLanguage=lang;const examples={Python:'print("Hello, Student Skill Graph!")',Java:'public class Main { public static void main(String[] args) { System.out.println("Hello, Student Skill Graph!"); } }',C:'#include <stdio.h>\nint main(){ printf("Hello, Student Skill Graph!\\n"); return 0; }',"C++":'#include <iostream>\nusing namespace std;\nint main(){ cout << "Hello, Student Skill Graph!\\n"; return 0; }',JavaScript:'console.log("Hello, Student Skill Graph!");','HTML/CSS':'<!doctype html>\n<html><body><h1>Hello, Student Skill Graph!</h1></body></html>'};$("code").value=examples[lang]||"";$("output").textContent=lang==="HTML/CSS"?"Click Run to preview your HTML.":"Run your code to see the actual output or error message.";}
async function runCode(){
 const code=$("code").value;const out=$("output");const status=$("runStatus");if(!code.trim()){out.textContent="Error: code is empty.";status.textContent="Error";return}
 status.textContent="Running…";out.textContent="Compiling/executing your code…";
 if(selectedCompilerLanguage==="HTML/CSS"){
   out.textContent="HTML/CSS preview is opened below.\n";const old=document.getElementById("htmlPreview");if(old)old.remove();const iframe=document.createElement("iframe");iframe.id="htmlPreview";iframe.style="width:100%;height:260px;background:white;border:1px solid #ddd;border-radius:10px;margin-top:12px";iframe.srcdoc=code;out.parentElement.after(iframe);status.textContent="Preview";return;
 }
 try{
   const lang=compilerLanguages[selectedCompilerLanguage];
   const response=await fetch("https://ce.judge0.com/submissions/?base64_encoded=false&wait=true",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({source_code:code,language_id:lang.id})});
   const data=await response.json();
   if(!response.ok)throw new Error(data.error||data.message||`Compiler service returned ${response.status}`);
   const output=data.stdout||data.stderr||data.compile_output||data.message||"Program finished with no output.";
   out.textContent=`Status: ${data.status?.description||"Completed"}\n\n${output}`;
   status.textContent=data.status?.description||"Completed";status.className=`pill ${data.status?.id===3?"green":"red"}`;
 }catch(err){out.textContent=`Compiler service error:\n${err.message}\n\nThe compiler API may require authentication or may be temporarily unavailable. For a fully self-hosted version, connect Judge0 on your own server.`;status.textContent="Service error";status.className="pill red";}
}

/* V11 — Duolingo-style language learning */
const languageCourses={
 Spanish:{code:'es-ES',flag:'🇪🇸',greeting:'Hola',lessons:[
  {title:'Greetings',items:[['Hola','Hello'],['Buenos días','Good morning'],['¿Cómo estás?','How are you?'],['Gracias','Thank you']],questions:[['What does "Hola" mean?',['Hello','Goodbye','Please','Sorry'],0],['Choose "Thank you"',['Gracias','Hola','Adiós','Por favor'],0]]},
  {title:'Everyday Phrases',items:[['Por favor','Please'],['Adiós','Goodbye'],['Sí','Yes'],['No','No']],questions:[['What does "Por favor" mean?',['Please','Thanks','Yes','Goodbye'],0],['Which means "Yes"?',['No','Sí','Gracias','Hola'],1]]},
  {title:'Travel',items:[['¿Dónde está la estación?','Where is the station?'],['Necesito ayuda','I need help'],['¿Cuánto cuesta?','How much does it cost?'],['Un café, por favor','A coffee, please']],questions:[['How do you say "I need help"?',['Necesito ayuda','Hola amigo','¿Cuánto cuesta?','Buenos días'],0],['"¿Cuánto cuesta?" means…',['Where is it?','How much does it cost?','Can I help?','What time is it?'],1]]}
 ]},
 French:{code:'fr-FR',flag:'🇫🇷',greeting:'Bonjour',lessons:[
  {title:'Greetings',items:[['Bonjour','Hello / Good morning'],['Bonsoir','Good evening'],['Merci','Thank you'],['Salut','Hi / Bye']],questions:[['What does "Merci" mean?',['Hello','Thank you','Please','Goodbye'],1],['Choose "Good evening"',['Bonjour','Salut','Bonsoir','Merci'],2]]},
  {title:'Everyday Phrases',items:[['S’il vous plaît','Please'],['Oui','Yes'],['Non','No'],['Au revoir','Goodbye']],questions:[['Which means "Please"?',['Oui','Merci','S’il vous plaît','Non'],2],['What does "Au revoir" mean?',['Goodbye','Hello','Sorry','Yes'],0]]},
  {title:'Travel',items:[['Où est la gare ?','Where is the station?'],['J’ai besoin d’aide','I need help'],['Combien ça coûte ?','How much does it cost?'],['Une eau, s’il vous plaît','A water, please']],questions:[['How do you say "I need help"?',['Merci','J’ai besoin d’aide','Où est la gare ?','Salut'],1],['"Combien ça coûte ?" means…',['How much does it cost?','Where is the hotel?','Can I sit?','What is your name?'],0]]}
 ]},
 German:{code:'de-DE',flag:'🇩🇪',greeting:'Hallo',lessons:[
  {title:'Greetings',items:[['Hallo','Hello'],['Guten Morgen','Good morning'],['Danke','Thank you'],['Tschüss','Bye']],questions:[['What does "Danke" mean?',['Hello','Please','Thank you','Bye'],2],['Choose "Good morning"',['Guten Morgen','Hallo','Tschüss','Danke'],0]]},
  {title:'Everyday Phrases',items:[['Bitte','Please / You are welcome'],['Ja','Yes'],['Nein','No'],['Wie geht es dir?','How are you?']],questions:[['What does "Ja" mean?',['No','Yes','Please','Hello'],1],['Which means "How are you?"',['Danke','Bitte','Wie geht es dir?','Tschüss'],2]]},
  {title:'Travel',items:[['Wo ist der Bahnhof?','Where is the station?'],['Ich brauche Hilfe','I need help'],['Wie viel kostet das?','How much does that cost?'],['Ein Wasser, bitte','A water, please']],questions:[['"Ich brauche Hilfe" means…',['I need help','Good morning','Where is the station?','Thank you'],0],['Which phrase asks the price?',['Wo ist der Bahnhof?','Wie viel kostet das?','Ein Wasser, bitte','Hallo'],1]]}
 ]},
 Japanese:{code:'ja-JP',flag:'🇯🇵',greeting:'こんにちは',lessons:[
  {title:'Greetings',items:[['こんにちは','Hello'],['おはようございます','Good morning'],['ありがとう','Thank you'],['さようなら','Goodbye']],questions:[['What does "ありがとう" mean?',['Hello','Thank you','Goodbye','Please'],1],['Choose "Hello"',['さようなら','ありがとう','こんにちは','おはようございます'],2]]},
  {title:'Everyday Phrases',items:[['はい','Yes'],['いいえ','No'],['お願いします','Please'],['元気ですか？','How are you?']],questions:[['Which means "Yes"?',['いいえ','はい','ありがとう','こんにちは'],1],['"お願いします" is used for…',['Please / request','Goodbye','No','Hello'],0]]},
  {title:'Travel',items:[['駅はどこですか？','Where is the station?'],['助けてください','Please help me'],['いくらですか？','How much is it?'],['水をください','Water, please']],questions:[['"助けてください" means…',['Water please','Please help me','Where is the station?','Thank you'],1],['Which asks "How much is it?"',['いくらですか？','駅はどこですか？','水をください','こんにちは'],0]]}
 ]},
 Korean:{code:'ko-KR',flag:'🇰🇷',greeting:'안녕하세요',lessons:[
  {title:'Greetings',items:[['안녕하세요','Hello'],['감사합니다','Thank you'],['안녕히 가세요','Goodbye'],['좋은 아침이에요','Good morning']],questions:[['What does "감사합니다" mean?',['Hello','Thank you','Goodbye','Good morning'],1],['Choose "Hello"',['안녕하세요','감사합니다','안녕히 가세요','네'],0]]},
  {title:'Everyday Phrases',items:[['네','Yes'],['아니요','No'],['부탁합니다','Please'],['괜찮아요','It is okay']],questions:[['Which means "Yes"?',['아니요','네','감사합니다','괜찮아요'],1],['"괜찮아요" means…',['It is okay','Thank you','No','Hello'],0]]},
  {title:'Travel',items:[['역이 어디예요?','Where is the station?'],['도와주세요','Please help me'],['얼마예요?','How much is it?'],['물 주세요','Water, please']],questions:[['"도와주세요" means…',['Water please','Please help me','Goodbye','Where is the station?'],1],['Which asks the price?',['역이 어디예요?','물 주세요','얼마예요?','안녕하세요'],2]]}
 ]},
 Hindi:{code:'hi-IN',flag:'🇮🇳',greeting:'नमस्ते',lessons:[
  {title:'Greetings',items:[['नमस्ते','Hello'],['सुप्रभात','Good morning'],['धन्यवाद','Thank you'],['अलविदा','Goodbye']],questions:[['What does "धन्यवाद" mean?',['Hello','Thank you','Goodbye','Please'],1],['Choose "Hello"',['अलविदा','नमस्ते','धन्यवाद','सुप्रभात'],1]]},
  {title:'Everyday Phrases',items:[['कृपया','Please'],['हाँ','Yes'],['नहीं','No'],['आप कैसे हैं?','How are you?']],questions:[['Which means "Yes"?',['नहीं','हाँ','कृपया','नमस्ते'],1],['"आप कैसे हैं?" means…',['How are you?','Where are you?','Thank you','Goodbye'],0]]},
  {title:'Travel',items:[['स्टेशन कहाँ है?','Where is the station?'],['मुझे मदद चाहिए','I need help'],['यह कितने का है?','How much is this?'],['पानी दीजिए','Water, please']],questions:[['"मुझे मदद चाहिए" means…',['I need help','Water please','Goodbye','Hello'],0],['Which phrase asks the price?',['स्टेशन कहाँ है?','पानी दीजिए','यह कितने का है?','धन्यवाद'],2]]}
 ]},
 Telugu:{code:'te-IN',flag:'🇮🇳',greeting:'నమస్కారం',lessons:[
  {title:'Greetings',items:[['నమస్కారం','Hello'],['శుభోదయం','Good morning'],['ధన్యవాదాలు','Thank you'],['వీడ్కోలు','Goodbye']],questions:[['What does "ధన్యవాదాలు" mean?',['Hello','Thank you','Goodbye','Please'],1],['Choose "Good morning"',['వీడ్కోలు','ధన్యవాదాలు','నమస్కారం','శుభోదయం'],3]]},
  {title:'Everyday Phrases',items:[['దయచేసి','Please'],['అవును','Yes'],['కాదు','No'],['ఎలా ఉన్నారు?','How are you?']],questions:[['Which means "Yes"?',['కాదు','అవును','దయచేసి','నమస్కారం'],1],['"ఎలా ఉన్నారు?" means…',['How are you?','Where is it?','Thank you','Goodbye'],0]]},
  {title:'Travel',items:[['స్టేషన్ ఎక్కడ ఉంది?','Where is the station?'],['నాకు సహాయం కావాలి','I need help'],['ఇది ఎంత?','How much is this?'],['నీరు ఇవ్వండి','Water, please']],questions:[['"నాకు సహాయం కావాలి" means…',['I need help','Water please','Thank you','Where is the station?'],0],['Which asks the price?',['నీరు ఇవ్వండి','ఇది ఎంత?','నమస్కారం','ధన్యవాదాలు'],1]]}
 ]},
 Italian:{code:'it-IT',flag:'🇮🇹',greeting:'Ciao',lessons:[
  {title:'Greetings',items:[['Ciao','Hello / Bye'],['Buongiorno','Good morning'],['Grazie','Thank you'],['Arrivederci','Goodbye']],questions:[['What does "Grazie" mean?',['Hello','Thank you','Please','Goodbye'],1],['Choose "Good morning"',['Ciao','Buongiorno','Grazie','Arrivederci'],1]]},
  {title:'Everyday Phrases',items:[['Per favore','Please'],['Sì','Yes'],['No','No'],['Come stai?','How are you?']],questions:[['Which means "Please"?',['Sì','Per favore','Grazie','No'],1],['"Come stai?" means…',['How are you?','Goodbye','Thank you','What is this?'],0]]},
  {title:'Travel',items:[['Dov’è la stazione?','Where is the station?'],['Ho bisogno di aiuto','I need help'],['Quanto costa?','How much does it cost?'],['Acqua, per favore','Water, please']],questions:[['"Ho bisogno di aiuto" means…',['I need help','Where is the station?','Water please','Thank you'],0],['Which asks the price?',['Acqua, per favore','Quanto costa?','Dov’è la stazione?','Ciao'],1]]}
 ]},
 English:{code:'en-US',flag:'🇬🇧',greeting:'Hello',lessons:[
  {title:'Greetings',items:[['Hello','Hello'],['Good morning','Good morning'],['How are you?','How are you?'],['Thank you','Thank you']],questions:[['Which phrase is a greeting?',['Hello','Goodbye','Sorry','Please'],0],['Which phrase is used to thank someone?',['How are you?','Good night','Thank you','See you'],2]]},
  {title:'Everyday Phrases',items:[['Please','Please'],['Excuse me','Excuse me'],['Sorry','Sorry'],['See you later','See you later']],questions:[['Which phrase is polite when asking for something?',['Please','Sorry','Hello','Goodbye'],0],['Which phrase can you use to get someone’s attention politely?',['See you later','Excuse me','Thank you','Good night'],1]]},
  {title:'Numbers & Time',items:[['one','one'],['two','two'],['today','today'],['tomorrow','tomorrow']],questions:[['What does "today" mean?',['The day before','This day','Next week','Yesterday'],1],['Which word refers to the next day?',['today','yesterday','tomorrow','morning'],2]]},
  {title:'Food & Café',items:[['water','water'],['coffee','coffee'],['I am hungry','I am hungry'],['The bill, please','The bill, please']],questions:[['What would you order to drink?',['water','chair','book','window'],0],['Which phrase asks for the bill?',['I am hungry','Good morning','The bill, please','See you'],2]]},
  {title:'Travel',items:[['Where is the station?','Where is the station?'],['I need help','I need help'],['How much does it cost?','How much does it cost?'],['Turn left','Turn left']],questions:[['Which phrase asks for a station?',['Where is the station?','I need help','Turn left','Thank you'],0],['Which phrase asks about price?',['Turn left','How much does it cost?','Where is the station?','Goodbye'],1]]},
  {title:'Study & Work',items:[['I am studying','I am studying'],['I have an exam','I have an exam'],['Can you explain?','Can you explain?'],['I understand','I understand']],questions:[['Which phrase says you are studying?',['I understand','I am studying','I have an exam','Can you explain?'],1],['Which phrase asks for an explanation?',['I understand','I am studying','Can you explain?','Goodbye'],2]]}
 ]}
};
const englishScratchExamples={
  Greetings:['Hello, my name is Likhitha.','Good morning, Professor.','How are you today?'],
  'Everyday Phrases':['Excuse me, could you help me?','Sorry, I am late.','Please open the door.'],
  'Numbers & Time':['I have two classes today.','The exam is tomorrow.','I will call you at five.'],
  'Food & Café':['Can I have a cup of coffee?','I am hungry after class.','The bill, please.'],
  Travel:['Where is the railway station?','I need help with my luggage.','How much does this ticket cost?'],
  'Study & Work':['I am studying Python today.','I have an exam on Friday.','Can you explain this concept?']
};
Object.keys(languageCourses.English.lessons).forEach(i=>{
  const lesson=languageCourses.English.lessons[i];
  const extra=englishScratchExamples[lesson.title]||[];
  lesson.examples=[...(lesson.examples||[]),...extra.map((e,n)=>`Scratch example ${n+1}: <strong>${e}</strong>` )];
});

let languageState=JSON.parse(localStorage.getItem('sg_language_state')||'null')||{language:'Spanish',lesson:0,xp:0,streak:0,completed:{}};
function saveLanguageState(){localStorage.setItem('sg_language_state',JSON.stringify(languageState));}
function languages(){
 const course=languageCourses[languageState.language];
 return head('Learn Languages','Learn languages with bite-sized lessons, multiple-choice practice and speech recognition — inspired by the flow of language-learning apps.')+
 `<div class="language-hero card"><div><span class="eyebrow">LANGUAGE LAB</span><h2>${course.flag} ${languageState.language}</h2><p class="muted">XP ${languageState.xp} • 🔥 ${languageState.streak} day streak • ${Object.keys(languageState.completed).filter(k=>languageState.completed[k]).length} lessons completed</p></div><div><select id="languageSelect" class="search" onchange="changeLanguage(this.value)">${Object.keys(languageCourses).map(l=>`<option value="${l}" ${l===languageState.language?'selected':''}>${languageCourses[l].flag} ${l}</option>`).join('')}</select></div></div>`+
 `<div class="language-path">${course.lessons.map((l,i)=>`<button class="language-node ${i===languageState.lesson?'active':''} ${languageState.completed[languageState.language+'-'+i]?'done':''}" onclick="openLanguageLesson(${i})"><span>${i+1}</span><strong>${l.title}</strong><small>${languageState.completed[languageState.language+'-'+i]?'✓ Complete':'Practice'}</small></button>`).join('')}</div>`+
 `<div class="grid2"><div class="card"><h3>What you will practice</h3><div class="list"><div class="list-item"><h4>📖 Learn phrases</h4><p>Read the target-language phrase, meaning and example use.</p></div><div class="list-item"><h4>🧠 Multiple choice</h4><p>Answer lesson questions and earn XP for correct answers.</p></div><div class="list-item"><h4>🎙 Speak with speech recognition</h4><p>Say the phrase aloud. Your browser compares your speech transcript with the target phrase.</p></div></div></div><div class="card"><h3>Start learning</h3><p class="muted">Your selected language is ${course.language||languageState.language}. Begin with the current lesson.</p><button class="btn gold-btn" onclick="openLanguageLesson(${languageState.lesson})">Start lesson →</button><button class="btn light" onclick="requestSpeechPermission()">Enable speech recognition</button></div></div>`;
}
function changeLanguage(name){if(!languageCourses[name])return;languageState.language=name;languageState.lesson=0;saveLanguageState();render('languages');}
function openLanguageLesson(i){const course=languageCourses[languageState.language];languageState.lesson=Math.max(0,Math.min(i,course.lessons.length-1));saveLanguageState();const lesson=course.lessons[languageState.lesson];const key=languageState.language+'-'+languageState.lesson;window.currentLanguageQuestion=0;const q=lesson.questions[0];
 $('content').innerHTML=head(`${course.flag} ${languageState.language}: ${lesson.title}`,`Learn, listen, speak and answer. Earn 10 XP for each correct practice answer.`)+
 `<div class="grid2"><div class="card"><h3>📚 Lesson phrases</h3><div class="list">${lesson.items.map((it,idx)=>`<div class="list-item phrase-card"><div><h4>${it[0]}</h4><p>${it[1]}</p></div><button class="btn light" onclick="speakPhrase('${escapeJs(it[0])}','${course.code}')">🔊 Listen</button><button class="btn" onclick="startLanguageSpeech('${escapeJs(it[0])}','${course.code}')">🎙 Speak</button><div id="speechResult${idx}" class="tiny"></div></div>`).join('')}</div></div><div class="card"><span class="pill blue">Multiple Choice</span><h2 style="margin-top:12px" id="langQuestion">${q[0]}</h2><div id="langOptions">${q[1].map((o,idx)=>`<button class="quiz-option" onclick="answerLanguage(${idx})">${String.fromCharCode(65+idx)}. ${o}</button>`).join('')}</div><div id="langFeedback" style="margin-top:12px"></div><div style="margin-top:16px"><button class="btn light" onclick="render('languages')">← Language home</button><button class="btn gold-btn" onclick="completeLanguageLesson()">✓ Complete lesson</button></div></div></div>`;
}
function escapeJs(v){return v.replace(/\\/g,'\\\\').replace(/'/g,"\\'");}
function speakPhrase(text,code){if(!('speechSynthesis' in window)){showToast('Speech synthesis is not supported in this browser.');return}const u=new SpeechSynthesisUtterance(text);u.lang=code;window.speechSynthesis.cancel();window.speechSynthesis.speak(u);}
function requestSpeechPermission(){const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){showToast('Speech recognition is not supported in this browser. Try Chrome or Edge.');return}const r=new SR();r.lang=languageCourses[languageState.language].code;r.interimResults=false;r.maxAlternatives=1;r.onresult=()=>showToast('Speech recognition is enabled.');r.onerror=e=>showToast('Speech recognition message: '+e.error);r.start();}
function normalizeSpeech(v){return v.toLowerCase().normalize('NFD').replace(/[\\u0300-\\u036f]/g,'').replace(/[^\\p{L}\\p{N} ]/gu,'').replace(/\\s+/g,' ').trim();}
function similarity(a,b){a=normalizeSpeech(a);b=normalizeSpeech(b);if(!a||!b)return 0;if(a===b)return 100;const aa=new Set(a.split(' ')),bb=new Set(b.split(' '));let hit=0;aa.forEach(x=>{if(bb.has(x))hit++});return Math.round(hit/Math.max(aa.size,bb.size)*100);}
function startLanguageSpeech(target,code){const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){showToast('Speech recognition is not supported in this browser. Try Chrome or Edge.');return}const r=new SR();r.lang=code;r.interimResults=false;r.maxAlternatives=1;r.onresult=e=>{const heard=e.results[0][0].transcript;const score=similarity(heard,target);showToast(score>=80?'🎉 Great pronunciation match!':'Keep practicing — try saying it again.');const boxes=document.querySelectorAll('.phrase-card');boxes.forEach(box=>{if(box.textContent.includes(target)){const el=box.querySelector('.tiny');if(el)el.textContent=`Heard: ${heard} • Match: ${score}%`;}})};r.onerror=e=>showToast('Speech recognition: '+e.error);r.start();showToast('🎙 Listening… say: '+target);}
function answerLanguage(idx){const lesson=languageCourses[languageState.language].lessons[languageState.lesson];const q=lesson.questions[0];const fb=$('langFeedback');if(!fb)return;const correct=idx===q[2];if(correct){languageState.xp+=10;languageState.streak=Math.max(1,languageState.streak+1);saveLanguageState();fb.innerHTML='<span class="pill green">✓ Correct! +10 XP</span><p class="muted">Nice work. Now say one of the lesson phrases using the 🎙 Speak button.</p>';document.querySelectorAll('#langOptions .quiz-option').forEach(b=>b.disabled=true);}else{fb.innerHTML=`<span class="pill red">✗ Not quite</span><p class="muted">Correct answer: <strong>${q[1][q[2]]}</strong>. Review the phrase list and try again.</p>`;}}
function completeLanguageLesson(){const key=languageState.language+'-'+languageState.lesson;languageState.completed[key]=true;languageState.xp+=20;languageState.streak=Math.max(1,languageState.streak+1);saveLanguageState();showToast('🎉 Language lesson completed! +20 XP');const course=languageCourses[languageState.language];if(languageState.lesson<course.lessons.length-1){languageState.lesson++;saveLanguageState();setTimeout(()=>openLanguageLesson(languageState.lesson),350)}else render('languages');}

const communicationLessons = {
  Grammar: {
    title: "English Grammar",
    intro: "Learn grammar through explanations, many examples and practice. Wrong answers show the correction and why it is correct.",
    lessons: [
      {name:"1. Parts of Speech", desc:"Identify nouns, pronouns, verbs, adjectives, adverbs, prepositions and conjunctions.", examples:["Ravi runs quickly. → Ravi = noun, runs = verb, quickly = adverb.","The beautiful flower is red. → beautiful = adjective, flower = noun.","She and I studied together. → She/I = pronouns, and = conjunction."]},
      {name:"2. Sentence Structure", desc:"Build clear subject + verb + object sentences and questions.", examples:["I read books. → Subject: I, Verb: read, Object: books.","She is studying English. → Subject: She, Verb phrase: is studying, Object: English.","Did you finish the project? → Question word order uses the helping verb before the subject."]},
      {name:"3. Tenses", desc:"Practice present, past and future forms.", examples:["Present: I study every day.","Past: I studied yesterday.","Future: I will study tomorrow.","Present continuous: I am studying now."]},
      {name:"4. Articles", desc:"Use a, an and the correctly.", examples:["I saw a dog. → a before a consonant sound.","She ate an apple. → an before a vowel sound.","The sun is bright. → the for a specific/unique thing."]},
      {name:"5. Subject-Verb Agreement", desc:"Match the verb with a singular or plural subject.", examples:["He works every day. ✓","They work every day. ✓","He work every day. ✗ → He works every day."]},
      {name:"6. Prepositions", desc:"Practice in, on, at, to, from, for, with and other common prepositions.", examples:["I live in India. → country/place.","The class starts at 9 AM. → exact time.","The book is on the table. → surface."]}
    ],
    practice: [
      [["Choose the correct sentence.",["She go to college every day.","She goes to college every day.","She going to college every day.","She gone to college every day."],1,"Use 'goes' because 'she' is a singular third-person subject."],["Identify the verb: 'The students completed the assignment.'",["students","completed","assignment","the"],1,"'Completed' tells what the students did, so it is the verb."],["Which word is an adjective in 'She has a beautiful voice.'",["She","has","beautiful","voice"],2,"'Beautiful' describes the noun 'voice', so it is an adjective."]],
      [["Choose the correct sentence.",["I read books.","Read I books.","Books I read.","I books read."],0,"The normal basic order is subject + verb + object: I + read + books."],["Choose the correct question.",["You are ready?","Are you ready?","Ready are you?","You ready are?"],1,"In a yes/no question, the helping verb 'are' comes before the subject 'you'."],["In 'They play football', what is the object?",["They","play","football","none"],2,"'Football' receives the action of the verb 'play'."]],
      [["Which sentence is in the past tense?",["They play cricket.","They are playing cricket.","They played cricket.","They will play cricket."],2,"'Played' shows an action completed in the past."],["Choose the future sentence.",["I visit my friend yesterday.","I am visiting now.","I visited last week.","I will visit tomorrow."],3,"'Will visit' expresses a future action."],["Choose the present continuous sentence.",["She studies every day.","She studied yesterday.","She is studying now.","She will study tomorrow."],2,"Present continuous uses am/is/are + verb-ing for an action happening now."]],
      [["Choose the correct article: I saw ___ elephant.",["a","an","the","no article"],1,"Use 'an' before the vowel sound at the start of 'elephant'."],["Choose the correct sentence.",["I have a umbrella.","I have an umbrella.","I have the umbrella always.","I have an umbrellas."],1,"'Umbrella' begins with a vowel sound, so 'an' is used."],["Which sentence uses 'the' naturally for a specific item?",["Give me a pen.","I saw a car.","Please close the door.","She wants an apple."],2,"'The door' refers to a specific door understood in the situation."]],
      [["Choose the correct sentence.",["He work hard.","He works hard.","He working hard.","He workings hard."],1,"'He' is singular, so the present-simple verb takes -s: works."],["Choose the correct sentence.",["They works here.","They working here.","They work here.","They workes here."],2,"'They' is plural, so the base verb 'work' is used."],["Complete: My brother ___ football every Sunday.",["play","plays","playing","played"],1,"'My brother' is singular, so the present-simple verb is 'plays'."]],
      [["Choose the correct preposition: I live ___ India.",["at","in","on","to"],1,"Use 'in' for a country, city or larger area."],["Choose the correct sentence.",["The class starts in 9 AM.","The class starts on 9 AM.","The class starts at 9 AM.","The class starts to 9 AM."],2,"Use 'at' for an exact clock time."],["The phone is ___ the table.",["on","at","from","to"],0,"Use 'on' when something is positioned on a surface."]]
    ]
  },
  Vocabulary: {
    title:"English Vocabulary", intro:"Build vocabulary with multiple examples, context and immediate explanations for wrong answers.",
    lessons:[
      {name:"1. Everyday Vocabulary",desc:"Learn common words used in college and daily conversations.",examples:["Attend = go to an event or class. Example: I attend college every day.","Improve = make something better. Example: I want to improve my English.","Schedule = a plan of times and activities. Example: Check your class schedule."]},
      {name:"2. Synonyms and Antonyms",desc:"Learn words with similar and opposite meanings.",examples:["Rapid ↔ quick (synonyms).","Ancient ↔ modern (antonyms).","Begin ↔ start (synonyms)."]},
      {name:"3. Academic Vocabulary",desc:"Use useful words for assignments and presentations.",examples:["Analyze = examine carefully. Example: Analyze the data.","Evaluate = judge using evidence. Example: Evaluate the results.","Summarize = give the main points briefly. Example: Summarize the chapter."]},
      {name:"4. Professional Vocabulary",desc:"Use clear workplace vocabulary.",examples:["Deadline = the final time to finish something.","Collaborate = work together.","Feedback = comments that help improve work."]},
      {name:"5. Interview Vocabulary",desc:"Use professional words when describing yourself and your projects.",examples:["Strength = a skill you perform well.","Achievement = something important you successfully completed.","Experience = knowledge gained through doing something."]},
      {name:"6. Context Practice",desc:"Learn to select the correct word from the sentence meaning.",examples:["We need to analyze the results before deciding.","Please summarize the report in two minutes.","I can collaborate with my team to complete the project."]}
    ],
    practice:[
      [["Which word is closest in meaning to 'rapid'?",["Slow","Quick","Weak","Quiet"],1,"'Quick' means happening or moving fast, so it is a synonym of rapid."],["Which word is the opposite of 'ancient'?",["Old","Historic","Modern","Traditional"],2,"'Modern' refers to the present or recent period, opposite to ancient."],["Choose the best word: I want to ___ my communication skills.",["improve","erase","hide","damage"],0,"'Improve' means make something better, which fits the sentence."]],
      [["Which is a synonym of 'begin'?",["Finish","Start","Stop","Delay"],1,"'Start' and 'begin' have the same basic meaning."],["Which is an antonym of 'difficult'?",["Hard","Complex","Easy","Tough"],2,"'Easy' has the opposite meaning of difficult."],["Which pair contains synonyms?",["hot / cold","begin / start","old / new","fast / slow"],1,"'Begin' and 'start' both mean to commence something."]],
      [["What does 'analyze' mean?",["Ignore information","Examine carefully","Delete data","Guess randomly"],1,"Analyze means to examine information carefully to understand it."],["What does 'summarize' mean?",["Give the main points briefly","Copy every word","Change the topic","Add unrelated details"],0,"A summary gives the important points in a shorter form."],["Choose the best word: Please ___ the results before the presentation.",["evaluate","sleep","borrow","erase"],0,"Evaluate means judge or assess something using evidence or criteria."]],
      [["What is a deadline?",["A final time for completion","A team member","A meeting room","A job title"],0,"A deadline is the final date or time by which something should be completed."],["What does collaborate mean?",["Work alone","Work together","Avoid work","Cancel a task"],1,"Collaborate means work together toward a shared goal."],["What is useful feedback?",["Random criticism","Information that helps improve work","A password","A deadline"],1,"Useful feedback points out what can be improved and how."]],
      [["Which word can describe something you successfully completed?",["Achievement","Delay","Problem","Weakness"],0,"An achievement is something successfully accomplished."],["Which phrase is professional in an interview?",["I don't know anything.","My strength is problem solving.","Whatever you want.","I just need any job."],1,"This clearly and professionally describes a positive skill."],["What does experience mean?",["Knowledge gained through doing something","A random guess","A future plan","A job application"],0,"Experience is knowledge or skill gained from doing or encountering something."]],
      [["Choose the best word: We need to ___ the results before making a decision.",["analyze","sleep","borrow","erase"],0,"Analyze fits because results should be examined before making a decision."],["Choose the best word: Please ___ the report in two minutes.",["summarize","destroy","forget","hide"],0,"Summarize means present the main points briefly."],["Choose the best word: We will ___ with the design team.",["collaborate","erase","avoid","interrupt"],0,"Collaborate means work together, which fits the team context."]]
    ]
  },
  Speaking:{title:"Speaking Practice",intro:"Practice speaking clearly from basic introductions to project explanations.",lessons:[
    {name:"1. Self Introduction",desc:"Learn a simple opening for college and interviews.",examples:["Hello, my name is Likhitha. I am a third-year CSE student.","I am interested in cloud computing and software development.","Currently, I am working on a Student Skill Graph project."]},
    {name:"2. Daily Conversation",desc:"Practice natural questions and answers.",examples:["How are you? → I'm doing well, thank you.","What are you studying? → I'm studying Computer Science Engineering.","What are you working on? → I'm working on a cloud-based project."]},
    {name:"3. Explain a Topic",desc:"Use introduction, points and conclusion.",examples:["Start: Today I would like to explain cloud computing.","Body: First, cloud computing provides computing resources over the internet.","End: So, cloud computing helps organizations scale resources when needed."]},
    {name:"4. Interview Speaking",desc:"Answer common interview questions clearly.",examples:["Tell me about yourself → education + skills + project + goal.","What is your strength? → Give one strength and one example.","Why should we select you? → Connect your skills to the role."]}
  ],practice:[
    [["Which is a clear interview opening?",["Hello, my name is Likhitha and I am a CSE student.","Myself Likhitha only.","I don't know what to say.","You tell me."],0,"Use a complete sentence with your name and relevant background."],["What should come after your name in a self-introduction?",["Only your phone number","Education or current role","An unrelated joke","A long apology"],1,"Brief education or role gives the listener useful context."],["Which ending sounds professional?",["That's it, bye.","Thank you for listening. I am happy to answer questions.","Whatever.","I finished."],1,"It politely closes the introduction and invites questions."]],
    [["Choose a natural response to 'How are you?'",["I'm doing well, thank you.","I am a book.","Yesterday.","Computer."],0,"This directly answers the question politely."],["Choose a clear response to 'What are you studying?'",["I'm studying Computer Science Engineering.","At 9 AM.","Very quickly.","Because yes."],0,"It directly states the field of study."],["Which question keeps a conversation going?",["What are you working on?","Close the door.","Give me that.","No."],0,"An open question invites the other person to explain their work."]],
    [["Which is a good presentation opening?",["Today I would like to explain cloud computing.","Cloud. That's all.","I don't know this topic.","Let's finish quickly."],0,"It clearly tells the audience the topic."],["What should the body contain?",["Main points and examples","Only an apology","No information","Random words"],0,"The body explains the topic using organized points and examples."],["Which is a suitable conclusion?",["So, these are the main benefits. Thank you.","I forgot everything.","End.","No more."],0,"A short summary and thanks provide a clear ending."]],
    [["What is a good answer structure for 'Tell me about yourself'?",["Education + skills + project + goal","Only family details","Only hobbies","One word"],0,"This structure gives relevant professional information in a logical order."],["What should you do when describing a strength?",["Give a strength and an example","Only say 'I am perfect'","Avoid examples","Change the topic"],0,"An example makes the strength more believable and specific."],["Which answer is more professional?",["I am good at teamwork; in my project I coordinated tasks with my team.","I'm best at everything.","No idea.","Because I'm good."],0,"It names a skill and supports it with a concrete example."]]
  ]},
  Listening:{title:"Listening Practice",intro:"Improve listening by identifying key information, keywords and the speaker's main idea.",lessons:[
    {name:"1. Listening for Keywords",desc:"Listen for names, numbers, places and important terms.",examples:["If you hear 'The meeting is at 10 AM', focus on the time 10 AM.","If you hear 'Submit the assignment on Monday', identify Monday as the deadline.","If you hear 'The project uses Python and Flask', identify the technologies."]},
    {name:"2. Main Idea",desc:"Find the central message instead of every individual word.",examples:["A speaker explains benefits of cloud storage → main idea: advantages of cloud storage.","A teacher explains three causes of pollution → main idea: causes of pollution.","A project demo explains features → main idea: what the project does."]},
    {name:"3. Note Taking",desc:"Write short keywords rather than full sentences.",examples:["Lecture: Cloud = scalable, pay-as-you-go, internet → notes: scalable / pay-as-you-go / internet.","Interview: Python, SQL, project → notes: skills + project.","Meeting: Friday, 3 PM, Room 204 → notes: Fri / 3 PM / R204."]}
  ],practice:[
    [["If a speaker says 'The meeting starts at 10 AM', what keyword should you note?",["Meeting","10 AM","Speaker","Starts"],1,"The exact time is the key detail needed for the meeting."],["What should you focus on when listening for keywords?",["Important names, numbers and terms","Every single word","Only the speaker's accent","Background noise"],0,"Keywords carry the information you need to remember."],["If you hear 'Submit on Monday', what is important?",["Monday","The word submit only","The speaker's name","Nothing"],0,"Monday is the deadline detail."]],
    [["What is the main idea?",["The central message","Every small word","Only one example","The speaker's accent"],0,"The main idea is the central message of the talk."],["A talk explains benefits of cloud storage. What should you identify?",["The main benefits of cloud storage","Only the greeting","The room number","The speaker's clothes"],0,"The topic and its main benefits are central to the talk."],["Why is identifying the main idea useful?",["It helps understand the overall message","It makes you ignore everything","It removes the need to listen","It changes the topic"],0,"The main idea helps you understand what the speaker is communicating overall."]],
    [["What is better for quick notes?",["Short keywords","Every sentence word-for-word","A full essay","Nothing"],0,"Short keywords are faster to write and easier to review."],["Which notes are best for 'Friday, 3 PM, Room 204'?",["Fri / 3 PM / R204","A very long paragraph","Friday is a day of the week","Nothing"],0,"The short version preserves the important meeting details."],["What should notes capture?",["Important facts and keywords","Every filler word","Only jokes","Unrelated details"],0,"Notes should preserve information that helps you remember the content."]]
  ]},
  Writing:{title:"English Writing",intro:"Learn how to write clear sentences, paragraphs, emails and project descriptions.",lessons:[
    {name:"1. Sentence Writing",desc:"Write complete sentences with correct grammar and punctuation.",examples:["Weak: 'Because the project.' → Incomplete.","Better: 'I completed the project because I practiced every day.'","Use a capital letter at the start and punctuation at the end."]},
    {name:"2. Paragraph Writing",desc:"Build a paragraph with topic sentence, supporting points and conclusion.",examples:["Topic: Cloud computing is useful for students.","Support: Students can use cloud storage, virtual machines and online services.","Conclusion: Therefore, cloud skills are useful for modern projects."]},
    {name:"3. Professional Email",desc:"Write a clear subject, greeting, purpose and polite closing.",examples:["Subject: Request for Project Review","Dear Sir/Madam, I am writing to request a review of my project.","Thank you for your time. Regards, Likhitha."]},
    {name:"4. Project Description",desc:"Explain problem, solution, technologies and result.",examples:["Problem: Students struggle to track their skills.","Solution: A cloud-based platform creates a personalized skill graph.","Technologies: Flask, JavaScript and Google Cloud."]}
  ],practice:[
    [["Which is a complete sentence?",["Because the project.","I completed the project.","After the class.","Running quickly."],1,"A complete sentence has a subject and a predicate expressing a complete thought."],["What should begin a sentence?",["A capital letter","A comma","A number always","A question mark"],0,"Standard sentences begin with a capital letter."],["Which punctuation can end a statement?",[".",",",":","-"],0,"A period commonly ends a declarative statement."]],
    [["What should a topic sentence do?",["Introduce the main idea","End every paragraph","List random words","Hide the topic"],0,"The topic sentence tells the reader the paragraph's main idea."],["What supports a main idea?",["Relevant examples and details","Unrelated jokes","Random numbers","No information"],0,"Supporting details explain or prove the main idea."],["What can a conclusion do?",["Wrap up the main idea","Introduce an unrelated topic","Remove all details","Start a new essay"],0,"A conclusion closes the paragraph by reinforcing the main point."]],
    [["What belongs in an email subject?",["A short description of the purpose","Your whole essay","Only 'Hi'","Nothing"],0,"The subject should quickly tell the reader why you are writing."],["Which greeting is professional?",["Dear Sir/Madam,","Hey dude,","Yo,","What's up!!!"],0,"'Dear Sir/Madam' is a formal greeting when the recipient's name is unknown."],["Which closing is professional?",["Regards,","Bye bro,","Later!!!","Whatever"],0,"'Regards' is a common professional email closing."]],
    [["What should a project description explain first?",["The problem or need","A random joke","Only your name","Nothing"],0,"Starting with the problem makes the purpose of the project clear."],["Which technology list is clear?",["Flask, JavaScript, Google Cloud","Things and stuff","Many tools","Nothing"],0,"Specific technology names communicate the implementation clearly."],["What can the result section describe?",["What the project achieved","Your favorite movie","An unrelated topic","Only the title"],0,"The result explains the outcome or benefit of the project."]]
  ]},
  "Interview English":{title:"Interview English",intro:"Practice introductions, strengths, project explanations and common interview answers.",lessons:[
    {name:"1. Tell Me About Yourself",desc:"Use a 30–60 second structure.",examples:["Hello, I'm Likhitha, a third-year CSE student at AITAM.","I have been learning Java, cloud computing and web development.","I am currently building a Student Skill Graph project, and my goal is to grow as a software developer."]},
    {name:"2. Strengths and Weaknesses",desc:"Give honest, specific and improvement-focused answers.",examples:["Strength: 'I learn quickly. For example, I recently learned a new cloud service for my project.'","Weakness: 'I sometimes spend too long perfecting details, so I now set time limits for tasks.'","Avoid: 'I have no weaknesses.'"]},
    {name:"3. Project Explanation",desc:"Explain problem, solution, technology and your contribution.",examples:["Problem: Students need personalized learning paths.","Solution: Our platform analyzes skills and recommends learning.","My role: I worked on the learning flow, quizzes and dashboard."]},
    {name:"4. Common Questions",desc:"Practice why this role, teamwork and future goals.",examples:["Why this role? → Connect your interests and skills to the role.","Teamwork? → Give a real team example.","Where do you see yourself? → Describe a realistic learning/career direction."]}
  ],practice:[
    [["Which is the strongest self-introduction?",["I am Likhitha, a CSE student with cloud and programming interests, and I am building a project.","Myself Likhitha.","I need a job.","I have nothing to say."],0,"A strong introduction gives your background, relevant skills and current work."],["How long should a basic self-introduction usually be?",["30–60 seconds","10 minutes","One word","No limit"],0,"A concise 30–60 second introduction gives enough context without becoming too long."],["What should you mention about your current project?",["Its purpose and your contribution","Only the color","Nothing","Only the project name"],0,"The purpose and your contribution show what you actually worked on."]],
    [["What makes a weakness answer useful?",["A real weakness plus how you are improving","Saying you have no weaknesses","Blaming others","Avoiding the question"],0,"An improvement-focused answer shows awareness and action."],["Which strength answer is stronger?",["I learn quickly; I learned a new cloud service for my project.","I am perfect.","Everyone says I am best.","I have many strengths."],0,"A specific example supports the claimed strength."],["Which statement should you avoid?",["I have no weaknesses.","I am improving my time management.","I sometimes over-focus on details.","I use feedback to improve."],0,"Saying you have no weaknesses sounds unrealistic and gives no improvement example."]],
    [["What is a useful project explanation order?",["Problem → solution → technology → contribution","Color → title → joke → end","Only technology","Only result"],0,"This order gives the interviewer a clear story from need to implementation and your role."],["What should you explain about your role?",["What you personally worked on","What your friend did only","Nothing","Only the project logo"],0,"Your personal contribution helps the interviewer understand your experience."],["Why mention technologies?",["To show how the solution was built","To avoid explaining the project","To fill time","For decoration"],0,"Technologies explain the technical implementation."]],
    [["How should you answer 'Why this role?'",["Connect your skills and interests to the role","Because I need money only","I don't know","Any role is fine"],0,"Connecting your skills and interests makes the answer relevant to the position."],["What is a good teamwork answer?",["Give a specific team situation and your contribution","Say 'I am a team player' only","Blame a teammate","Avoid examples"],0,"A specific situation demonstrates teamwork better than a general claim."],["What should a career-goal answer include?",["A realistic direction and skills you want to develop","An unrelated story","Only salary","Nothing"],0,"A clear direction shows what you want to learn and build next."]]
  ]}
};

function communication(){
 const items=Object.keys(communicationLessons);
 return head("English Communication","Build grammar, vocabulary, speaking, listening, writing and interview confidence with lessons, examples and practice.")+`<div class="grid3">${items.map((x,i)=>`<div class="card"><div class="stat-icon">${["Aa","✦","◉","◌","✎","♙"][i]}</div><h3>${x}</h3><p class="muted">${communicationLessons[x].intro}</p><button class="btn" onclick="openCommunicationLesson('${x}')">Open lesson</button></div>`).join("")}</div>`;
}

function openCommunicationLesson(type){
 const data=communicationLessons[type];
 if(!data){showToast("Lesson not found");return;}
 const lessonHtml=data.lessons.map((l,i)=>`<div class="list-item"><h4>${l.name}</h4><p>${l.desc}</p><p class="tiny"><strong>Examples:</strong><br>${l.examples.map(e=>"• "+e).join("<br>")}</p><button class="btn light" onclick="showCommunicationPractice('${type}',${i})">Practice this lesson</button></div>`).join("");
 $("content").innerHTML=head(data.title,data.intro,`<button class="btn light" onclick="render('communication')">← Back to Communication</button>`)+`<div class="grid2"><div class="card"><h3 class="section-title">Lessons & Examples</h3>${lessonHtml}</div><div id="communicationPractice"><div class="card"><h3 class="section-title">Practice</h3><p class="muted">Choose a lesson to start. You will get multiple questions and explanations for mistakes.</p></div></div></div>`;
}

function showCommunicationPractice(type,lessonIndex,questionIndex=0){
 const data=communicationLessons[type];
 const lesson=data.lessons[lessonIndex];
 const questions=data.practice[lessonIndex]||data.practice[0]||[];
 const idx=Math.max(0,Math.min(Number(questionIndex)||0,questions.length-1));
 window._commSession={type,lessonIndex,questions,index:idx,answered:{...(window._commSession?.answered||{})}};
 const examples=lesson.examples||[];
 const q=questions[idx];
 const answeredKey=`${type}|${lessonIndex}|${idx}`;
 const alreadyAnswered=!!window._commSession.answered[answeredKey];
 const progress=Math.round(((idx+1)/questions.length)*100);
 const html=`<div class="card">
   <span class="pill blue">${type} • ${lesson.name}</span>
   <div style="display:flex;justify-content:space-between;align-items:center;margin:12px 0"><strong>Question ${idx+1} of ${questions.length}</strong><span class="pill gold">🪙 ${getRewardPoints()} coins</span></div>
   <div style="height:8px;background:#eee;border-radius:99px;overflow:hidden"><div style="width:${progress}%;height:100%;background:linear-gradient(90deg,#f2b84b,#6b4eff)"></div></div>
   <div class="card" style="margin-top:16px;background:#fafafa"><h4>📚 Examples for this topic</h4>${examples.map((e,i)=>`<p style="margin:8px 0"><strong>Example ${i+1}:</strong> ${e}</p>`).join('')}</div>
   <h3 class="section-title" style="margin-top:18px">${q[0]}</h3>
   <div id="commOptions">${q[1].map((o,i)=>`<button class="btn light" style="display:block;width:100%;text-align:left;margin:8px 0" ${alreadyAnswered?'disabled':''} onclick="checkCommunicationAnswer(${i},${q[2]},'${type}',${idx})">${String.fromCharCode(65+i)}. ${o}</button>`).join('')}</div>
   <div id="commFeedback" style="margin-top:15px"></div>
   <div style="display:flex;justify-content:space-between;gap:10px;margin-top:16px">
     <button class="btn light" onclick="showCommunicationPractice('${type}',${lessonIndex},${Math.max(0,idx-1)})" ${idx===0?'disabled':''}>← Previous</button>
     ${idx<questions.length-1?`<button id="commNext" class="btn" onclick="showCommunicationPractice('${type}',${lessonIndex},${idx+1})">Next Question →</button>`:`<button class="btn gold-btn" onclick="finishCommunicationPractice('${type}',${lessonIndex})">Finish Practice ✓</button>`}
   </div>
   <button class="btn light" style="margin-top:10px" onclick="openCommunicationLesson('${type}')">← Back to ${type} lessons</button>
 </div>`;
 $("communicationPractice").innerHTML=html;
}

function finishCommunicationPractice(type,lessonIndex){
 const session=window._commSession||{};
 const total=session.questions?.length||0;
 const answered=Object.keys(session.answered||{}).filter(k=>k.startsWith(`${type}|${lessonIndex}|`)).length;
 showToast(`Practice complete: ${answered}/${total} questions answered. Your coins are saved.`);
 openCommunicationLesson(type);
}

function checkCommunicationAnswer(selected,correct,type,qIndex){
 const box=$("commFeedback");
 const session=window._commSession||{};
 const questions=session.questions||communicationLessons[type]?.practice[session.lessonIndex]||[];
 const q=questions[qIndex];
 if(!q)return;
 const key=`${type}|${session.lessonIndex}|${qIndex}`;
 if(session.answered?.[key]){showToast('This question was already answered.');return;}
 session.answered=session.answered||{};
 session.answered[key]=true;
 const correctText=q[1][correct];
 const selectedText=q[1][selected];
 const explanation=q[3]||`The correct answer is “${correctText}” because it matches the rule or meaning being tested.`;
 document.querySelectorAll('#commOptions button').forEach(b=>b.disabled=true);
 if(selected===correct){
   box.innerHTML=`<div class="list-item"><span class="pill green">Correct ✓ +5 coins</span><p><strong>Your answer:</strong> ${selectedText}</p><p><strong>Why:</strong> ${explanation}</p><p class="tiny">Your reward balance is now <strong>${getRewardPoints()+5} coins</strong>.</p></div>`;
   addRewardPoints(5,`correct ${type} practice answer`);
 } else {
   box.innerHTML=`<div class="list-item"><span class="pill red">Not quite ✗</span><p><strong>Your answer:</strong> ${selectedText}</p><p><strong>Correct answer:</strong> ${String.fromCharCode(65+correct)}. ${correctText}</p><p><strong>Explanation:</strong> ${explanation}</p></div>`;
 }
 const history=JSON.parse(localStorage.getItem('sg_communication_history')||'[]');
 history.push({type,lesson:communicationLessons[type]?.lessons[session.lessonIndex]?.name||'',question:q[0],selected,correct,correctAnswer:correctText,wasCorrect:selected===correct,coins:selected===correct?5:0,date:new Date().toISOString()});
 localStorage.setItem('sg_communication_history',JSON.stringify(history.slice(-200)));
}

function presentation(){
 const examples=[
  ["Self Introduction","Hello, my name is Likhitha. I am a third-year CSE student at AITAM. I am interested in cloud computing and software development. I am currently working on a Student Skill Graph project. My goal is to improve my technical and communication skills."],
  ["Project Presentation","Good morning everyone. Today I am going to present our Student Skill Graph project. First, I will explain the problem. Then I will explain our solution, technologies, features and future scope. Finally, I will summarize the results."],
  ["Technical Topic","Good morning. Today I would like to explain cloud computing. Cloud computing provides computing resources over the internet. The main benefits are scalability, flexibility and pay-as-you-go usage. In our project, we use cloud services to support the learning platform. Thank you."],
  ["College Seminar","Good morning respected faculty and my dear friends. Our topic today is artificial intelligence. I will first introduce the concept, then discuss applications and finally explain the benefits and limitations. Let us begin with the basic idea."],
  ["Project Demo","Now I will demonstrate our application. First, the student logs in and completes onboarding. Next, the platform creates a personalized roadmap. The student watches lessons, takes quizzes and assessments, and the results update the skill graph. Finally, recommendations are generated based on skill gaps."]
 ];
 return head("Presentation Coach","Learn exactly how to start, what to say, how to structure a presentation and how to correct mistakes. Practice repeatedly until your speech improves.")+
 `<div class="grid2"><div class="card"><h3 class="section-title">How to start your presentation</h3><div class="timeline"><div class="step done"><h4>1. Greet the audience</h4><p>“Good morning respected faculty and my dear friends.”</p></div><div class="step"><h4>2. Introduce yourself</h4><p>“My name is Likhitha, and I am a third-year CSE student.”</p></div><div class="step"><h4>3. State the topic</h4><p>“Today I am going to present our Student Skill Graph project.”</p></div><div class="step"><h4>4. Give the roadmap</h4><p>“I will explain the problem, solution, technologies, features and future scope.”</p></div></div></div>
 <div class="card"><h3 class="section-title">Choose an example</h3><select id="presentationExample" class="field" onchange="loadPresentationExample()">${examples.map((e,i)=>`<option value="${i}">${e[0]}</option>`).join("")}</select><textarea id="speechText" class="field textarea" style="margin-top:12px;min-height:230px" placeholder="Type your presentation here or use the microphone..."></textarea><div style="margin-top:12px"><button class="btn" onclick="loadPresentationExample()">Load example</button> <button class="btn" onclick="startSpeech()">🎙 Start speaking</button> <button class="btn light" onclick="analyzeSpeech()">Check my mistakes</button></div><div id="speechFeedback" style="margin-top:15px"></div></div></div>
 <div class="card" style="margin-top:18px"><h3 class="section-title">What to avoid</h3><div class="grid3"><div class="list-item"><strong>❌ “Myself Likhitha.”</strong><p>✓ Say: “My name is Likhitha.”</p></div><div class="list-item"><strong>❌ “Today I am here to tell about...”</strong><p>✓ Say: “Today I am going to explain...”</p></div><div class="list-item"><strong>❌ “Firstly... secondly... lastly...” without explanation</strong><p>✓ Give one clear point and example for each section.</p></div><div class="list-item"><strong>❌ Speaking too fast</strong><p>✓ Pause after important points and breathe between sections.</p></div><div class="list-item"><strong>❌ Reading every slide word-for-word</strong><p>✓ Explain the slide naturally using your own words.</p></div><div class="list-item"><strong>❌ Ending suddenly</strong><p>✓ Summarize the key point and say “Thank you. I am happy to answer questions.”</p></div></div></div>`;
}

const presentationExamplesCache=[
 ["Self Introduction","Hello, my name is Likhitha. I am a third-year CSE student at AITAM. I am interested in cloud computing and software development. I am currently working on a Student Skill Graph project. My goal is to improve my technical and communication skills."],
 ["Project Presentation","Good morning everyone. Today I am going to present our Student Skill Graph project. First, I will explain the problem. Then I will explain our solution, technologies, features and future scope. Finally, I will summarize the results."],
 ["Technical Topic","Good morning. Today I would like to explain cloud computing. Cloud computing provides computing resources over the internet. The main benefits are scalability, flexibility and pay-as-you-go usage. In our project, we use cloud services to support the learning platform. Thank you."],
 ["College Seminar","Good morning respected faculty and my dear friends. Our topic today is artificial intelligence. I will first introduce the concept, then discuss applications and finally explain the benefits and limitations. Let us begin with the basic idea."],
 ["Project Demo","Now I will demonstrate our application. First, the student logs in and completes onboarding. Next, the platform creates a personalized roadmap. The student watches lessons, takes quizzes and assessments, and the results update the skill graph. Finally, recommendations are generated based on skill gaps."]
];
function loadPresentationExample(){const i=Number($("presentationExample").value||0);$("speechText").value=presentationExamplesCache[i][1];analyzeSpeech();}
function startSpeech(){const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){showToast("Speech recognition is not supported in this browser. You can type your speech instead.");return}const r=new SR();r.lang="en-US";r.interimResults=false;r.continuous=false;r.onresult=e=>{$("speechText").value=Array.from(e.results).map(x=>x[0].transcript).join(" ");analyzeSpeech()};r.onerror=e=>showToast("Microphone error: "+e.error);r.start();showToast("Listening… speak clearly.");}
function analyzeSpeech(){
 const el=$("speechText"),feedback=$("speechFeedback");if(!el||!feedback)return;let text=el.value.trim();if(!text){showToast("Please type or speak a presentation first.");return}
 const original=text; const fixes=[];
 const rules=[
  [/\bmyself\s+([A-Za-z]+)/gi,(m,n)=>`My name is ${n}`,"Use 'My name is ...' instead of 'Myself ...'."],
  [/\btoday\s+i\s+am\s+here\s+to\s+tell\s+about\b/gi,()=>"Today I am going to explain","Say 'explain' or 'present' instead of the unnatural phrase 'tell about'."],
  [/\bdiscuss about\b/gi,()=>"discuss","'Discuss' already includes the meaning of talking about something."],
  [/\bmore better\b/gi,()=>"better","Do not use 'more' with the comparative adjective 'better'."],
  [/\bi am having\b/gi,()=>"I have","For possession, use 'I have' rather than 'I am having'."],
  [/\bhe go\b/gi,()=>"he goes","With 'he/she/it' in the present simple, add -s/-es to the verb."],
  [/\bshe go\b/gi,()=>"she goes","With 'she' in the present simple, use 'goes'."],
  [/\bi has\b/gi,()=>"I have","Use 'have' with 'I'; 'has' is used with he/she/it."],
  [/\bpeople is\b/gi,()=>"people are","'People' is plural, so use 'are'."],
  [/\bstudents is\b/gi,()=>"students are","'Students' is plural, so use 'are'."]
 ];
 for(const [re,repl,why] of rules){if(re.test(text)){text=text.replace(re,repl);fixes.push({why,before:original.match(re)?.[0]||"",after:repl.toString().replace(/^.*=>/,"")});}}
 const words=original.split(/\s+/).filter(Boolean).length;const fillers=(original.match(/\b(um|uh|like|actually|basically|you know)\b/gi)||[]).length;
 if(words<35)fixes.push({why:"Your opening is very short. Add your topic, 2–3 main points and a conclusion.",before:"Short presentation",after:"Add structure + examples."});
 if(fillers>1)fixes.push({why:`You used ${fillers} filler words. Replace them with a short pause.` ,before:"Filler words",after:"Pause instead."});
 if(!/\b(good morning|good afternoon|hello)\b/i.test(original))fixes.push({why:"Start with a greeting when speaking to an audience.",before:"No greeting detected",after:"Good morning everyone."});
 if(!/\b(today|topic|present|explain|project)\b/i.test(original))fixes.push({why:"Clearly state what you are presenting.",before:"Topic not detected",after:"Today I am going to present..."});
 const corrected=text;
 feedback.innerHTML=`<div class="list-item"><h4>Presentation feedback</h4>${fixes.length?`<span class="pill red">${fixes.length} improvement${fixes.length===1?"":"s"}</span><div style="margin-top:10px">${fixes.map(f=>`<p><strong>Correction:</strong> ${f.why}<br><span class="tiny">Suggested: ${f.after}</span></p>`).join("")}</div><p><strong>Practice version:</strong><br>${corrected}</p>`:`<span class="pill green">Looking good ✓</span><p>Your presentation has a clear structure. Keep practicing pace, pauses and confidence.</p>`}<button class="btn light" style="margin-top:8px" onclick="$(\'speechText\').value=${JSON.stringify(corrected)}">Use corrected version</button></div>`;
}
function mentor(){
 return head("Mentor System","Connect learning questions with a mentor workflow. This demo includes mentor profiles and request tracking.")+
 `<div class="grid3">${["Cloud Engineering Mentor","Software Development Mentor","AI/ML Mentor"].map((x,i)=>`<div class="card"><div class="avatar" style="margin-bottom:12px">${["AR","SM","PK"][i]}</div><h3>${x}</h3><p class="muted">Guidance on roadmap, projects, assessments and career preparation.</p><span class="pill green">Available</span><br><button class="btn" style="margin-top:12px" onclick="showToast('Mentor request sent')">Request mentor</button></div>`).join("")}</div>`;
}
function projects(){
 return head("Projects","Apply learned skills by building portfolio projects. Add project details and track what you have completed.",
 `<button class="btn gold-btn" onclick="openProjectForm()">+ Add project</button>`)+
 `<div id="projectArea">${state.projects.length?`<div class="grid3">${state.projects.map((p,i)=>`<div class="card"><span class="pill blue">${p.status||"Planned"}</span><h3>${p.name}</h3><p class="muted">${p.description}</p><p class="tiny" style="text-align:left">Technologies: ${p.tech}<br>Skills: ${p.skills}<br>URL: ${p.url||"Not added"}</p><button class="btn light" onclick="completeProject(${i})">${p.status==="Completed"?"Completed ✓":"Mark complete"}</button></div>`).join("")}</div>`:`<div class="empty">No projects yet. Add a project or let the recommendation engine assign one after you complete a skill.</div>`}</div>`;
}
function openProjectForm(){
 $("projectArea").innerHTML=`<div class="card"><h3 class="section-title">Add project</h3><div class="form-grid"><div class="form-group"><label>PROJECT NAME</label><input id="prName" class="field" placeholder="Cloud Student Skill Graph"></div><div class="form-group"><label>TECHNOLOGIES</label><input id="prTech" class="field" placeholder="Flask, Google Cloud, Firestore"></div><div class="form-group full"><label>DESCRIPTION</label><textarea id="prDesc" class="field textarea" placeholder="Describe what the project does"></textarea></div><div class="form-group"><label>SKILLS USED</label><input id="prSkills" class="field" placeholder="Python, Cloud, SQL"></div><div class="form-group"><label>PROJECT URL</label><input id="prUrl" class="field" placeholder="https://github.com/..."></div></div><button class="btn gold-btn" style="margin-top:15px" onclick="saveProject()">Save project</button> <button class="btn light" onclick="render('projects')">Cancel</button></div>`;
}
function saveProject(){const p={name:$("prName").value||"Untitled Project",tech:$("prTech").value||"Not specified",description:$("prDesc").value||"No description",skills:$("prSkills").value||"Not specified",url:$("prUrl").value,status:"Planned"};state.projects.push(p);save();render("projects");showToast("Project saved")}
function completeProject(i){state.projects[i].status="Completed";save();showToast("Project completed!");render("projects")}
function progress(){
 return head("Progress Tracking","See your learning activity, assessment history and skill improvement over time.")+
 `<div class="grid2"><div class="card"><h3 class="section-title">Skill progress</h3><div class="chart-box" style="height:330px"><canvas id="progressChart"></canvas></div></div><div class="card"><h3 class="section-title">Activity summary</h3>${progressBar("Lessons",Math.min(100,state.completedLessons*8))}${progressBar("Assessments",Math.min(100,state.assessments.length*15))}${progressBar("Projects",Math.min(100,state.projects.filter(p=>p.status==="Completed").length*25))}${progressBar("Quizzes",Math.min(100,state.quizScore*33))}</div></div>`;
}
function certificates(){
 return head("Certificates","Certificates are generated when you complete a skill pathway. You can share the certificate or download/print it.")+
 `<div class="grid2"><div class="card"><div class="certificate"><div class="cert-title">CERTIFICATE</div><p>OF SKILL COMPLETION</p><h2>${state.certificates.length?state.certificates[state.certificates.length-1].skill:"Python Fundamentals"}</h2><div class="cert-name">${state.user.name}</div><p>has successfully completed the guided learning pathway and demonstrated the required learning outcomes.</p><p>${new Date().toLocaleDateString()}</p></div><div style="margin-top:12px;text-align:center"><button class="btn gold-btn" onclick="generateCertificate()">Generate certificate</button> <button class="btn light" onclick="shareCertificate()">Share</button></div></div>
 <div class="card"><h3 class="section-title">Your certificates</h3>${state.certificates.length?`<div class="list">${state.certificates.slice().reverse().map(c=>`<div class="list-item"><h4>${c.skill}</h4><p>Issued ${c.date}</p></div>`).join("")}</div>`:`<div class="empty">Complete a learning pathway to issue your first certificate.</div>`}</div></div>`;
}
function generateCertificate(){const c={skill:"Python Fundamentals",date:new Date().toLocaleDateString()};state.certificates.push(c);save();showToast("Certificate generated!");render("certificates")}
async function shareCertificate(){if(navigator.share){await navigator.share({title:"Student Skill Graph Certificate",text:`${state.user.name} completed a Student Skill Graph certificate.`})}else{await navigator.clipboard?.writeText("Student Skill Graph certificate — "+state.user.name);showToast("Certificate sharing text copied")}}
function completeLesson(skill){state.completedLessons++;state.skills[skill]=Math.min(100,state.skills[skill]+4);save();showToast(`${skill} skill improved by 4%`);render("dashboard")}
function saveProfile(){state.user.name=$("pName").value;state.user.email=$("pEmail").value;state.user.branch=$("pBranch").value;state.user.year=$("pYear").value;state.user.goal=$("pGoal").value;save();setupUser();showToast("Profile updated");render("profile")}
function filterResources(){const q=$("resourceSearch").value.toLowerCase();document.querySelectorAll(".resource").forEach(x=>x.style.display=x.dataset.text.includes(q)?"block":"none")}
function render(page){
 state.activePage=page;document.querySelectorAll(".nav-item").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
 const titles={dashboard:"Dashboard",profile:"Student Profile",skillgraph:"Skill Graph",analysis:"Skill Analysis",recommendations:"Recommendations",roadmap:"Learning Roadmap",resources:"Resources",ask:"Ask Questions",materials:"Study Materials",exams:"Scheduled Exams",assessments:"Assessments",quizzes:"Quizzes",compiler:"Online Compiler",communication:"Communication",presentation:"Presentation Coach",mentor:"Mentor System",projects:"Projects",progress:"Progress Tracking",certificates:"Certificates",rewards:"Rewards"};
 $("pageTitle").textContent=titles[page]||"Dashboard";
 const topbar=document.querySelector(".topbar"); if(topbar && !document.getElementById("coinBadge")){const b=document.createElement("span");b.id="coinBadge";b.className="pill gold";b.style.marginLeft="12px";topbar.querySelector(".crumb")?.appendChild(b);} if(document.getElementById("coinBadge"))document.getElementById("coinBadge").textContent=`🪙 ${getRewardPoints()} coins`;
 const pages={dashboard,profile,skillgraph,analysis,recommendations,roadmap,resources:resourcesPage,ask:askQuestions,assessments,quizzes,compiler,coding:codingProblemsPage,communication,presentation,mentor,projects,progress,certificates,rewards};
 $("content").innerHTML=(pages[page]||dashboard)();
 if(page==="dashboard")drawDashboardCharts();
 if(page==="skillgraph")drawRadar();
 if(page==="progress")drawProgress();
}
function chartDefaults(){return {responsive:true,maintainAspectRatio:false,plugins:{legend:{labels:{font:{size:10}}}},scales:{x:{grid:{display:false},ticks:{font:{size:9}}},y:{beginAtZero:true,max:100,ticks:{font:{size:9}}}}}}
function drawDashboardCharts(){new Chart($("dashBar"),{type:"bar",data:{labels:Object.keys(state.skills),datasets:[{data:Object.values(state.skills),borderRadius:5}]},options:chartDefaults()});new Chart($("dashPie"),{type:"doughnut",data:{labels:Object.keys(state.skills),datasets:[{data:Object.values(state.skills)}]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:"bottom",labels:{font:{size:8}}}}}})}
function drawRadar(){new Chart($("radar"),{type:"radar",data:{labels:Object.keys(state.skills),datasets:[{label:"Current skill level",data:Object.values(state.skills),fill:true}]},options:{responsive:true,maintainAspectRatio:false,scales:{r:{beginAtZero:true,max:100,ticks:{font:{size:8}}}}}})}
function drawProgress(){new Chart($("progressChart"),{type:"line",data:{labels:["Start","Week 1","Week 2","Week 3","Current"],datasets:[{label:"Overall skill level",data:[35,43,49,55,Math.round(Object.values(state.skills).reduce((a,b)=>a+b,0)/Object.keys(state.skills).length),],tension:.35,fill:true}]},options:chartDefaults()})}
/* V3 visible verification and persistent learning rewards */
function sgResetDemoRewards(){
  localStorage.removeItem('sg_reward_points');
  localStorage.removeItem('sg_reward_target');
  localStorage.removeItem('sg_reward_history');
  localStorage.removeItem('sg_communication_history');
  showToast('Rewards demo data reset.');
  render('rewards');
}
/* Enhanced learning, concept videos and rewards */
const rewardCatalog=[
{name:'Learning Platform Reward',points:100,desc:'Demo reward: learning-platform credit/coupon. A real verified partner code must be configured by the project owner.'},
{name:'Website Builder Reward',points:150,desc:'Demo reward: website-builder credit/coupon. A real verified partner code must be configured by the project owner.'},
{name:'OTT Reward',points:200,desc:'Demo reward: OTT trial/coupon. A real verified partner code must be configured by the project owner.'},
{name:'Cloud Learning Reward',points:250,desc:'Demo reward: cloud-learning voucher. A real verified partner code must be configured by the project owner.'}
];
const rewardTargets=[50,100,250,500,1000];
function getRewardPoints(){return Number(localStorage.getItem('sg_reward_points')||0)}
function getRewardTarget(){return Number(localStorage.getItem('sg_reward_target')||100)}
function getRewardHistory(){return JSON.parse(localStorage.getItem('sg_reward_history')||'[]')}
function saveRewardHistory(history){localStorage.setItem('sg_reward_history',JSON.stringify(history.slice(-100)))}
function addRewardPoints(points,reason){
  if(points<=0)return;
  points=Math.floor(Number(points)||0);
  const before=getRewardPoints();
  const target=getRewardTarget();
  const total=before+points;
  localStorage.setItem('sg_reward_points',total);
  const history=getRewardHistory();
  history.push({type:'earned',coins:points,reason,date:new Date().toLocaleString(),total});
  saveRewardHistory(history);
  if(before<target && total>=target) showToast(`🎉 Target reached! You reached ${target} coins.`);
  else showToast(`🪙 +${points} coins — ${reason}. Total: ${total}`);
}
function setRewardTarget(target){
  const t=Number(target);
  if(!rewardTargets.includes(t))return;
  localStorage.setItem('sg_reward_target',t);
  showToast(`🎯 New target set: ${t} coins`);
  render('rewards');
}
function rewards(){
  const p=getRewardPoints();
  const target=getRewardTarget();
  const percent=Math.min(100,Math.round(p/target*100));
  const history=getRewardHistory().slice().reverse();
  return head('Rewards','Earn coins for correct answers, choose a target, and track your progress toward it.')+`<div class="card" style="border:2px solid #6b4eff;background:#faf8ff;margin-bottom:18px"><strong>🎯 Rewards System Active — V3</strong><p class="muted" style="margin:6px 0 0">Your coins, target and history are saved in this browser. Correct answers automatically add coins.</p></div>`+
  `<div class="grid2">
    <div class="card">
      <div class="score-circle">${p}</div>
      <h3 style="text-align:center">🪙 My Coins</h3>
      <p class="muted" style="text-align:center">Coins are saved in this browser and remain available when you return to the app.</p>
      <h3 class="section-title" style="margin-top:20px">🎯 Set Your Target</h3>
      <div class="grid3">${rewardTargets.map(t=>`<button class="btn ${t===target?'gold-btn':'light'}" onclick="setRewardTarget(${t})">${t} coins</button>`).join('')}</div>
      <div style="margin-top:20px"><div style="display:flex;justify-content:space-between"><strong>Target progress</strong><strong>${p} / ${target}</strong></div><div style="height:14px;background:#eee;border-radius:99px;overflow:hidden;margin-top:8px"><div style="width:${percent}%;height:100%;background:linear-gradient(90deg,#f2b84b,#6b4eff)"></div></div><p class="tiny" style="margin-top:8px">${p>=target?'🎉 Target reached! Set a new target to keep learning.':`${target-p} more coins to reach your target.`}</p></div>
    </div>
    <div class="card">
      <h3 class="section-title">🎁 Reward Store</h3>
      <p class="muted">When you have enough coins, you can claim a demo reward. Real subscriptions/coupons require verified partner rewards.</p>
      <div class="list">${rewardCatalog.map(r=>`<div class="list-item"><h4>🎁 ${r.name} <span class="pill gold">${r.points} coins</span></h4><p>${r.desc}</p><button class="btn ${p>=r.points?'gold-btn':'light'}" onclick="claimReward(${r.points},'${r.name.replace(/'/g,"\\'")}')" ${p<r.points?'disabled':''}>${p>=r.points?'Claim reward':'Need more coins'}</button></div>`).join('')}</div>
    </div>
  </div>
  <div class="card" style="margin-top:18px">
    <h3 class="section-title">📜 Coin History</h3>
    ${history.length?`<div class="list">${history.slice(0,30).map(h=>`<div class="list-item"><h4>${h.type==='earned'?'🪙 +'+h.coins+' coins':'🎁 '+h.name}</h4><p>${h.reason||'Reward claimed'} • ${h.date}</p><p class="tiny">Balance after action: ${h.total}</p></div>`).join('')}</div>`:'<div class="empty">No coin activity yet. Answer questions correctly to start earning.</div>'}
  </div>`;
}
function claimReward(cost,name){
  const p=getRewardPoints();
  if(p<cost){showToast(`You need ${cost-p} more coins.`);return}
  const total=p-cost;
  localStorage.setItem('sg_reward_points',total);
  const history=getRewardHistory();
  history.push({type:'claimed',coins:cost,name,date:new Date().toLocaleString(),total});
  saveRewardHistory(history);
  showToast(`🎁 ${name} claimed for ${cost} coins.`);
  render('rewards');
}

const conceptVideos={
Python:[
['Python Fundamentals','Variables and data types','https://www.youtube.com/embed/rfscVS0vtbw?start=906','Learn variables and data types.'],
['Python Conditions','if, elif and else','https://www.youtube.com/embed/rfscVS0vtbw?start=6006','Learn decision making.'],
['Python Loops','while, for and nested loops','https://www.youtube.com/embed/rfscVS0vtbw?start=8493','Learn repetition and loop control.'],
['Python Functions','Functions and return values','https://www.youtube.com/embed/rfscVS0vtbw?start=5055','Build reusable functions.'],
['Python Collections','Lists, tuples and dictionaries','https://www.youtube.com/embed/rfscVS0vtbw?start=3790','Work with Python collections.'],
['Python OOP','Classes, objects and inheritance','https://www.youtube.com/embed/rfscVS0vtbw?start=13436','Learn object-oriented Python.']],
Java:[
['Java Fundamentals','Variables and data types','https://www.youtube.com/embed/eIrMbAQSU34','Build Java foundations.'],
['Java Conditions','if, else and switch','https://www.youtube.com/embed/eIrMbAQSU34?start=2400','Control program flow.'],
['Java Loops','for, while and do-while','https://www.youtube.com/embed/eIrMbAQSU34?start=4200','Practice repetition.'],
['Java Methods','Methods and parameters','https://www.youtube.com/embed/eIrMbAQSU34?start=6000','Create reusable methods.'],
['Java Arrays','Arrays and indexing','https://www.youtube.com/embed/eIrMbAQSU34?start=7200','Store multiple values.'],
['Java OOP','Classes, objects and inheritance','https://www.youtube.com/embed/eIrMbAQSU34?start=9000','Learn Java OOP.']],
'C++':[
['C++ Fundamentals','Variables and data types','https://www.youtube.com/embed/vLnPwxZdW4Y?start=730','Start C++ programming.'],
['C++ Arrays','Arrays and indexing','https://www.youtube.com/embed/vLnPwxZdW4Y?start=4380','Work with arrays.'],
['C++ Functions','Functions and return values','https://www.youtube.com/embed/vLnPwxZdW4Y?start=4800','Create reusable functions.'],
['C++ Conditions','if statements and switch','https://www.youtube.com/embed/vLnPwxZdW4Y?start=5722','Control program flow.'],
['C++ Loops','while and for loops','https://www.youtube.com/embed/vLnPwxZdW4Y?start=12447','Repeat operations.'],
['C++ OOP','Classes, constructors and inheritance','https://www.youtube.com/embed/vLnPwxZdW4Y?start=11600','Learn C++ OOP.']],
'Data Structures':[
['Arrays & Lists','List fundamentals','https://www.youtube.com/embed/B31LgI4Y4DQ?start=393','Understand lists.'],
['Linked Lists','Nodes, insertion and deletion','https://www.youtube.com/embed/B31LgI4Y4DQ?start=1130','Learn linked lists.'],
['Stacks','Stack operations and implementation','https://www.youtube.com/embed/B31LgI4Y4DQ?start=10340','Learn LIFO stacks.'],
['Queues','Queue operations and implementation','https://www.youtube.com/embed/B31LgI4Y4DQ?start=25920','Learn FIFO queues.'],
['Trees','Binary trees and BSTs','https://www.youtube.com/embed/B31LgI4Y4DQ?start=30600','Learn tree structures.'],
['Graphs','Graph representations','https://www.youtube.com/embed/B31LgI4Y4DQ?start=49000','Learn graph basics.']],
'Data Analytics':[
['Data Analysis Basics','Analysis workflow','https://www.youtube.com/embed/r-uOLxNrNk8','Understand the analysis process.'],
['Jupyter Notebooks','Notebook workflow','https://www.youtube.com/embed/r-uOLxNrNk8?start=1850','Use notebooks for analysis.'],
['NumPy','Numerical arrays','https://www.youtube.com/embed/r-uOLxNrNk8?start=3898','Learn NumPy basics.'],
['Pandas','DataFrames and processing','https://www.youtube.com/embed/r-uOLxNrNk8?start=7028','Process tabular data.'],
['Data Cleaning','Missing and invalid values','https://www.youtube.com/embed/r-uOLxNrNk8?start=10038','Clean datasets.'],
['Visualization','Charts and insights','https://www.youtube.com/embed/r-uOLxNrNk8','Communicate analytical results.']],
'AI/ML':[
['ML Fundamentals','What machine learning is','https://www.youtube.com/embed/i_LwzRVP7bg?start=525','Understand the ML workflow.'],
['Features & Data','Features and datasets','https://www.youtube.com/embed/i_LwzRVP7bg?start=1043','Understand model inputs.'],
['Classification','Classification and training','https://www.youtube.com/embed/i_LwzRVP7bg?start=1037','Learn classification.'],
['K-Nearest Neighbors','KNN intuition','https://www.youtube.com/embed/i_LwzRVP7bg?start=2683','Understand KNN.'],
['Neural Networks','Neural-network basics','https://www.youtube.com/embed/i_LwzRVP7bg?start=5984','Learn neural networks.'],
['Clustering & PCA','K-Means and PCA','https://www.youtube.com/embed/i_LwzRVP7bg?start=11600','Explore unsupervised learning.']],
'Cloud Computing':[
['Cloud Fundamentals','What cloud computing means','https://www.youtube.com/embed/zBBevSjX9E8?start=64','Understand cloud basics.'],
['Cloud Models','IaaS, PaaS and SaaS','https://www.youtube.com/embed/zBBevSjX9E8?start=250','Compare service models.'],
['Google Cloud','What GCP is','https://www.youtube.com/embed/zBBevSjX9E8?start=1035','Understand Google Cloud.'],
['Compute','Compute services','https://www.youtube.com/embed/zBBevSjX9E8?start=1680','Learn compute concepts.'],
['Storage','Cloud storage','https://www.youtube.com/embed/zBBevSjX9E8?start=1680','Learn storage concepts.'],
['Cloud Services','BigQuery, Cloud Run, GKE and Functions','https://www.youtube.com/embed/zBBevSjX9E8?start=1680','Explore major services.']],
Communication:[
['Communication Basics','Clear speaking','https://www.youtube.com/embed/2QbD6LhQ7vI','Build communication basics.'],
['Grammar','Grammar for communication','https://www.youtube.com/embed/2QbD6LhQ7vI','Improve sentence accuracy.'],
['Vocabulary','Everyday and professional vocabulary','https://www.youtube.com/embed/2QbD6LhQ7vI','Build usable vocabulary.'],
['Speaking','Speaking clearly and confidently','https://www.youtube.com/embed/2QbD6LhQ7vI','Practice spoken English.'],
['Listening','Listening for key information','https://www.youtube.com/embed/2QbD6LhQ7vI','Improve listening.'],
['Interview English','Professional interview language','https://www.youtube.com/embed/2QbD6LhQ7vI','Practice interview English.']]};
function startResource(skill){const list=conceptVideos[skill]||conceptVideos.Python;$('content').innerHTML=head(`${skill} Learning Path`,`Choose a concept. Each concept has its own teaching video and lesson notes.`)+`<div class="grid3">${list.map((v,i)=>`<div class="card"><span class="pill blue">Lesson ${i+1}</span><h3 style="margin-top:10px">${v[0]}</h3><p class="muted"><strong>${v[1]}</strong><br>${v[3]}</p><button class="btn" onclick="openConceptVideo('${skill}',${i})">▶ Watch video</button></div>`).join('')}</div><div style="margin-top:16px"><button class="btn light" onclick="render('resources')">← Back to Resources</button></div>`}
function openConceptVideo(skill,i){const v=(conceptVideos[skill]||conceptVideos.Python)[i];state.currentSkill=skill;$('content').innerHTML=head(v[0],`${skill} • ${v[1]}`,`<button class="btn light" onclick="startResource('${skill}')">← Back to ${skill} lessons</button>`)+`<div class="grid2"><div class="card"><div style="position:relative;padding-top:56.25%;overflow:hidden;border-radius:12px;background:#111"><iframe src="${v[2]}" title="${v[0]}" style="position:absolute;inset:0;width:100%;height:100%;border:0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div><h3 style="margin-top:18px">${v[0]}</h3><p class="muted">${v[3]}</p><button class="btn gold-btn" onclick="completeVideoLesson('${skill}')">✓ Mark Lesson Complete</button></div><div class="card"><h3 class="section-title">After this video</h3><div class="timeline"><div class="step done"><h4>1. Watch</h4><p>Focus on the concept and examples.</p></div><div class="step"><h4>2. Practice</h4><p>Use the Online Compiler when the topic is programming.</p></div><div class="step"><h4>3. Quiz</h4><button class="btn" onclick="startQuiz('${skill}')">Open ${skill} Quiz</button></div><div class="step"><h4>4. Assessment</h4><button class="btn light" onclick="startAssessment('${skill}')">Open ${skill} Assessment</button></div></div></div></div>`}

/* Expand every communication lesson to multiple examples. */
const extraExamples={
'Parts of Speech':['The teacher explained the lesson clearly. → teacher=noun, explained=verb, clearly=adverb.','My new laptop is fast. → new=adjective, laptop=noun, is=verb.','We walked across the bridge. → We=pronoun, across=preposition, bridge=noun.','Riya and Arun completed the task. → and=conjunction, completed=verb.'],
'Sentence Structure':['They play cricket. → Subject=They, Verb=play, Object=cricket.','The students are preparing for exams. → Subject=students, Verb phrase=are preparing.','Where did you keep the book? → helping verb + subject + main verb.','My friend gave me a useful book. → Subject=friend, Verb=gave, Objects=me/book.'],
'Tenses':['I work every day. → present simple.','I worked yesterday. → past simple.','I will work tomorrow. → future simple.','I am working now. → present continuous.','I have finished my work. → present perfect.'],
'Articles':['She bought a pen. → a before a consonant sound.','He ate an orange. → an before a vowel sound.','Please close the door. → the for a specific door.','I saw an honest man. → an follows the vowel sound in honest.'],
'Subject-Verb Agreement':['The boy plays football. ✓','The boys play football. ✓','Each student has a notebook. ✓','The list of names is on the table. ✓'],
'Prepositions':['The keys are in the bag. → in for an enclosed place.','The phone is on the desk. → on for a surface.','We meet at 5 PM. → at for exact time.','She walked to college. → to shows direction.'],
};
Object.keys(communicationLessons).forEach(type=>communicationLessons[type].lessons.forEach(l=>{const key=l.name.replace(/^\d+\. /,'');if(extraExamples[key])l.examples=[...l.examples,...extraExamples[key]];}));
/* Ensure EVERY communication lesson has multiple topic-specific examples.
   We use the lesson's own practice questions as additional examples instead of generic filler text. */
Object.keys(communicationLessons).forEach(type=>{
  const data=communicationLessons[type];
  data.lessons.forEach((lesson,idx)=>{
    const practice=(data.practice&&data.practice[idx])||[];
    const practiceExamples=practice.map((q,i)=>{
      const correct=q[1][q[2]];
      return `Practice example ${i+1}: ${q[0]} → Correct answer: ${correct}. ${q[3]}`;
    });
    lesson.examples=[...new Set([...(lesson.examples||[]),...practiceExamples])].slice(0,12);
  });
});

/* Better rewards for every right quiz/assessment answer. */
const oldSubmitQuiz=submitQuiz;
submitQuiz=function(){if(quizSession.rewarded){oldSubmitQuiz();return;} const qs=quizBanks[quizSession.skill];const correct=qs.reduce((n,q,i)=>n+(quizSession.answers[i]===q.a?1:0),0);quizSession.rewarded=true;addRewardPoints(correct*10,`${correct} correct ${quizSession.skill} quiz answers`);oldSubmitQuiz();};
const oldSubmitAssessment=submitAssessment;
submitAssessment=function(){if(assessmentSession.rewarded){oldSubmitAssessment();return;} const qs=assessmentBanks[assessmentSession.skill];const correct=qs.reduce((n,q,i)=>n+(assessmentSession.answers[i]===q.a?1:0),0);assessmentSession.rewarded=true;addRewardPoints(correct*15,`${correct} correct ${assessmentSession.skill} assessment answers`);oldSubmitAssessment();};

function presentation(){
 const examples=[
 ['Self Introduction','Good morning respected faculty and my dear friends. My name is Likhitha. I am a third-year CSE student. I am interested in cloud computing and software development. Today I would like to briefly introduce myself and my learning goals.'],
 ['Project Presentation','Good morning everyone. Today I am going to present our Student Skill Graph project. First I will explain the problem. Then I will explain our solution, technologies, main features, results and future scope.'],
 ['Technical Topic','Good morning. Today I would like to explain cloud computing. First I will define cloud computing. Then I will explain service models, important services and practical uses. Finally I will summarize the benefits.'],
 ['College Seminar','Good morning respected faculty and my dear friends. Our topic today is artificial intelligence. I will begin with the basic concept, then discuss applications, advantages and limitations, and finally conclude with key points.'],
 ['Project Demo','Now I will demonstrate our application. First the student logs in and completes onboarding. Next the system creates a personalized roadmap. The student watches concept videos, takes quizzes and assessments, and the results update the skill graph.'],
 ['Problem Statement','The main problem is that students often use separate platforms for learning, practice and progress tracking. Our solution combines these activities into one personalized cloud-based learning platform.'],
 ['Conclusion','To conclude, our project connects personalized learning, assessment and skill tracking. It identifies skill gaps and recommends the next learning step. Thank you for listening. I am happy to answer your questions.'],
 ['Interview Introduction','Good morning. Thank you for giving me this opportunity. My name is Likhitha and I am a third-year CSE student. My current interests are cloud computing, programming and software development.']
 ];
 return head('Presentation Coach','Learn how to start, structure, deliver and correct a presentation. Use the examples, then write or speak your own version.')+`<div class="grid2"><div class="card"><h3 class="section-title">How to start</h3><div class="timeline"><div class="step done"><h4>1. Greeting</h4><p>“Good morning respected faculty and my dear friends.”</p></div><div class="step"><h4>2. Introduce yourself</h4><p>“My name is Likhitha. I am a third-year CSE student.”</p></div><div class="step"><h4>3. Introduce the topic</h4><p>“Today I am going to present our Student Skill Graph project.”</p></div><div class="step"><h4>4. Give the structure</h4><p>“First I will explain the problem, then the solution, technologies, features and future scope.”</p></div><div class="step"><h4>5. End properly</h4><p>“To conclude, these are the key points. Thank you. I am happy to answer questions.”</p></div></div></div><div class="card"><h3 class="section-title">Multiple examples</h3><select id="presentationExample" class="field" onchange="loadPresentationExample()">${examples.map((e,i)=>`<option value="${i}">${e[0]}</option>`).join('')}</select><textarea id="speechText" class="field textarea" style="margin-top:12px;min-height:230px" placeholder="Type or speak your presentation..."></textarea><div style="margin-top:12px"><button class="btn" onclick="loadPresentationExample()">Load example</button> <button class="btn" onclick="startSpeech()">🎙 Start speaking</button> <button class="btn light" onclick="analyzeSpeech()">Check my mistakes</button></div><div id="speechFeedback" style="margin-top:15px"></div></div></div><div class="card" style="margin-top:18px"><h3 class="section-title">Common mistakes and corrections</h3><div class="grid3"><div class="list-item"><strong>❌ Myself Likhitha.</strong><p>✓ My name is Likhitha.</p></div><div class="list-item"><strong>❌ Today I am here to tell about...</strong><p>✓ Today I am going to explain...</p></div><div class="list-item"><strong>❌ First I will tell introduction.</strong><p>✓ First, I will introduce the topic.</p></div><div class="list-item"><strong>❌ I am having a project.</strong><p>✓ I have a project.</p></div><div class="list-item"><strong>❌ Discuss about the problem.</strong><p>✓ Discuss the problem.</p></div><div class="list-item"><strong>❌ Thank you for listening, that's all.</strong><p>✓ Thank you for listening. I am happy to answer questions.</p></div></div></div>`;
}

/* Add Rewards to the router. */
const oldRender=render;
render=function(page){if(page==='rewards'){$('pageTitle').textContent='Rewards';document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.page===page));$('content').innerHTML=rewards();return}oldRender(page)};


/* V5 PROJECT PORTFOLIO + REWARD CATALOG */
const assignedProjectCatalog=[
 {id:'python-mini-app',name:'Python Mini Application',skill:'Python',level:'Beginner',description:'Build a small Python application that uses variables, conditions, loops and functions.',tasks:['Create the program','Add at least 3 test cases','Explain the code in a README'],deliverable:'GitHub repository + README'},
 {id:'java-oop-app',name:'Java OOP Application',skill:'Java',level:'Beginner',description:'Create a Java application demonstrating classes, objects, methods and inheritance.',tasks:['Create at least 2 classes','Use inheritance','Add sample input/output'],deliverable:'GitHub repository + short demo'},
 {id:'data-analysis',name:'Student Data Analysis',skill:'Data Analytics',level:'Intermediate',description:'Analyze a student dataset and produce useful insights using Python, Pandas and charts.',tasks:['Clean the dataset','Calculate useful statistics','Create at least 3 visualizations'],deliverable:'Notebook + GitHub repository'},
 {id:'cloud-deployment',name:'Cloud Deployment Project',skill:'Cloud Computing',level:'Intermediate',description:'Deploy a small web application to a cloud platform and document the deployment steps.',tasks:['Prepare the application','Deploy it','Document the architecture and URL'],deliverable:'Live URL + GitHub repository'},
 {id:'communication-presentation',name:'Professional Presentation',skill:'Communication',level:'Beginner',description:'Prepare and deliver a 5-minute presentation about a technical topic.',tasks:['Prepare introduction','Explain 3 key points','Give a clear conclusion'],deliverable:'Presentation file + recorded/demo link'}
];
function getAssignedProjects(){return JSON.parse(localStorage.getItem('sg_assigned_projects')||'[]')}
function saveAssignedProjects(v){localStorage.setItem('sg_assigned_projects',JSON.stringify(v))}
function getPortfolioLinks(p){return `<div class="project-links">${p.github?`<a class="btn light" href="${p.github}" target="_blank" rel="noopener">GitHub ↗</a>`:`<button class="btn light" onclick="openGitHubNew()">Create GitHub repo</button>`}${p.linkedin?`<a class="btn light" href="${p.linkedin}" target="_blank" rel="noopener">LinkedIn ↗</a>`:`<button class="btn light" onclick="shareProjectLinkedIn(${JSON.stringify(p.name).replace(/"/g,'&quot;')})">Share on LinkedIn</button>`}${p.demo?`<a class="btn light" href="${p.demo}" target="_blank" rel="noopener">Live Demo ↗</a>`:''}</div>`}
function projects(){
 const assigned=getAssignedProjects();
 const assignedCards=assignedProjectCatalog.map(a=>{
   const done=assigned.includes(a.id);
   return `<div class="card"><span class="pill ${done?'green':'gold'}">${done?'Started':'Assigned project'}</span><h3>${a.name}</h3><p class="muted"><strong>${a.skill}</strong> • ${a.level}</p><p>${a.description}</p><h4>Project tasks</h4><ul>${a.tasks.map(t=>`<li>${t}</li>`).join('')}</ul><p class="tiny"><strong>Deliverable:</strong> ${a.deliverable}</p><button class="btn ${done?'light':'gold-btn'}" onclick="${done?`render('projects')`:`startAssignedProject('${a.id}')`}">${done?'Project started ✓':'Start this project'}</button></div>`;
 }).join('');
 const mine=state.projects.length?`<div class="grid3">${state.projects.map((p,i)=>`<div class="card"><span class="pill ${p.status==='Completed'?'green':'blue'}">${p.status||'Planned'}</span><h3>${p.name}</h3><p>${p.description}</p><p class="tiny"><strong>Technologies:</strong> ${p.tech||'Not specified'}<br><strong>Skills:</strong> ${p.skills||'Not specified'}<br><strong>Files:</strong> ${p.files?.length?p.files.join(', '):'Add files in your project folder'} </p>${getPortfolioLinks(p)}<div style="margin-top:12px"><button class="btn gold-btn" onclick="completeProject(${i})">${p.status==='Completed'?'Completed ✓':'Mark complete'}</button> <button class="btn light" onclick="editProjectLinks(${i})">Edit links</button> <button class="btn light" onclick="copyGitCommands(${i})">Copy GitHub upload commands</button></div></div>`).join('')}</div>`:'<div class="empty">No personal projects yet. Use “+ Add my project” to add one.</div>';
 return head('Projects','Complete assigned challenges, add your own work, and build a shareable portfolio.',`<button class="btn gold-btn" onclick="openProjectForm()">+ Add my project</button>`)+
 `<div class="card" style="margin-bottom:18px"><h3 class="section-title">📌 Assigned Projects</h3><p class="muted">These projects are assigned based on common learning paths. Start one, complete it, and add the GitHub/demo links to your portfolio.</p><div class="grid3">${assignedCards}</div></div>`+
 `<div class="card"><h3 class="section-title">🚀 My Projects & Portfolio</h3><p class="muted">Add projects you created yourself or projects completed outside the platform.</p>${mine}</div><div class="card" style="margin-top:18px"><h3 class="section-title">☁️ Publish to GitHub & LinkedIn</h3><div class="grid3"><div class="list-item"><h4>1. Create a GitHub repository</h4><p>Create a repository, copy its URL, and save it in your project.</p><button class="btn" onclick="openGitHubNew()">Open GitHub</button></div><div class="list-item"><h4>2. Upload your project</h4><p>Open your project folder in Terminal/Git Bash and use the Git commands generated by the project card.</p></div><div class="list-item"><h4>3. Share on LinkedIn</h4><p>Add your GitHub/live-demo link to a LinkedIn project or post.</p><button class="btn" onclick="shareProjectLinkedIn('My Student Skill Graph Project')">Share on LinkedIn</button></div></div><p class="tiny" style="margin-top:12px">The browser app cannot silently upload files to your GitHub account without GitHub authentication. This version prepares the portfolio links and Git commands so the actual upload is done securely through your GitHub account.</p></div>`;
}
function startAssignedProject(id){const a=assignedProjectCatalog.find(x=>x.id===id);if(!a)return;const list=getAssignedProjects();if(!list.includes(id)){list.push(id);saveAssignedProjects(list)};openProjectForm(a);}
function openProjectForm(prefill={}){
 $('content').innerHTML=head(prefill.id?'Assigned Project':'Add My Project','Add your project details, portfolio links and files.')+`<div class="card"><div class="form-grid"><div class="form-group"><label>PROJECT NAME</label><input id="prName" class="field" value="${prefill.name||''}" placeholder="My Cloud Project"></div><div class="form-group"><label>TECHNOLOGIES</label><input id="prTech" class="field" value="${prefill.skill?prefill.skill+', ':''}${prefill.tech||''}" placeholder="Python, Flask, Google Cloud"></div><div class="form-group full"><label>DESCRIPTION</label><textarea id="prDesc" class="field textarea" placeholder="Describe your project">${prefill.description||''}</textarea></div><div class="form-group"><label>SKILLS USED</label><input id="prSkills" class="field" value="${prefill.skill||''}" placeholder="Python, Cloud, SQL"></div><div class="form-group"><label>STATUS</label><select id="prStatus" class="field"><option>Planned</option><option>In Progress</option><option>Completed</option></select></div><div class="form-group"><label>GITHUB REPOSITORY URL</label><input id="prGithub" class="field" placeholder="https://github.com/username/repository"></div><div class="form-group"><label>LINKEDIN PROJECT/POST URL</label><input id="prLinkedin" class="field" placeholder="https://www.linkedin.com/..."></div><div class="form-group"><label>LIVE DEMO URL</label><input id="prDemo" class="field" placeholder="https://your-project.example.com"></div><div class="form-group full"><label>PROJECT FILES</label><input id="prFiles" class="field" type="file" multiple><p class="tiny">Files are recorded as part of this local portfolio entry. To publish the actual files, use the GitHub publishing steps below.</p></div></div><div style="margin-top:15px"><button class="btn gold-btn" onclick="saveProjectV5()">Save project to portfolio</button> <button class="btn light" onclick="render('projects')">Cancel</button></div></div>`;
}
function saveProjectV5(){const files=[...($('prFiles')?.files||[])].map(f=>f.name);const p={name:$('prName').value||'Untitled Project',tech:$('prTech').value||'Not specified',description:$('prDesc').value||'No description',skills:$('prSkills').value||'Not specified',status:$('prStatus').value,github:$('prGithub').value.trim(),linkedin:$('prLinkedin').value.trim(),demo:$('prDemo').value.trim(),files,date:new Date().toLocaleString()};state.projects.push(p);save();showToast('Project added to your portfolio');render('projects')}
function editProjectLinks(i){const p=state.projects[i];openProjectForm(p);setTimeout(()=>{$('prGithub').value=p.github||'';$('prLinkedin').value=p.linkedin||'';$('prDemo').value=p.demo||'';$('prStatus').value=p.status||'Planned';document.querySelector('#content .btn.gold-btn').onclick=()=>{p.github=$('prGithub').value.trim();p.linkedin=$('prLinkedin').value.trim();p.demo=$('prDemo').value.trim();p.status=$('prStatus').value;save();showToast('Project links updated');render('projects')}},0)}
function openGitHubNew(){window.open('https://github.com/new','_blank','noopener');showToast('Create your repository on GitHub, then paste its URL into your project.')}
function shareProjectLinkedIn(name){const text=encodeURIComponent(`I completed my project: ${name} using Student Skill Graph.`);window.open(`https://www.linkedin.com/feed/?shareActive=true&text=${text}`,'_blank','noopener')}
function copyGitCommands(i){const p=state.projects[i];const repo=p.github||'YOUR_GITHUB_REPOSITORY_URL';const commands=`git init\ngit add .\ngit commit -m "Add ${p.name}"\ngit branch -M main\ngit remote add origin ${repo}\ngit push -u origin main`;navigator.clipboard?.writeText(commands);showToast('GitHub upload commands copied')}

const rewardCatalogV5=[
{name:'OTT Subscription Reward',category:'Subscriptions',points:200,desc:'Demo OTT subscription/trial reward. A verified partner code is required for a real subscription.'},
{name:'Learning Platform Coupon',category:'Coupons & Credits',points:100,desc:'Demo learning-platform coupon or credit. Configure a real partner code before issuing.'},
{name:'Website Builder Credit',category:'Coupons & Credits',points:150,desc:'Demo website-builder credit/coupon.'},
{name:'Cloud Learning Voucher',category:'Learning Rewards',points:250,desc:'Demo cloud-learning voucher.'},
{name:'Premium Course Reward',category:'Learning Rewards',points:300,desc:'Demo premium-course access reward.'}
];
function getClaimedRewards(){return JSON.parse(localStorage.getItem('sg_claimed_rewards')||'[]')}
function saveClaimedRewards(v){localStorage.setItem('sg_claimed_rewards',JSON.stringify(v.slice(-100)))}
function claimRewardV5(cost,name,category){const p=getRewardPoints();if(p<cost){showToast(`You need ${cost-p} more coins.`);return}const total=p-cost;localStorage.setItem('sg_reward_points',total);const claimed=getClaimedRewards();claimed.push({name,category,cost,date:new Date().toLocaleString(),status:'Demo reward claimed'});saveClaimedRewards(claimed);const h=getRewardHistory();h.push({type:'claimed',coins:cost,name,reason:category,date:new Date().toLocaleString(),total});saveRewardHistory(h);showToast(`🎁 ${name} claimed!`);render('rewards')}
function rewards(){const p=getRewardPoints(),target=getRewardTarget(),percent=Math.min(100,Math.round(p/target*100)),history=getRewardHistory().slice().reverse(),claimed=getClaimedRewards().slice().reverse();const cats=[...new Set(rewardCatalogV5.map(x=>x.category))];return head('Rewards','Earn coins through learning, choose a target, and manage your subscriptions, coupons, credits and reward history.')+
`<div class="grid2"><div class="card"><h3 class="section-title">🪙 Coins & Target</h3><div class="score-circle">${p}</div><p style="text-align:center"><strong>Current coins</strong></p><div class="grid3">${rewardTargets.map(t=>`<button class="btn ${t===target?'gold-btn':'light'}" onclick="setRewardTarget(${t})">${t} coins</button>`).join('')}</div><div style="margin-top:18px"><div style="display:flex;justify-content:space-between"><strong>Target progress</strong><strong>${p}/${target}</strong></div><div style="height:14px;background:#eee;border-radius:99px;overflow:hidden;margin-top:8px"><div style="width:${percent}%;height:100%;background:linear-gradient(90deg,#f2b84b,#6b4eff)"></div></div><p class="tiny">${p>=target?'🎉 Target reached! Choose another target.':`${target-p} more coins to reach your target.`}</p></div></div>
<div class="card"><h3 class="section-title">🎁 Subscriptions, Coupons & Credits</h3><p class="muted">Rewards are separated by category. Real subscriptions/coupons require verified partner rewards.</p>${cats.map(cat=>`<div style="margin-top:14px"><h4>${cat}</h4><div class="list">${rewardCatalogV5.filter(r=>r.category===cat).map(r=>`<div class="list-item"><h4>${r.name} <span class="pill gold">${r.points} coins</span></h4><p>${r.desc}</p><button class="btn ${p>=r.points?'gold-btn':'light'}" onclick="claimRewardV5(${r.points},'${r.name.replace(/'/g,"\\'")}','${r.category}')" ${p<r.points?'disabled':''}>${p>=r.points?'Claim reward':'Need more coins'}</button></div>`).join('')}</div></div>`).join('')}</div></div>
<div class="grid2" style="margin-top:18px"><div class="card"><h3 class="section-title">🎟️ My Claimed Rewards</h3>${claimed.length?`<div class="list">${claimed.map(r=>`<div class="list-item"><h4>🎁 ${r.name}</h4><p>${r.category} • ${r.cost} coins • ${r.date}</p><span class="pill blue">${r.status}</span></div>`).join('')}</div>`:'<div class="empty">No rewards claimed yet.</div>'}</div><div class="card"><h3 class="section-title">📜 Coin History</h3>${history.length?`<div class="list">${history.slice(0,30).map(h=>`<div class="list-item"><h4>${h.type==='earned'?'🪙 +'+h.coins+' coins':'🎁 '+h.name}</h4><p>${h.reason||'Reward claimed'} • ${h.date}</p><p class="tiny">Balance after action: ${h.total}</p></div>`).join('')}</div>`:'<div class="empty">No coin activity yet.</div>'}</div></div>`}

if(state.user)showApp();

/* V6: STUDY MATERIALS + SCHEDULED EXAMS + STRICT LOGIN */
const studyMaterials=[
 {skill:'Python',icon:'🐍',materials:['Variables and data types','Conditions and loops','Functions and collections','OOP practice sheets'],pdf:'materials/pdfs/python-study-pack.pdf',textbook:'Python Tutorial (official documentation)',textbookUrl:'https://docs.python.org/3/tutorial/',blueprint:['Fundamentals','Control flow','Functions','Collections','OOP','Mini project']},
 {skill:'Java',icon:'☕',materials:['Java syntax notes','OOP examples','Arrays and methods','Inheritance exercises'],pdf:'materials/pdfs/java-study-pack.pdf',textbook:'Dev.java Learn Java',textbookUrl:'https://dev.java/learn/',blueprint:['Basics','Control flow','Methods','Arrays','OOP','Project']},
 {skill:'C++',icon:'⚙️',materials:['C++ basics','Arrays and strings','Functions','OOP and STL'],pdf:'materials/pdfs/cpp-study-pack.pdf',textbook:'cppreference',textbookUrl:'https://en.cppreference.com/w/',blueprint:['Syntax','Arrays','Functions','OOP','STL','Practice']},
 {skill:'Data Structures',icon:'🌳',materials:['Complexity notes','Linked lists','Stacks and queues','Trees and graphs'],pdf:'materials/pdfs/dsa-study-pack.pdf',textbook:'Open Data Structures',textbookUrl:'https://opendatastructures.org/',blueprint:['Complexity','Linear structures','Stacks/queues','Trees','Graphs','Algorithms']},
 {skill:'Data Analytics',icon:'📊',materials:['Analytics workflow','NumPy/Pandas notes','Cleaning checklist','Visualization guide'],pdf:'materials/pdfs/data-analytics-study-pack.pdf',textbook:'Python Data Analysis resources',textbookUrl:'https://pandas.pydata.org/docs/',blueprint:['Workflow','Jupyter','NumPy','Pandas','Cleaning','Visualization']},
 {skill:'AI/ML',icon:'🤖',materials:['ML fundamentals','Feature engineering notes','Classification','KNN and neural networks'],pdf:'materials/pdfs/ai-ml-study-pack.pdf',textbook:'scikit-learn User Guide',textbookUrl:'https://scikit-learn.org/stable/user_guide.html',blueprint:['ML workflow','Data/features','Classification','KNN','Neural networks','Clustering']},
 {skill:'Cloud Computing',icon:'☁️',materials:['Cloud fundamentals','IaaS/PaaS/SaaS','Compute and storage','Google Cloud basics'],pdf:'materials/pdfs/cloud-study-pack.pdf',textbook:'Google Cloud documentation',textbookUrl:'https://cloud.google.com/docs',blueprint:['Cloud basics','Service models','Compute','Storage','Networking','Cloud services']},
 {skill:'Communication',icon:'🗣️',materials:['Parts of speech','Tenses and grammar','Vocabulary','Speaking/listening/interview practice'],pdf:'materials/pdfs/communication-study-pack.pdf',textbook:'Purdue OWL Writing Lab',textbookUrl:'https://owl.purdue.edu/',blueprint:['Grammar','Vocabulary','Speaking','Listening','Writing','Interview']}
];
const materialDetails={
 Python:{overview:'Python programming from fundamentals to object-oriented programming.',topics:[['Variables & Data Types','Variables store values such as numbers, strings and booleans.'],['Conditions','Use if, elif and else to make decisions.'],['Loops','Use for and while loops to repeat work.'],['Functions','Functions group reusable logic and accept parameters.'],['Collections','Lists, tuples, sets and dictionaries organize data.'],['OOP','Classes and objects model real-world entities.']],links:[['Official Python Tutorial','https://docs.python.org/3/tutorial/']]},
 Java:{overview:'Java programming, object-oriented design and application development.',topics:[['Syntax & Variables','Learn Java types, variables and operators.'],['Control Flow','Use conditions and loops to control execution.'],['Methods','Create reusable methods with parameters and return values.'],['Arrays','Store and process collections of values.'],['OOP','Use classes, objects, inheritance and polymorphism.'],['Exceptions','Handle runtime problems safely.']],links:[['Dev.java Learn','https://dev.java/learn/']]},
 'C++':{overview:'C++ programming, problem solving, OOP and STL.',topics:[['Basics','Variables, types, operators and input/output.'],['Arrays & Strings','Store and manipulate collections of values.'],['Functions','Build reusable blocks of logic.'],['OOP','Use classes, objects and inheritance.'],['STL','Use vectors, maps, sets and algorithms.'],['Problem Solving','Apply C++ to programming problems.']],links:[['cppreference','https://en.cppreference.com/w/']]},
 'Data Structures':{overview:'Core data structures and algorithms used to solve computational problems.',topics:[['Complexity','Understand time and space complexity.'],['Arrays','Use indexed contiguous storage.'],['Linked Lists','Connect nodes dynamically.'],['Stacks & Queues','Implement LIFO and FIFO processing.'],['Trees','Represent hierarchical data.'],['Graphs','Model networks and relationships.']],links:[['Open Data Structures','https://opendatastructures.org/']]},
 'Data Analytics':{overview:'A practical analytics path from raw data to insights.',topics:[['Analytics Workflow','Define a question, collect data and plan analysis.'],['Jupyter','Run reproducible notebook-based analysis.'],['NumPy','Work with numerical arrays.'],['Pandas','Use Series and DataFrames.'],['Data Cleaning','Handle missing, duplicate and inconsistent data.'],['Visualization','Communicate patterns with charts.']],links:[['Pandas Documentation','https://pandas.pydata.org/docs/']]},
 'AI/ML':{overview:'Machine learning fundamentals, features, models and evaluation.',topics:[['ML Workflow','Frame a problem and choose data and evaluation.'],['Features','Prepare useful input variables.'],['Classification','Predict categories from labeled examples.'],['KNN','Classify using nearby training examples.'],['Neural Networks','Learn patterns through layered models.'],['Clustering','Group similar observations without labels.']],links:[['scikit-learn User Guide','https://scikit-learn.org/stable/user_guide.html']]},
 'Cloud Computing':{overview:'Cloud fundamentals, service models, compute, storage and networking.',topics:[['Cloud Basics','Understand on-demand computing and shared infrastructure.'],['IaaS/PaaS/SaaS','Compare the main cloud service models.'],['Compute','Run workloads on virtual machines or managed compute.'],['Storage','Choose object, block or file storage.'],['Networking','Connect workloads securely.'],['Cloud Services','Combine managed services into applications.']],links:[['Google Cloud Documentation','https://cloud.google.com/docs']]},
 Communication:{overview:'English communication for academic, professional and interview situations.',topics:[['Parts of Speech','Nouns, pronouns, verbs, adjectives, adverbs, prepositions, conjunctions and interjections.'],['Grammar','Sentence structure, tenses, articles, subject-verb agreement and prepositions.'],['Vocabulary','Build useful academic and workplace vocabulary.'],['Speaking','Introduce yourself, explain ideas and speak confidently.'],['Listening','Identify key ideas, details and speaker intent.'],['Writing','Write clear emails, paragraphs and professional messages.'],['Interview English','Answer common interview questions professionally.']],links:[['Purdue OWL','https://owl.purdue.edu/']]}
};
function materialCard(m){return `<div class="card"><span class="pill blue">${m.icon} ${m.skill}</span><h3 style="margin-top:10px">${m.skill} Learning Pack</h3><p class="muted">${materialDetails[m.skill].overview}</p><h4>📘 Topics</h4><div class="list">${materialDetails[m.skill].topics.map((t,i)=>`<button class="list-item" style="width:100%;text-align:left;cursor:pointer" onclick="openMaterialTopic('${m.skill}',${i})"><h4>${i+1}. ${t[0]}</h4><p>${t[1]}</p><span class="pill blue">Open material →</span></button>`).join('')}</div><div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap"><a class="btn gold-btn" href="${m.pdf}" target="_blank" rel="noopener">📄 Open PDF</a><a class="btn light" href="${m.pdf}" download>⬇ Download PDF</a>${materialDetails[m.skill].links.map(l=>`<a class="btn light" href="${l[1]}" target="_blank" rel="noopener">📖 ${l[0]} ↗</a>`).join('')}</div><h4 style="margin-top:16px">🧭 Blueprint</h4><div class="list">${m.blueprint.map((x,i)=>`<div class="list-item"><h4>${i+1}. ${x}</h4><p>Complete the lessons, practice and assessment for this stage.</p></div>`).join('')}</div></div>`}
function materials(){return head('Study Materials','Open each topic directly, read the material in the app, open its PDF in a new tab, use reference textbooks, and follow the learning blueprint.')+`<div class="grid2">${studyMaterials.map(materialCard).join('')}</div>`}
function openMaterialTopic(skill,index){const d=materialDetails[skill],t=d.topics[index];const examples={Python:['x=10 stores an integer.','if x>5: print("High") checks a condition.','for n in range(3): print(n) repeats a block.'],Java:['int age=20; declares an integer.','if(age>=18) checks a condition.','class Student { } defines a class.'],'C++':['int n=5; declares a value.','for(int i=0;i<5;i++) repeats work.','vector<int> a stores a dynamic sequence.'],'Data Structures':['An array gives O(1) indexed access.','A stack follows LIFO.','A queue follows FIFO.'],'Data Analytics':['A DataFrame stores tabular data.','Missing values can be detected before analysis.','A chart can reveal trends.'],'AI/ML':['A feature is an input variable.','Classification predicts a category.','KNN uses nearby examples.'],'Cloud Computing':['IaaS provides virtualized infrastructure.','Object storage stores files as objects.','Autoscaling adjusts capacity to demand.'],Communication:['Noun: The student submitted the assignment.','Verb: She explains the topic clearly.','Adjective: He gave a concise answer.']}[skill]||[];return $('content').innerHTML=head(`${skill} • ${t[0]}`,t[1],`<button class="btn light" onclick="render('materials')">← Back to materials</button>`)+`<div class="grid2"><div class="card"><h3 class="section-title">📖 Study Notes</h3><p>${t[1]}</p><h4 style="margin-top:18px">Examples</h4><div class="list">${examples.map((e,i)=>`<div class="list-item"><h4>Example ${i+1}</h4><p>${e}</p></div>`).join('')}</div></div><div class="card"><h3 class="section-title">🎯 Practice this topic</h3><p>After reading, continue to the skill quiz and assessment.</p><button class="btn gold-btn" onclick="startQuiz('${skill}')">Open ${skill} Quiz</button><button class="btn light" style="margin-left:8px" onclick="startAssessment('${skill}')">Open Assessment</button><div style="margin-top:18px"><h4>📄 PDF</h4><a class="btn light" href="${studyMaterials.find(x=>x.skill===skill).pdf}" target="_blank">Open study PDF</a></div></div></div>`}


/* Ask Questions — topic-aware learning assistant. Answers include explanation, key points and examples. */
const askKnowledge = [
 {keys:['what is cloud computing','cloud computing'],topic:'Cloud Computing',title:'Cloud Computing',answer:'Cloud computing is the delivery of computing resources such as servers, storage, databases, networking and software over the internet. Instead of buying and maintaining physical infrastructure, users can provision resources when needed and pay according to usage.',points:['On-demand access to computing resources','Resources can scale up or down','Common service models are IaaS, PaaS and SaaS','Examples include Google Cloud, AWS and Microsoft Azure'],example:'Example: A college website can run on a cloud server. During admissions, the application can use more computing resources, and after admissions the resources can be reduced.'},
 {keys:['what is python','python'],topic:'Python',title:'Python',answer:'Python is a high-level, general-purpose programming language known for readable syntax and a large ecosystem of libraries. It is widely used in web development, automation, data analysis, artificial intelligence and machine learning.',points:['Simple and readable syntax','Supports object-oriented and functional programming','Large library ecosystem','Used in data science, AI/ML and web development'],example:'Example:\nname = "Likhitha"\nprint("Hello", name)\n\nThis creates a variable and prints its value.'},
 {keys:['what is java','java'],topic:'Java',title:'Java',answer:'Java is a class-based, object-oriented programming language designed to be portable across platforms through the Java Virtual Machine (JVM). Java programs are compiled into bytecode that the JVM can execute.',points:['Object-oriented','Platform independent through the JVM','Strong type checking','Widely used for enterprise and Android-related development'],example:'Example:\nclass Hello {\n  public static void main(String[] args) {\n    System.out.println("Hello World");\n  }\n}'},
 {keys:['what is c++','c++'],topic:'C++',title:'C++',answer:'C++ is a general-purpose programming language that extends C with features such as classes, objects, templates and the Standard Template Library. It is commonly used for systems software and performance-sensitive applications.',points:['Supports procedural and object-oriented programming','Provides low-level memory control','Includes the STL','Useful for competitive programming and performance-focused software'],example:'Example:\nint a = 10, b = 20;\ncout << a + b;\n\nThe program outputs 30.'},
 {keys:['what is data structure','data structures','data structure'],topic:'Data Structures',title:'Data Structures',answer:'A data structure is a way of organizing and storing data so that operations such as searching, insertion, deletion and traversal can be performed efficiently.',points:['Arrays store elements in indexed positions','Linked lists connect nodes using links','Stacks follow LIFO','Queues follow FIFO','Trees and graphs represent hierarchical or connected data'],example:'Example: A stack can model browser history. The most recently visited page is the first page removed when the user presses Back.'},
 {keys:['what is stack','stack'],topic:'Stacks',title:'Stack',answer:'A stack is a linear data structure that follows LIFO — Last In, First Out. The main operations are push, pop and peek/top.',points:['push adds an item','pop removes the top item','peek/top reads the top item','Useful for function calls, undo operations and expression evaluation'],example:'Example: Push 10, 20, 30. The stack top is 30. A pop operation removes 30 first.'},
 {keys:['what is queue','queue'],topic:'Queues',title:'Queue',answer:'A queue is a linear data structure that follows FIFO — First In, First Out. Elements are inserted at the rear and removed from the front.',points:['Enqueue inserts an element','Dequeue removes the front element','Used in scheduling and buffering','A circular queue reuses available positions efficiently'],example:'Example: People waiting at a ticket counter form a queue. The person who arrives first is served first.'},
 {keys:['what is linked list','linked list'],topic:'Linked Lists',title:'Linked List',answer:'A linked list is a sequence of nodes where each node stores data and a link to another node. Unlike an array, nodes do not have to be stored in contiguous memory.',points:['Easy insertion/deletion when the node position is known','Singly linked lists have a next link','Doubly linked lists have next and previous links','Random access is slower than an array'],example:'Example: 10 → 20 → 30 → null. Each node points to the next node.'},
 {keys:['what is sql','sql'],topic:'SQL',title:'SQL',answer:'SQL (Structured Query Language) is used to create, read, update and delete data in relational databases. It can also filter, join, group and aggregate data.',points:['SELECT retrieves data','INSERT adds data','UPDATE changes data','DELETE removes data','JOIN combines related tables'],example:'Example:\nSELECT name, marks FROM students WHERE marks >= 80;\n\nThis retrieves students whose marks are at least 80.'},
 {keys:['what is database','database'],topic:'Databases',title:'Database',answer:'A database is an organized collection of data that can be stored, managed and retrieved efficiently. A DBMS provides tools for creating and querying databases.',points:['Stores structured information','Supports queries and updates','Relational databases use tables','Indexes can speed up searches'],example:'Example: A college database can contain Student, Course and Marks tables connected using student or course IDs.'},
 {keys:['what is machine learning','machine learning','ml'],topic:'AI/ML',title:'Machine Learning',answer:'Machine learning is a branch of artificial intelligence in which algorithms learn patterns from data and use those patterns to make predictions or decisions.',points:['Supervised learning uses labeled data','Unsupervised learning finds patterns without labels','Models are trained using data','Evaluation measures how well a model generalizes'],example:'Example: A spam classifier learns from emails labeled spam/not spam and predicts the class of a new email.'},
 {keys:['what is artificial intelligence','artificial intelligence','ai'],topic:'AI/ML',title:'Artificial Intelligence',answer:'Artificial intelligence is the field of building systems that perform tasks associated with human intelligence, such as understanding language, recognizing patterns, planning and making decisions.',points:['Includes machine learning and other approaches','Can process large amounts of data','Used in recommendation systems, vision and language applications'],example:'Example: A learning platform can recommend the next topic by analyzing a student’s quiz results and completed lessons.'},
 {keys:['what is data analytics','data analytics'],topic:'Data Analytics',title:'Data Analytics',answer:'Data analytics is the process of examining data to discover patterns, answer questions and support decisions. A typical workflow includes collecting, cleaning, analyzing and visualizing data.',points:['Collect relevant data','Clean missing or inconsistent values','Analyze patterns and relationships','Visualize findings with charts or dashboards'],example:'Example: A student dashboard can analyze quiz scores across Python, Java and DSA and show which skill needs more practice.'},
 {keys:['what is cloud run','cloud run'],topic:'Google Cloud',title:'Google Cloud Run',answer:'Cloud Run is a Google Cloud service for running containerized applications on a fully managed platform. It can automatically handle infrastructure and scale application instances based on traffic.',points:['Runs containerized applications','Managed infrastructure','Supports automatic scaling','Useful for deploying web APIs and applications'],example:'Example: A Flask Student Skill Graph application can be packaged as a container and deployed to Cloud Run so students can access it through a web URL.'},
 {keys:['what is firestore','firestore'],topic:'Google Cloud',title:'Cloud Firestore',answer:'Cloud Firestore is a managed NoSQL document database from Google Cloud. Applications store data in collections and documents and can read or update that data from client or server applications.',points:['Document-oriented NoSQL database','Collections contain documents','Supports real-time data synchronization','Useful for user profiles, progress and learning history'],example:'Example: A student document can store name, selected skills, completed lessons and quiz scores.'},
 {keys:['what is git','git'],topic:'Git',title:'Git',answer:'Git is a distributed version control system used to track changes in source code and collaborate on software projects.',points:['Tracks file changes','Supports branches and merges','Makes collaboration easier','GitHub and similar services can host Git repositories'],example:'Example:\ngit add .\ngit commit -m "Add quiz feature"\ngit push\n\nThese commands stage, save and upload a change to a remote repository.'},
 {keys:['what is html','html'],topic:'Web Development',title:'HTML',answer:'HTML (HyperText Markup Language) defines the structure and content of a web page using elements such as headings, paragraphs, links, forms and buttons.',points:['Defines page structure','Uses elements and attributes','Works with CSS for presentation','Works with JavaScript for behavior'],example:'Example: <h1>Student Skill Graph</h1> creates a main heading on a web page.'},
 {keys:['what is css','css'],topic:'Web Development',title:'CSS',answer:'CSS (Cascading Style Sheets) controls the appearance and layout of HTML elements. It can define colors, spacing, fonts, borders, responsive layouts and more.',points:['Controls presentation','Supports responsive layouts','Uses selectors and properties','Can use Flexbox and Grid for layout'],example:'Example: .card { padding: 20px; border-radius: 12px; } adds spacing and rounded corners to a card.'},
 {keys:['what is javascript','javascript','js'],topic:'Web Development',title:'JavaScript',answer:'JavaScript is a programming language used to add behavior and interactivity to web pages. It can read and change the DOM, respond to events and communicate with web services.',points:['Runs in browsers','Handles user events','Can update page content dynamically','Can call APIs using fetch'],example:'Example: document.querySelector("#btn").onclick = () => alert("Hello!"); runs code when a button is clicked.'},
 {keys:['what is api','api'],topic:'APIs',title:'API',answer:'An API (Application Programming Interface) defines how one software component can communicate with another. Web APIs commonly use HTTP requests and return structured data such as JSON.',points:['Provides a defined interface','Common HTTP methods include GET, POST, PUT and DELETE','JSON is widely used for web API responses','APIs connect frontends, backends and external services'],example:'Example: A weather dashboard can send a GET request to a weather API and display the returned temperature and conditions.'},
 {keys:['what is oop','oops','object oriented programming','object-oriented programming'],topic:'OOP',title:'Object-Oriented Programming',answer:'Object-oriented programming organizes software around objects that combine data and behavior. Common concepts include classes, objects, encapsulation, inheritance, polymorphism and abstraction.',points:['Class defines a blueprint','Object is an instance of a class','Encapsulation protects internal state','Inheritance allows reuse','Polymorphism allows one interface to have different implementations'],example:'Example: A Student class can contain name and marks fields and a calculateGrade() method. Each student object can have different values.'}
];
function findAskAnswer(question, selected){
 const q=(question||'').toLowerCase().trim();
 let best=null,score=0;
 askKnowledge.forEach(item=>{let s=0;item.keys.forEach(k=>{if(q.includes(k))s+=k.length>4?3:2});if(selected&&selected!=='All Topics'&&item.topic===selected)s+=1;if(s>score){score=s;best=item}});
 return best;
}
function askQuestions(){
 const topics=['All Topics',...Array.from(new Set(askKnowledge.map(x=>x.topic)))];
 const examples=['What is cloud computing?','Explain stack with an example','What is machine learning?','How does SQL work?','What is an API?'];
 return head('Ask Questions','Have a doubt? Ask about programming, cloud, AI/ML, data structures, databases, web development and other learning topics. The answer is shown with clear content, key points and a practical example.')+
 `<div class="grid2"><div class="card"><h3 class="section-title">💬 Ask your doubt</h3><label class="field-label">Topic</label><select id="askTopic" class="input">${topics.map(t=>`<option>${t}</option>`).join('')}</select><label class="field-label" style="margin-top:12px">Your question</label><textarea id="askInput" class="input" rows="6" placeholder="Example: What is a stack and where is it used?"></textarea><div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">${examples.map(x=>`<button class="btn light" onclick="setAskQuestion(${JSON.stringify(x)})">${x}</button>`).join('')}</div><button class="btn gold-btn" style="margin-top:14px" onclick="submitAskQuestion()">Get Answer →</button></div><div class="card"><h3 class="section-title">📌 How this helps</h3><div class="list"><div class="list-item"><h4>Clear explanation</h4><p>Understand the concept in simple student-friendly language.</p></div><div class="list-item"><h4>Key points</h4><p>See the important points you should remember for exams and interviews.</p></div><div class="list-item"><h4>Practical example</h4><p>Every supported topic includes a concrete example to connect theory with practice.</p></div><div class="list-item"><h4>Ask follow-up doubts</h4><p>You can immediately ask another question whenever a concept is unclear.</p></div></div></div></div><div id="askAnswer" style="margin-top:18px"></div>`;
}
function setAskQuestion(q){$('askInput').value=q;submitAskQuestion()}
function submitAskQuestion(){
 const q=$('askInput')?.value.trim(), selected=$('askTopic')?.value||'All Topics';
 if(!q){showToast('Please enter your question first.');return}
 const item=findAskAnswer(q,selected), box=$('askAnswer');
 if(!item){box.innerHTML=`<div class="card"><span class="pill gold">Question received</span><h3 style="margin-top:12px">I need a little more detail</h3><p>I could not match this doubt to the current learning knowledge base. Try adding the main topic or concept, for example: “Explain linked list insertion” or “What is a Python function?”</p><p class="muted">This version answers the project’s built-in learning topics locally. A real AI model such as Gemini can be connected later for open-ended questions.</p></div>`;return}
 box.innerHTML=`<div class="card ask-result"><div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap"><span class="pill green">${item.topic}</span><span class="pill blue">Answer</span></div><h2 style="margin:14px 0 8px">${item.title}</h2><p>${item.answer.replace(/\n/g,'<br>')}</p><h3 class="section-title" style="margin-top:20px">Key points</h3><ul>${item.points.map(x=>`<li style="margin:8px 0">${x}</li>`).join('')}</ul><h3 class="section-title" style="margin-top:20px">Example</h3><pre style="white-space:pre-wrap;margin:0">${item.example}</pre><div style="margin-top:16px"><button class="btn light" onclick="$('askInput').focus()">Ask another question</button></div></div>`;
}

const scheduledExams=[
 {id:'python-today',title:'Python Fundamentals — Today',skill:'Python',start:'2026-09-29T10:00:00+05:30',end:'2026-09-29T11:00:00+05:30',questions:[
  {q:'Which keyword defines a function in Python?',o:['func','def','function','method'],a:1,e:'Python uses def to define a function.'},
  {q:'Which loop is commonly used to iterate through a list?',o:['for','switch','class','try'],a:0,e:'A for loop iterates over items in an iterable.'},
  {q:'Which collection stores key-value pairs?',o:['list','tuple','dictionary','string'],a:2,e:'A dictionary stores data as key-value pairs.'},
  {q:'What does len([1,2,3]) return?',o:['2','3','4','1'],a:1,e:'The list contains three elements.'}
 ]},
 {id:'java-tomorrow',title:'Java OOP — Tomorrow',skill:'Java',start:'2026-09-30T10:00:00+05:30',end:'2026-09-30T11:00:00+05:30',questions:[
  {q:'Which keyword creates an object in Java?',o:['new','create','object','make'],a:0,e:'The new keyword creates an object instance.'},
  {q:'Which concept allows a class to inherit another class?',o:['Inheritance','Compilation','Casting','Parsing'],a:0,e:'Inheritance lets a subclass acquire members of a superclass.'},
  {q:'Which method is the entry point of a Java application?',o:['start()','run()','main()','init()'],a:2,e:'Java applications start from the main method.'},
  {q:'Which keyword refers to the current object?',o:['self','this','current','object'],a:1,e:'this refers to the current object.'}
 ]},
 {id:'python-midterm',title:'Python Fundamentals Exam',skill:'Python',start:'2026-10-01T10:00:00+05:30',end:'2026-10-01T11:00:00+05:30',questions:[
  {q:'Which keyword defines a function in Python?',o:['func','def','function','method'],a:1,e:'Python uses def to define a function.'},
  {q:'Which loop is commonly used to iterate through a list?',o:['for','switch','class','try'],a:0,e:'A for loop iterates over items in an iterable.'},
  {q:'Which collection stores key-value pairs?',o:['list','tuple','dictionary','string'],a:2,e:'A dictionary stores data as key-value pairs.'},
  {q:'What does len([1,2,3]) return?',o:['2','3','4','1'],a:1,e:'The list contains three elements.'}
 ]},
 {id:'java-oop',title:'Java OOP Exam',skill:'Java',start:'2026-10-02T14:00:00+05:30',end:'2026-10-02T15:00:00+05:30',questions:[
  {q:'Which keyword creates an object in Java?',o:['new','create','object','make'],a:0,e:'The new keyword creates an object instance.'},
  {q:'Which concept allows a class to inherit another class?',o:['Inheritance','Compilation','Casting','Parsing'],a:0,e:'Inheritance lets a subclass acquire members of a superclass.'},
  {q:'Which method is the entry point of a Java application?',o:['start()','run()','main()','init()'],a:2,e:'Java applications start from the main method.'},
  {q:'Which keyword refers to the current object?',o:['self','this','current','object'],a:1,e:'this refers to the current object.'}
 ]},
 {id:'cloud-foundations',title:'Cloud Computing Foundations Exam',skill:'Cloud Computing',start:'2026-10-03T11:00:00+05:30',end:'2026-10-03T12:00:00+05:30',questions:[
  {q:'What does IaaS provide?',o:['Virtualized infrastructure','Only email','Only source code','Only videos'],a:0,e:'IaaS provides infrastructure such as virtual machines, storage and networking.'},
  {q:'Which is a cloud deployment model?',o:['Public cloud','Local loop','Compiler cloud','Text cloud'],a:0,e:'Public cloud is a recognized cloud deployment model.'},
  {q:'Which service is commonly used for object storage?',o:['Cloud Storage','Cloud DNS only','Cloud Shell only','Cloud Logging only'],a:0,e:'Object storage services store files and objects in buckets.'},
  {q:'What is scalability?',o:['Adjusting resources to demand','Deleting all servers','Changing passwords','Printing reports'],a:0,e:'Scalability is the ability to adjust capacity as demand changes.'}
 ]},
 {id:'communication-exam',title:'Professional Communication Exam',skill:'Communication',start:'2026-10-04T16:00:00+05:30',end:'2026-10-04T17:00:00+05:30',questions:[
  {q:'Which is a noun?',o:['quickly','student','beautiful','write'],a:1,e:'Student names a person and is therefore a noun.'},
  {q:'Which sentence is grammatically correct?',o:['She go to class.','She goes to class.','She going class.','She gone class.'],a:1,e:'With she in the simple present, the verb is goes.'},
  {q:'Which opening is professional?',o:['Hey bro','Dear Professor,','Yo!','What’s up?'],a:1,e:'Dear Professor is appropriate in a formal academic message.'},
  {q:'What is active listening?',o:['Waiting to speak','Paying attention and responding appropriately','Ignoring the speaker','Changing the topic'],a:1,e:'Active listening means paying attention, understanding and responding appropriately.'}
 ]},
 {id:'data-analytics-exam',title:'Data Analytics Exam',skill:'Data Analytics',start:'2026-10-05T10:00:00+05:30',end:'2026-10-05T11:00:00+05:30',questions:[
  {q:'Which Python library is widely used for tabular data?',o:['Pandas','Flask','React','JUnit'],a:0,e:'Pandas provides DataFrame and Series structures for tabular data.'},
  {q:'Why clean data?',o:['To improve data quality','To delete all rows','To hide results','To change passwords'],a:0,e:'Cleaning addresses missing, invalid, duplicate or inconsistent data.'},
  {q:'What is a visualization?',o:['A graphical representation of data','A password','A compiler','A database user'],a:0,e:'Charts and graphs visually communicate patterns in data.'},
  {q:'What does a DataFrame represent?',o:['A tabular data structure','A web server','A network cable','A Java class only'],a:0,e:'A Pandas DataFrame is a two-dimensional labeled tabular structure.'}
 ]}
];

const anytimeExams=[
 {id:'any-python',title:'Python Mastery — Anytime Exam',skill:'Python',start:'2026-09-29T00:00:00+05:30',end:'2026-10-07T23:59:00+05:30',questions:[
  {q:'Which keyword defines a function?',o:['func','def','function','method'],a:1,e:'Python uses def to define functions.'},
  {q:'Which data structure stores key-value pairs?',o:['List','Tuple','Dictionary','Set'],a:2,e:'Dictionaries store key-value pairs.'},
  {q:'What is the output of 3 * 2?',o:['5','6','9','32'],a:1,e:'Multiplication is performed before the result is returned: 6.'},
  {q:'Which statement repeats code while a condition is true?',o:['if','while','class','import'],a:1,e:'A while loop continues while its condition remains true.'},
  {q:'Which collection is ordered and changeable?',o:['List','Tuple','String','Integer'],a:0,e:'Lists are ordered and mutable.'}
 ]},
 {id:'any-java',title:'Java OOP — Anytime Exam',skill:'Java',start:'2026-09-29T00:00:00+05:30',end:'2026-10-10T23:59:00+05:30',questions:[
  {q:'Which keyword creates an object?',o:['new','make','class','this'],a:0,e:'new creates an instance.'},
  {q:'Which OOP concept hides implementation details?',o:['Encapsulation','Inheritance','Looping','Parsing'],a:0,e:'Encapsulation bundles data and methods while controlling access.'},
  {q:'What is the entry point method?',o:['start()','run()','main()','init()'],a:2,e:'Java applications begin execution at main.'},
  {q:'Which keyword refers to the current object?',o:['self','this','current','me'],a:1,e:'this refers to the current object.'},
  {q:'Which type represents true/false?',o:['boolean','bool','bit','logical'],a:0,e:'Java uses boolean for true/false values.'}
 ]},
 {id:'any-dsa',title:'DSA Challenge — Anytime Exam',skill:'Data Structures',start:'2026-09-29T00:00:00+05:30',end:'2026-10-15T23:59:00+05:30',questions:[
  {q:'Which structure is LIFO?',o:['Queue','Stack','Tree','Graph'],a:1,e:'Stacks follow last-in, first-out.'},
  {q:'What does BFS commonly use?',o:['Queue','Stack','Heap','Hash table'],a:0,e:'Breadth-first search explores level by level with a queue.'},
  {q:'Binary search needs what?',o:['Sorted data','Random data','A graph','A stack'],a:0,e:'Binary search repeatedly halves a sorted search space.'},
  {q:'Which traversal is root-left-right?',o:['Inorder','Preorder','Postorder','Level order'],a:1,e:'Preorder visits root before its subtrees.'},
  {q:'Which algorithm finds a shortest path in an unweighted graph?',o:['BFS','Bubble sort','Binary search','DFS only'],a:0,e:'BFS explores by distance in an unweighted graph.'}
 ]}
];
let examSession={exam:null,index:0,answers:[],submitted:false};
function examStatus(exam){const now=Date.now(),s=new Date(exam.start).getTime(),e=new Date(exam.end).getTime();return now<s?'upcoming':now<=e?'active':'closed'}
function formatExamTime(v){return new Date(v).toLocaleString([], {dateStyle:'medium',timeStyle:'short'})}
function getExamHistory(){return JSON.parse(localStorage.getItem('sg_exam_history')||'[]')}
function saveExamHistory(v){localStorage.setItem('sg_exam_history',JSON.stringify(v.slice(-100)))}
function exams(){
 const history=getExamHistory().slice().reverse();
 const renderExamCard=ex=>{const st=examStatus(ex);const label=st==='active'?'🟢 Open now':st==='upcoming'?'🔒 Not open yet':'⛔ Closed';return `<div class="card exam-card"><span class="pill ${st==='active'?'green':st==='upcoming'?'blue':'red'}">${label}</span><h3 style="margin-top:10px">${ex.title}</h3><p class="muted"><strong>Skill:</strong> ${ex.skill}</p><div class="list-item"><h4>Available from</h4><p>${formatExamTime(ex.start)}</p></div><div class="list-item" style="margin-top:8px"><h4>Ending time</h4><p>${formatExamTime(ex.end)}</p></div><p class="tiny" style="margin-top:10px">${st==='active'?`You can start whenever you choose until ${formatExamTime(ex.end)}.`:st==='upcoming'?`Opens ${formatExamTime(ex.start)}.`:'The deadline has passed.'}</p><button class="btn ${st==='active'?'gold-btn':'light'}" ${st!=='active'?'disabled':''} onclick="startScheduledExam('${ex.id}')">${st==='active'?'Start Exam Now':'Locked'}</button></div>`};
 return head('Exams','Take an exam at a time that suits you. Anytime exams stay open until their deadline; the exam cannot be submitted after the ending time.',`<button class="btn gold-btn" onclick="enableExamNotifications()">🔔 Enable Exam Notifications</button>`)+
 `<div class="notification-callout card"><strong>⏰ Anytime Exams</strong><p class="muted">These exams do not require a fixed start time. Start them whenever you are ready before the deadline.</p><div class="grid3">${anytimeExams.map(renderExamCard).join('')}</div></div>`+
 `<h3 style="margin:25px 0 10px">Fixed Schedule Exams</h3><div class="grid3">${scheduledExams.map(renderExamCard).join('')}</div>`+
 `<div class="card" style="margin-top:18px"><h3 class="section-title">📜 Exam History</h3>${history.length?`<div class="list">${history.map(h=>`<div class="list-item"><h4>${h.title} <span class="pill blue">${h.percent}%</span></h4><p>${h.skill} • ${h.score}/${h.total} • ${h.date}</p></div>`).join('')}</div>`:'<div class="empty">No exams completed yet.</div>'}</div>`;
}
function startScheduledExam(id){const ex=[...anytimeExams,...scheduledExams].find(x=>x.id===id);if(!ex)return;if(examStatus(ex)!=='active'){showToast('This exam is not open right now.');render('exams');return}examSession={exam:ex,index:0,answers:[],submitted:false};renderScheduledExamQuestion()}
function renderScheduledExamQuestion(){const ex=examSession.exam,q=ex.questions[examSession.index],sel=examSession.answers[examSession.index];$('content').innerHTML=head(ex.title,`⏱ ${formatExamTime(ex.start)} → ${formatExamTime(ex.end)} • Question ${examSession.index+1} of ${ex.questions.length}`,`<button class="btn light" onclick="render('exams')">← Exit</button>`)+`<div class="card"><span class="pill gold">${ex.skill}</span><h2 style="margin:15px 0">${q.q}</h2>${q.o.map((o,i)=>`<button class="quiz-option ${sel===i?'selected':''}" onclick="selectScheduledAnswer(${i})">${String.fromCharCode(65+i)}. ${o}</button>`).join('')}<div style="margin-top:18px"><button class="btn light" onclick="examPrev()" ${examSession.index===0?'disabled':''}>← Previous</button> ${examSession.index<ex.questions.length-1?`<button class="btn" onclick="examNext()">Next →</button>`:`<button class="btn gold-btn" onclick="submitScheduledExam()">Submit Exam</button>`}</div></div>`}
function selectScheduledAnswer(i){examSession.answers[examSession.index]=i;renderScheduledExamQuestion()}
function examPrev(){if(examSession.index>0){examSession.index--;renderScheduledExamQuestion()}}
function examNext(){if(examSession.index<examSession.exam.questions.length-1){examSession.index++;renderScheduledExamQuestion()}}
function submitScheduledExam(){const ex=examSession.exam;if(examStatus(ex)!=='active'){showToast('The exam window has ended.');render('exams');return}let score=0;ex.questions.forEach((q,i)=>{if(examSession.answers[i]===q.a)score++});const percent=Math.round(score/ex.questions.length*100);const h=getExamHistory();h.push({id:ex.id,title:ex.title,skill:ex.skill,score,total:ex.questions.length,percent,date:new Date().toLocaleString()});saveExamHistory(h);state.assessments.push({skill:ex.skill,score:percent,date:new Date().toLocaleDateString(),source:'Scheduled Exam'});state.skills[ex.skill]=Math.max(state.skills[ex.skill]||0,Math.min(100,Math.round((state.skills[ex.skill]||0)*0.7+percent*0.3)));save();addRewardPoints(score*20,`${score} correct answers in ${ex.title}`);renderScheduledExamResult(score,percent)}
function renderScheduledExamResult(score,percent){const ex=examSession.exam;$('content').innerHTML=head(`${ex.title} Result`,`Exam completed and saved to your exam history.`)+`<div class="grid2"><div class="card"><div class="score-circle">${percent}%</div><h3 style="text-align:center">${score} / ${ex.questions.length} correct</h3><p class="muted" style="text-align:center">Your result has been stored. Correct answers also earn coins.</p><button class="btn gold-btn" onclick="render('exams')">Back to Exams</button></div><div class="card"><h3 class="section-title">Review</h3><div class="list">${ex.questions.map((q,i)=>`<div class="list-item"><h4>Q${i+1}. ${q.q}</h4><p>Your answer: ${examSession.answers[i]===undefined?'Not answered':q.o[examSession.answers[i]]}</p><p>Correct answer: <strong>${q.o[q.a]}</strong></p><p>${q.e}</p></div>`).join('')}</div></div></div>`}

/* V6 router: materials and scheduled exams */
const sgRenderV6=render;
render=function(page){
 if(page==='materials'){state.activePage=page;document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.page===page));$('pageTitle').textContent='Study Materials';$('content').innerHTML=materials();return}
 if(page==='exams'){state.activePage=page;document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.page===page));$('pageTitle').textContent='Scheduled Exams';$('content').innerHTML=exams();return}
 sgRenderV6(page);
};
setInterval(()=>{if(state.activePage==='exams' && document.visibilityState==='visible')render('exams')},30000);

/* V7 authentication and materials/rewards fixes */
function showForgotPassword(){const email=prompt('Enter your registered email address:');if(!email)return;const accounts=getAccounts();const key=email.trim().toLowerCase();if(!accounts[key]){showToast('No account found for that email.');return}const newPass=prompt('Enter a new password (minimum 6 characters):');if(!newPass||newPass.length<6){showToast('Password must be at least 6 characters.');return}accounts[key].password=newPass;saveAccounts(accounts);showToast('Password updated. You can now sign in.')}
function continueWithGoogle(){showToast('Google sign-in needs a real Google OAuth/Firebase configuration. The button is ready for integration.');}
function createAccount(){const name=prompt('Enter your full name:');if(!name)return;const email=prompt('Enter your email:');if(!email)return;const key=email.trim().toLowerCase();const accounts=getAccounts();if(accounts[key]){showToast('An account with this email already exists.');return}const password=prompt('Create a password (minimum 6 characters):');if(!password||password.length<6){showToast('Password must be at least 6 characters.');return}accounts[key]={password,name:name.trim(),branch:'Computer Science Engineering',year:'3rd Year',goal:'Explore careers'};saveAccounts(accounts);showToast('Account created. You can now sign in.');$('loginEmail').value=key;$('loginPassword').value='';}
if($('forgotPassword'))$('forgotPassword').onclick=showForgotPassword;
if($('googleLogin'))$('googleLogin').onclick=continueWithGoogle;
if($('createAccount'))$('createAccount').onclick=createAccount;


const sgRenderV7=render;
render=function(page){
 if(page==='materials'){state.activePage=page;document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.page===page));$('pageTitle').textContent='Study Materials';$('content').innerHTML=materials();return}
 if(page==='rewards'){state.activePage=page;document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.page===page));$('pageTitle').textContent='Rewards';$('content').innerHTML=rewards();return}
 if(page==='languages'){state.activePage=page;document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.page===page));$('pageTitle').textContent='Learn Languages';$('content').innerHTML=languages();return}
 sgRenderV7(page);
};

/* V11 — notification center + browser notifications */
function examNotifications(){
 const now=Date.now();
 return [...anytimeExams,...scheduledExams].map(ex=>{const e=new Date(ex.end).getTime();const s=new Date(ex.start).getTime();return {type:'exam',title:ex.title,text:now<s?`Starts ${formatExamTime(ex.start)}`:now<=e?`Open until ${formatExamTime(ex.end)}`:'Closed',time:s}}).filter(n=>now<=n.time+1000*60*60*24*30 || n.text.includes('Open until')).sort((a,b)=>a.time-b.time).slice(0,6);
}
function buildNotifications(){
 const items=examNotifications();
 items.push({type:'learning',title:'Language practice reminder',text:`Keep your ${languageState.streak||0}-day learning streak going.`});
 return items.slice(0,8);
}
function toggleNotifications(){const p=$('notificationPanel');if(!p)return;const hidden=p.classList.toggle('hidden');if(!hidden){p.innerHTML=`<div class="notification-head"><strong>Notifications</strong><button class="btn light" onclick="requestBrowserNotifications();event.stopPropagation()">Allow browser alerts</button></div>${buildNotifications().map(n=>`<div class="notification-item"><span>${n.type==='exam'?'⏰':'📚'}</span><div><strong>${n.title}</strong><small>${n.text}</small></div></div>`).join('')}`;}}
function requestBrowserNotifications(){if(!('Notification' in window)){showToast('Browser notifications are not supported.');return}Notification.requestPermission().then(v=>showToast(v==='granted'?'🔔 Browser notifications enabled.':'Notifications were not enabled.'));}
function enableExamNotifications(){requestBrowserNotifications();showToast('You will see exam reminders while this page is open.');}
function notificationTick(){const btn=$('notificationBtn');if(btn){const active=[...anytimeExams,...scheduledExams].some(ex=>examStatus(ex)==='active');btn.classList.toggle('has-alert',active)}if(state.user && 'Notification' in window && Notification.permission==='granted'){const now=new Date();[...anytimeExams,...scheduledExams].forEach(ex=>{const start=new Date(ex.start),end=new Date(ex.end);const key='sg_notified_'+ex.id;if(now>=start && now<new Date(start.getTime()+60*60*1000) && !localStorage.getItem(key)){new Notification('Exam available: '+ex.title,{body:'You can take it now. Deadline: '+formatExamTime(ex.end)});localStorage.setItem(key,'1')}})}}
setInterval(notificationTick,60000);notificationTick();
window.addEventListener('click',e=>{const w=document.querySelector('.notification-wrap');if(w && !w.contains(e.target))$('notificationPanel')?.classList.add('hidden')});

if(state.user){showApp()}
else { $('app').classList.add('hidden'); $('authPage').classList.remove('hidden'); }


/* V12 — visible multi-language picker, more from-scratch examples and expanded video library */
(function enhanceLanguageLearningV12(){
  const makeLesson=(title,items,contexts)=>{
    const enriched=items.map((it,i)=>[it[0],it[1],contexts[i]||'Use this phrase in a real conversation.']);
    const opts=enriched.slice(0,4).map(x=>x[1]);
    const phraseOpts=enriched.slice(0,4).map(x=>x[0]);
    const questions=[
      [`What does "${enriched[0][0]}" mean?`,opts,0],
      [`Choose the phrase for "${enriched[1][1]}"`,phraseOpts,1],
      [`What does "${enriched[2][0]}" mean?`,opts,2]
    ];
    return {title,items:enriched,questions,examples:enriched.slice(0,4).map((it,i)=>`${it[0]} → ${it[1]} • Example: ${it[2]}`)};
  };
  const contexts={
    numbers:['Use it when counting objects.','Use it when saying a quantity.','Use it when giving a simple number.','Use it when talking about today.','Use it when talking about tomorrow.'],
    food:['Use it when asking for water.','Use it when ordering coffee.','Use it when ordering tea.','Use it when saying you need food.','Use it when asking for the bill.'],
    study:['Use it when saying you study or learn.','Use it when talking about an exam.','Use it when asking for an explanation.','Use it after you understand something.','Use it when saying you will meet tomorrow.']
  };
  const additions={
    Spanish:[
      makeLesson('Numbers & Time',[['uno','one'],['dos','two'],['tres','three'],['hoy','today'],['mañana','tomorrow']],contexts.numbers),
      makeLesson('Food & Café',[['agua','water'],['café','coffee'],['té','tea'],['Tengo hambre','I am hungry'],['La cuenta, por favor','The bill, please']],contexts.food),
      makeLesson('Study & Work',[['Estudio','I study'],['Tengo un examen','I have an exam'],['¿Puedes explicar?','Can you explain?'],['Entiendo','I understand'],['Hasta mañana','See you tomorrow']],contexts.study)
    ],
    French:[
      makeLesson('Numbers & Time',[['un','one'],['deux','two'],['trois','three'],["aujourd’hui",'today'],['demain','tomorrow']],contexts.numbers),
      makeLesson('Food & Café',[['eau','water'],['café','coffee'],['thé','tea'],["J’ai faim",'I am hungry'],["L’addition, s’il vous plaît",'The bill, please']],contexts.food),
      makeLesson('Study & Work',[['J’étudie','I study'],["J’ai un examen",'I have an exam'],['Pouvez-vous expliquer ?','Can you explain?'],['Je comprends','I understand'],['À demain','See you tomorrow']],contexts.study)
    ],
    German:[
      makeLesson('Numbers & Time',[['eins','one'],['zwei','two'],['drei','three'],['heute','today'],['morgen','tomorrow']],contexts.numbers),
      makeLesson('Food & Café',[['Wasser','water'],['Kaffee','coffee'],['Tee','tea'],['Ich habe Hunger','I am hungry'],['Die Rechnung, bitte','The bill, please']],contexts.food),
      makeLesson('Study & Work',[['Ich lerne','I study / learn'],['Ich habe eine Prüfung','I have an exam'],['Können Sie das erklären?','Can you explain?'],['Ich verstehe','I understand'],['Bis morgen','See you tomorrow']],contexts.study)
    ],
    Japanese:[
      makeLesson('Numbers & Time',[['いち','one'],['に','two'],['さん','three'],['今日（きょう）','today'],['明日（あした）','tomorrow']],contexts.numbers),
      makeLesson('Food & Café',[['水（みず）','water'],['コーヒー','coffee'],['お茶（おちゃ）','tea'],['お腹がすきました','I am hungry'],['お会計お願いします','The bill, please']],contexts.food),
      makeLesson('Study & Work',[['勉強しています','I am studying'],['試験があります','I have an exam'],['説明してください','Please explain'],['分かりました','I understand'],['また明日','See you tomorrow']],contexts.study)
    ],
    Korean:[
      makeLesson('Numbers & Time',[['하나','one'],['둘','two'],['셋','three'],['오늘','today'],['내일','tomorrow']],contexts.numbers),
      makeLesson('Food & Café',[['물','water'],['커피','coffee'],['차','tea'],['배고파요','I am hungry'],['계산해 주세요','The bill, please']],contexts.food),
      makeLesson('Study & Work',[['공부해요','I study'],['시험이 있어요','I have an exam'],['설명해 주세요','Please explain'],['이해했어요','I understand'],['내일 봐요','See you tomorrow']],contexts.study)
    ],
    Hindi:[
      makeLesson('Numbers & Time',[['एक','one'],['दो','two'],['तीन','three'],['आज','today'],['कल','tomorrow']],contexts.numbers),
      makeLesson('Food & Café',[['पानी','water'],['कॉफी','coffee'],['चाय','tea'],['मुझे भूख लगी है','I am hungry'],['बिल दीजिए','The bill, please']],contexts.food),
      makeLesson('Study & Work',[['मैं पढ़ता/पढ़ती हूँ','I study'],['मेरी परीक्षा है','I have an exam'],['समझाइए, कृपया','Please explain'],['मैं समझ गया/गई','I understand'],['कल मिलते हैं','See you tomorrow']],contexts.study)
    ],
    Telugu:[
      makeLesson('Numbers & Time',[['ఒకటి','one'],['రెండు','two'],['మూడు','three'],['ఈరోజు','today'],['రేపు','tomorrow']],contexts.numbers),
      makeLesson('Food & Café',[['నీరు','water'],['కాఫీ','coffee'],['టీ','tea'],['నాకు ఆకలిగా ఉంది','I am hungry'],['బిల్లు ఇవ్వండి','The bill, please']],contexts.food),
      makeLesson('Study & Work',[['నేను చదువుతున్నాను','I am studying'],['నాకు పరీక్ష ఉంది','I have an exam'],['దయచేసి వివరించండి','Please explain'],['నాకు అర్థమైంది','I understand'],['రేపు కలుద్దాం','See you tomorrow']],contexts.study)
    ],
    Italian:[
      makeLesson('Numbers & Time',[['uno','one'],['due','two'],['tre','three'],['oggi','today'],['domani','tomorrow']],contexts.numbers),
      makeLesson('Food & Café',[['acqua','water'],['caffè','coffee'],['tè','tea'],['Ho fame','I am hungry'],['Il conto, per favore','The bill, please']],contexts.food),
      makeLesson('Study & Work',[['Studio','I study'],["Ho un esame",'I have an exam'],['Puoi spiegare?','Can you explain?'],['Capisco','I understand'],['A domani','See you tomorrow']],contexts.study)
    ],
    Portuguese:[
      makeLesson('Greetings',[['Olá','Hello'],['Bom dia','Good morning'],['Obrigado/Obrigada','Thank you'],['Por favor','Please'],['Tchau','Bye']],['Use when greeting a person.','Use in the morning.','Use to thank someone.','Use when making a polite request.','Use when saying goodbye.']),
      makeLesson('Daily Conversation',[['Sim','Yes'],['Não','No'],['Tudo bem?','Are you okay?'],['Como você está?','How are you?'],['Até logo','See you soon']],['Use to agree.','Use to disagree.','Use as a friendly check-in.','Use to ask how someone feels.','Use when leaving but planning to meet again.']),
      makeLesson('Numbers & Time',[['um','one'],['dois','two'],['três','three'],['hoje','today'],['amanhã','tomorrow']],contexts.numbers),
      makeLesson('Food & Café',[['água','water'],['café','coffee'],['chá','tea'],['Estou com fome','I am hungry'],['A conta, por favor','The bill, please']],contexts.food),
      makeLesson('Travel',[['Onde fica a estação?','Where is the station?'],['Preciso de ajuda','I need help'],['Quanto custa?','How much does it cost?'],['hotel','hotel'],['à esquerda','to the left']],['Use at a station.','Use when you need assistance.','Use while shopping or ordering.','Use when asking for accommodation.','Use when giving directions.']),
      makeLesson('Study & Work',[['Estou estudando','I am studying'],['Tenho uma prova','I have an exam'],['Pode explicar?','Can you explain?'],['Eu entendo','I understand'],['Até amanhã','See you tomorrow']],contexts.study)
    ],
    Russian:[
      makeLesson('Greetings',[['Привет','Hello / Hi'],['Доброе утро','Good morning'],['Спасибо','Thank you'],['Пожалуйста','Please / You are welcome'],['До свидания','Goodbye']],['Use with friends or in casual situations.','Use in the morning.','Use to thank someone.','Use for a polite request or reply.','Use when saying goodbye politely.']),
      makeLesson('Daily Conversation',[['Да','Yes'],['Нет','No'],['Как дела?','How are you?'],['Хорошо','Good / Fine'],['До встречи','See you']],['Use to agree.','Use to disagree.','Use to ask how someone is doing.','Use to say you are fine.','Use when you expect to meet again.']),
      makeLesson('Numbers & Time',[['один','one'],['два','two'],['три','three'],['сегодня','today'],['завтра','tomorrow']],contexts.numbers),
      makeLesson('Food & Café',[['вода','water'],['кофе','coffee'],['чай','tea'],['Я голоден / Я голодна','I am hungry'],['Счёт, пожалуйста','The bill, please']],contexts.food),
      makeLesson('Travel',[['Где станция?','Where is the station?'],['Мне нужна помощь','I need help'],['Сколько это стоит?','How much does it cost?'],['гостиница','hotel'],['налево','to the left']],['Use at a station.','Use when you need assistance.','Use when asking a price.','Use when asking for or talking about a hotel.','Use when giving directions.']),
      makeLesson('Study & Work',[['Я учусь','I study'],['У меня экзамен','I have an exam'],['Объясните, пожалуйста','Please explain'],['Я понимаю','I understand'],['До завтра','See you tomorrow']],contexts.study)
    ]
  };

  Object.entries(additions).forEach(([name, lessons])=>{
    if(!languageCourses[name]){
      const seed=lessons[0];
      const codeMap={Portuguese:'pt-PT',Russian:'ru-RU'};
      const flags={Portuguese:'🇵🇹',Russian:'🇷🇺'};
      languageCourses[name]={code:codeMap[name],flag:flags[name],greeting:name==='Portuguese'?'Olá':'Привет',lessons:[seed]};
    }
    const existing=languageCourses[name].lessons||[];
    const existingTitles=new Set(existing.map(l=>l.title));
    lessons.forEach(l=>{if(!existingTitles.has(l.title))existing.push(l)});
    languageCourses[name].lessons=existing;
  });

  // Add real, topic-specific example usage to every existing language lesson.
  const contextsByTitle={
    'Greetings':['Greeting a classmate: say the first phrase naturally.','Greeting a teacher politely.','Thanking someone after they help you.','Ending a short conversation politely.'],
    'Everyday Phrases':['Answering yes to a simple question.','Saying no politely.','Checking how a friend is doing.','Responding to a friend in a short conversation.'],
    'Travel':['Asking a station employee for directions.','Requesting help when you are lost.','Asking for a price before buying something.','Ordering or requesting an item politely.'],
    'Numbers & Time':['Counting one item.','Counting two items.','Saying a small quantity.','Talking about today or tomorrow.'],
    'Food & Café':['Asking for a drink.','Ordering a coffee.','Ordering tea.','Asking for the bill at the end of a meal.'],
    'Study & Work':['Telling a classmate what you are studying.','Talking about an upcoming exam.','Asking a teacher or colleague to explain.','Confirming that you understand.']
  };
  Object.values(languageCourses).forEach(course=>course.lessons.forEach(lesson=>{
    const ctx=contextsByTitle[lesson.title]||['Use this phrase in a simple conversation.','Use it with a friend or classmate.','Use it in a real-life situation.','Use it when you need a polite response.'];
    lesson.items=lesson.items.map((it,i)=>[it[0],it[1],it[2]||ctx[i%ctx.length]]);
    lesson.examples=lesson.items.slice(0,5).map((it,i)=>`Example ${i+1}: <strong>${it[0]}</strong> — ${it[1]}<br><span class="tiny">${it[2]}</span>`);
  }));

  // Reset an invalid stored language instead of silently falling back to Spanish.
  if(!languageCourses[languageState.language]) languageState.language='Spanish';
  if(typeof languageState.lesson!=='number') languageState.lesson=0;
  saveLanguageState();

  window.languageCoursesV12=languageCourses;
})();

function languages(){
  const selected=languageCourses[languageState.language]||languageCourses.Spanish;
  const completedCount=Object.keys(languageState.completed||{}).filter(k=>languageState.completed[k]).length;
  const cards=Object.entries(languageCourses).map(([name,c])=>`<button class="language-choice-card ${name===languageState.language?'selected':''}" onclick="changeLanguage('${escapeJs(name)}')"><div class="language-choice-flag">${c.flag}</div><div><strong>${name}</strong><small>${c.lessons.length} lessons • ${name===languageState.language?'Selected':'Choose language'}</small></div><span class="language-choice-arrow">→</span></button>`).join('');
  return head('Learn Languages','Learn a new language step by step with vocabulary, real examples, listening, multiple-choice practice and speech recognition.')+
  `<div class="card language-picker-card"><div class="language-picker-heading"><div><span class="eyebrow">DUOLINGO-STYLE LANGUAGE LAB</span><h2>Choose your language</h2><p class="muted">All languages are visible below — click any language to start from the beginning.</p></div><div class="language-stats"><span class="pill gold">🪙 ${languageState.xp} XP</span><span class="pill blue">🔥 ${languageState.streak} streak</span><span class="pill green">✓ ${completedCount} completed</span></div></div><div class="language-choice-grid">${cards}</div><div class="language-select-fallback"><label class="field-label">Quick selector</label><select id="languageSelect" class="field" onchange="changeLanguage(this.value)">${Object.keys(languageCourses).map(l=>`<option value="${l}" ${l===languageState.language?'selected':''}>${languageCourses[l].flag} ${l}</option>`).join('')}</select></div></div>`+
  `<div class="language-hero card"><div><span class="eyebrow">CURRENT COURSE</span><h2>${selected.flag} ${languageState.language}</h2><p class="muted">${selected.lessons.length} bite-sized lessons • Vocabulary • Examples • Listening • Speaking • MCQs</p></div><button class="btn gold-btn" onclick="openLanguageLesson(${Math.min(languageState.lesson,selected.lessons.length-1)})">Continue ${languageState.language} →</button></div>`+
  `<div class="language-path">${selected.lessons.map((l,i)=>`<button class="language-node ${i===languageState.lesson?'active':''} ${languageState.completed[languageState.language+'-'+i]?'done':''}" onclick="openLanguageLesson(${i})"><span>${i+1}</span><strong>${l.title}</strong><small>${languageState.completed[languageState.language+'-'+i]?'✓ Complete':'Practice now'}</small></button>`).join('')}</div>`;
}
function changeLanguage(name){if(!languageCourses[name]){showToast('Please choose a language from the visible language cards.');return}languageState.language=name;languageState.lesson=0;saveLanguageState();showToast(`${languageCourses[name].flag} ${name} selected`);render('languages');}
function openLanguageLesson(i){
  const course=languageCourses[languageState.language]||languageCourses.Spanish;
  languageState.lesson=Math.max(0,Math.min(Number(i)||0,course.lessons.length-1));saveLanguageState();
  const lesson=course.lessons[languageState.lesson];
  window.currentLanguageQuestion=0; const q=lesson.questions[0];
  const exampleHTML=(lesson.examples||[]).map(x=>`<div class="example-box">${x}</div>`).join('');
  $('content').innerHTML=head(`${course.flag} ${languageState.language}: ${lesson.title}`,`Lesson ${languageState.lesson+1} of ${course.lessons.length} • Learn, listen, speak and answer.`)+
  `<div class="grid2"><div class="card"><h3>📚 New words & phrases</h3><div class="list">${lesson.items.map((it,idx)=>`<div class="list-item phrase-card"><div><h4>${it[0]}</h4><p>${it[1]}</p><p class="tiny">💡 ${it[2]}</p></div><button class="btn light" onclick="speakPhrase('${escapeJs(it[0])}','${course.code}')">🔊 Listen</button><button class="btn" onclick="startLanguageSpeech('${escapeJs(it[0])}','${course.code}',${idx})">🎙 Speak</button><div id="speechResult${idx}" class="tiny"></div></div>`).join('')}</div></div><div class="card"><span class="pill blue">Multiple Choice</span><h2 style="margin-top:12px" id="langQuestion">${q[0]}</h2><div id="langOptions">${q[1].map((o,idx)=>`<button class="quiz-option" onclick="answerLanguage(${idx})">${String.fromCharCode(65+idx)}. ${o}</button>`).join('')}</div><div id="langFeedback" style="margin-top:12px"></div><div style="margin-top:16px"><button class="btn light" onclick="render('languages')">← All languages</button><button class="btn gold-btn" onclick="completeLanguageLesson()">✓ Complete lesson</button></div></div></div>`+
  `<div class="card language-examples-card" style="margin-top:18px"><h3 class="section-title">✨ Examples from scratch</h3><p class="muted">Use these new phrases in real situations instead of only memorising word meanings.</p><div class="example-grid">${exampleHTML}</div></div>`;
}
function answerLanguage(idx){
  const lesson=languageCourses[languageState.language].lessons[languageState.lesson];
  const q=lesson.questions[window.currentLanguageQuestion||0]; const fb=$('langFeedback');if(!fb)return;
  const correct=idx===q[2];
  if(correct){languageState.xp+=10;saveLanguageState();fb.innerHTML=`<span class="pill green">✓ Correct! +10 XP</span><p class="muted">Great. Now practice speaking one of the phrases above.</p>`;document.querySelectorAll('#langOptions .quiz-option').forEach(b=>b.disabled=true);}
  else fb.innerHTML=`<span class="pill red">✗ Try again</span><p class="muted">Correct answer: <strong>${q[1][q[2]]}</strong>. Read the example and try once more.</p>`;
}
function startLanguageSpeech(phrase,code,idx){
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR){showToast('Speech recognition is not supported in this browser. Try Chrome or Edge.');return}
  const r=new SR();r.lang=code;r.interimResults=false;r.maxAlternatives=3;
  r.onresult=e=>{const heard=e.results[0][0].transcript.trim();const norm=s=>s.toLowerCase().replace(/[¿?¡!.,]/g,'').normalize('NFD').replace(/[\u0300-\u036f]/g,'');const ok=norm(heard).includes(norm(phrase))||norm(phrase).includes(norm(heard));const box=$(`speechResult${idx}`);if(box)box.innerHTML=ok?`<span class="pill green">✓ Good pronunciation attempt</span><br>You said: ${heard}`:`<span class="pill red">Try again</span><br>You said: ${heard}<br>Target: ${phrase}`;};
  r.onerror=e=>showToast('Speech recognition: '+e.error);r.start();showToast(`🎙 Speak now: ${phrase}`);
}
function completeLanguageLesson(){
  const key=languageState.language+'-'+languageState.lesson;
  if(!languageState.completed[key]){languageState.completed[key]=true;languageState.xp+=20;languageState.streak=Math.max(1,languageState.streak+1);saveLanguageState();addRewardPoints(10,`Completed ${languageState.language} language lesson`);showToast('🎉 Lesson completed! +20 XP +10 coins');}
  const course=languageCourses[languageState.language];
  if(languageState.lesson<course.lessons.length-1){languageState.lesson++;saveLanguageState();setTimeout(()=>openLanguageLesson(languageState.lesson),300)}else render('languages');
}

/* More real teaching-video chapters. These point into verified public YouTube courses. */
const videoExtrasV12={
  Python:[
    ['Python Hello World','Setup and first program','https://www.youtube.com/embed/rfscVS0vtbw?start=400','Start with the first executable Python program.'],
    ['Python Strings','Working with strings','https://www.youtube.com/embed/rfscVS0vtbw?start=1620','Learn string values and common operations.'],
    ['Python Numbers','Working with numbers','https://www.youtube.com/embed/rfscVS0vtbw?start=2298','Practice numbers and arithmetic.'],
    ['Python User Input','Getting input from users','https://www.youtube.com/embed/rfscVS0vtbw?start=2906','Read input and use it in programs.'],
    ['Python Files','Reading files','https://www.youtube.com/embed/rfscVS0vtbw?start=18370','Learn basic file handling.']
  ],
  Java:[
    ['Java Variables','Variables and data types','https://www.youtube.com/embed/xk4_1vDrzzo?start=1226','Learn Java variables.'],
    ['Java User Input','Reading input','https://www.youtube.com/embed/xk4_1vDrzzo?start=2202','Read values from the user.'],
    ['Java If Statements','Decision making','https://www.youtube.com/embed/xk4_1vDrzzo?start=3939','Build conditional logic.'],
    ['Java Loops','While and for loops','https://www.youtube.com/embed/xk4_1vDrzzo?start=5073','Practice repeated execution.'],
    ['Java ArrayList','Dynamic collections','https://www.youtube.com/embed/xk4_1vDrzzo?start=6929','Learn a common Java collection.'],
    ['Java Exceptions','Exception handling','https://www.youtube.com/embed/xk4_1vDrzzo?start=17851','Understand try/catch.']
  ],
  'C++':[
    ['C++ Strings','Working with strings','https://www.youtube.com/embed/vLnPwxZdW4Y?start=2355','Practice string operations.'],
    ['C++ User Input','Getting user input','https://www.youtube.com/embed/vLnPwxZdW4Y?start=3560','Read input from the keyboard.'],
    ['C++ Switch','Switch statements','https://www.youtube.com/embed/vLnPwxZdW4Y?start=7339','Choose between multiple cases.'],
    ['C++ Pointers','Pointer basics','https://www.youtube.com/embed/vLnPwxZdW4Y?start=10751','Understand addresses and pointers.'],
    ['C++ Constructors','Constructors in classes','https://www.youtube.com/embed/vLnPwxZdW4Y?start=195?','Learn how objects are initialized.']
  ],
  'Data Structures':[
    ['Linked List Insertion','Insert at a node position','https://www.youtube.com/embed/B31LgI4Y4DQ?start=6182','Practice insertion in linked lists.'],
    ['Reverse Linked List','Iterative reversal','https://www.youtube.com/embed/B31LgI4Y4DQ?start=6212','Learn iterative linked-list reversal.'],
    ['Stack Parentheses','Balanced parentheses','https://www.youtube.com/embed/B31LgI4Y4DQ?start=12723','Use a stack to check matching brackets.'],
    ['Queue Implementation','Queue with arrays','https://www.youtube.com/embed/B31LgI4Y4DQ?start=16337','Implement a basic queue.'],
    ['Tree Traversal','BFS and DFS traversals','https://www.youtube.com/embed/B31LgI4Y4DQ?start=24410','Understand tree traversal strategies.'],
    ['Graph Representation','Adjacency matrix and list','https://www.youtube.com/embed/B31LgI4Y4DQ?start=52760','Represent graphs in code.']
  ],
  'Data Analytics':[
    ['Data Analysis Project','Real-life data analysis example','https://www.youtube.com/embed/r-uOLxNrNk8?start=671','Follow an end-to-end analysis example.'],
    ['Jupyter Practice','Jupyter notebook tutorial','https://www.youtube.com/embed/r-uOLxNrNk8?start=1850','Work interactively with notebooks.'],
    ['NumPy Arrays','NumPy introduction','https://www.youtube.com/embed/r-uOLxNrNk8?start=3898','Learn numerical arrays.'],
    ['Pandas DataFrames','Pandas introduction','https://www.youtube.com/embed/r-uOLxNrNk8?start=7028','Process table-like data.'],
    ['Data Cleaning','Cleaning messy datasets','https://www.youtube.com/embed/r-uOLxNrNk8?start=10038','Handle nulls and invalid values.']
  ],
  'AI/ML':[
    ['ML Workflow','Machine learning process','https://www.youtube.com/embed/i_LwzRVP7bg?start=500','Understand a typical ML workflow.'],
    ['Training Data','Features and datasets','https://www.youtube.com/embed/i_LwzRVP7bg?start=1000','Understand training inputs.'],
    ['KNN Example','K-nearest neighbors','https://www.youtube.com/embed/i_LwzRVP7bg?start=2500','Learn KNN with intuition.'],
    ['Neural Network Basics','Neural networks','https://www.youtube.com/embed/i_LwzRVP7bg?start=5900','Understand nodes and layers.'],
    ['Clustering','Unsupervised learning','https://www.youtube.com/embed/i_LwzRVP7bg?start=10900','Explore clustering concepts.']
  ],
  'Cloud Computing':[
    ['GCP Introduction','Google Cloud Platform basics','https://www.youtube.com/embed/OUVJ1J_AMEc?start=232','Get a beginner introduction to GCP.'],
    ['GCP Global Infrastructure','Regions and infrastructure','https://www.youtube.com/embed/OUVJ1J_AMEc?start=1451','Understand Google Cloud infrastructure.'],
    ['GCP Console','Console walkthrough','https://www.youtube.com/embed/OUVJ1J_AMEc?start=1813','Explore the GCP console.'],
    ['Cloud Storage Demo','Google Cloud Storage','https://www.youtube.com/embed/OUVJ1J_AMEc?start=2423','See a practical storage walkthrough.'],
    ['Compute Concepts','Compute services','https://www.youtube.com/embed/OUVJ1J_AMEc?start=900','Learn where compute fits.'],
    ['Cloud Certification Path','Google Cloud certification overview','https://www.youtube.com/embed/OUVJ1J_AMEc?start=300','Connect learning to certification preparation.']
  ],
  Communication:[
    ['English Basics','Start speaking from basics','https://www.youtube.com/embed/TyJQRXjOQA8','Begin with confidence, pronunciation and everyday speaking.'],
    ['Daily Conversation','Real-life English practice','https://www.youtube.com/embed/Tqt7Zj-qAtk','Practice useful everyday sentences and conversations.'],
    ['English Shadowing','Listening and speaking practice','https://www.youtube.com/embed/1pUzaV33YCM','Repeat natural sentences to build speaking confidence.'],
    ['English Interviews','Interview conversation practice','https://www.youtube.com/embed/CQsU1bvIqRY','Practice common interview-style communication.']
  ]
};
Object.entries(videoExtrasV12).forEach(([skill,items])=>{if(conceptVideos[skill]){const existing=new Set(conceptVideos[skill].map(v=>v[0]));items.forEach(v=>{if(!existing.has(v[0]) && !v[2].includes('start=195?'))conceptVideos[skill].push(v)})}});

function startResource(skill){
  const list=conceptVideos[skill]||conceptVideos.Python;
  $('content').innerHTML=head(`${skill} Learning Path`,`${list.length} topic videos — learn from the basics, watch examples, then practice with quizzes and assessments.`)+
  `<div class="video-library-stats"><span class="pill blue">▶ ${list.length} videos</span><span class="pill gold">📚 Concept-by-concept learning</span><span class="pill green">✓ Quiz + Assessment</span></div>`+
  `<div class="grid3 video-library-grid">${list.map((v,i)=>`<div class="card video-library-card"><div class="video-thumb"><img src="https://img.youtube.com/vi/${(v[2].match(/embed\/([^?]+)/)||[])[1]||''}/hqdefault.jpg" alt="${v[0]} thumbnail"><span class="video-play">▶</span></div><span class="pill blue">Lesson ${i+1}</span><h3 style="margin-top:10px">${v[0]}</h3><p class="muted"><strong>${v[1]}</strong><br>${v[3]}</p><button class="btn" onclick="openConceptVideo('${skill}',${i})">▶ Watch video</button></div>`).join('')}</div>`+
  `<div style="margin-top:16px"><button class="btn light" onclick="render('resources')">← Back to Resources</button></div>`;
}
function openConceptVideo(skill,i){
  const list=conceptVideos[skill]||conceptVideos.Python; const v=list[i]; if(!v)return startResource(skill);
  state.currentSkill=skill;
  $('content').innerHTML=head(v[0],`${skill} • ${v[1]}`,`<button class="btn light" onclick="startResource('${skill}')">← Back to ${skill} videos</button>`)+
  `<div class="grid2"><div class="card"><div class="video-frame-large"><iframe src="${v[2]}" title="${v[0]}" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div><h3 style="margin-top:18px">${v[0]}</h3><p class="muted">${v[3]}</p><button class="btn gold-btn" onclick="completeVideoLesson('${skill}')">✓ Mark Lesson Complete</button></div><div class="card"><h3 class="section-title">After this video</h3><div class="timeline"><div class="step done"><h4>1. Watch</h4><p>Focus on the concept, worked examples and key terms.</p></div><div class="step"><h4>2. Practice</h4><p>Use the Online Compiler when the topic is programming.</p></div><div class="step"><h4>3. Quiz</h4><button class="btn" onclick="startQuiz('${skill}')">Open ${skill} Quiz</button></div><div class="step"><h4>4. Assessment</h4><button class="btn light" onclick="startAssessment('${skill}')">Open ${skill} Assessment</button></div></div></div></div>`;
}
