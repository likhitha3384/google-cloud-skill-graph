# Suggested Google Cloud production architecture

Frontend: HTML/CSS/JavaScript (or React later)
Authentication: Firebase Authentication
Database: Cloud Firestore
Backend API: Cloud Run
File storage: Cloud Storage
Async learning/risk/recommendation jobs: Cloud Functions or Cloud Run Jobs
AI feedback: Vertex AI (for recommendations, speech/presentation feedback, learning explanations)
Speech: Browser Web Speech API or Google Cloud Speech-to-Text
Video: Cloud Storage / YouTube embeds / your approved course catalog
Charts: Chart.js
Real compiler: isolated sandbox service on Cloud Run/GKE with strict CPU, memory, time and network limits
Certificates: HTML-to-PDF service + Cloud Storage
Notifications: Firebase Cloud Messaging
