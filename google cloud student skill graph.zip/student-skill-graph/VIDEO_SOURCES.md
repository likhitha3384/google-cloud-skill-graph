# Student Skill Graph — Video Sources

The V12 video library uses embedded public YouTube teaching videos and chapter/timestamp links so students can jump directly to a concept.

Current sources include:
- freeCodeCamp: Python full course — https://www.youtube.com/watch?v=rfscVS0vtbw
- Bro Code: Java full course — https://www.youtube.com/watch?v=xk4_1vDrzzo
- freeCodeCamp: C++ full course — https://www.youtube.com/watch?v=vLnPwxZdW4Y
- freeCodeCamp / MyCodeSchool: Data Structures full course — https://www.youtube.com/watch?v=B31LgI4Y4DQ
- freeCodeCamp: Data Analysis with Python — https://www.youtube.com/watch?v=r-uOLxNrNk8
- Google Cloud beginner tutorial (Great Learning) — https://www.youtube.com/watch?v=OUVJ1J_AMEc
- Communication practice examples include recent English-learning YouTube videos from verified channels.

The app embeds the videos; it does not copy or re-host the video files.
