# Student Skill Graph — V2 Final

This version includes:
- Multiple topic-specific communication examples for every lesson
- Communication practice with explanations for wrong answers
- Skill-specific concept videos
- Coins for correct quiz, assessment and communication answers
- Selectable coin targets: 50, 100, 250, 500, 1000
- Coin progress bar toward the selected target
- Saved coin earning/claim history in browser localStorage
- Reward Store
- Quiz and assessment result history
- Online compiler

## How to open
1. Extract this ZIP completely.
2. Open the folder `student-skill-graph-v2-final`.
3. Double-click `index.html`.
4. If an older version was already open, press `Ctrl + F5` in the browser.
5. Click **Communication** to see the multiple examples.
6. Click **Rewards** to see coins, targets, progress and history.

Important: rewards are demo reward entries until real partner coupon/subscription codes are configured.

## V6 additions
- Strict email + password login using locally stored account credentials.
- Study Materials section with skill-specific materials, downloadable PDF study packs, textbook/reference links and learning blueprints.
- Scheduled Exams section with configured beginning/ending date-time windows, locked exams before start, active exams during the window, and closed exams after the end time.
- Exam results, review, history and coin rewards are stored locally.
- Default demo account: student@example.com / Student@123


### Ask Questions
Students can open **Ask Questions** from the sidebar and type a doubt. The feature returns a structured learning answer with:
- clear concept content
- key points
- a practical/example section
- topic-aware matching for programming, DSA, SQL, web development, cloud, AI/ML, data analytics and more

The current version works locally with a built-in learning knowledge base. An AI provider such as Gemini can be connected later for open-ended questions beyond the built-in topics.


### V11 additions
- Duolingo-style Learn Languages area with Spanish, French, German, Japanese, Korean, Hindi, Telugu and Italian.
- Bite-sized phrase lessons, multiple-choice practice, text-to-speech listening and browser speech recognition speaking practice.
- Anytime exams that can be started before a configured deadline, plus fixed schedule exams.
- In-app notification center and optional browser exam reminders while the page is open.
- 30 LeetCode-style coding practice problems linked to the online compiler.
- Animated page transitions, cards, buttons, navigation and interactive elements.
- Password show/hide eye icon on sign-in.
